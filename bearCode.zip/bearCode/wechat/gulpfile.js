var gulp     = require('gulp'),
browserSync  = require('browser-sync'),
reload       = browserSync.reload,
sass         = require('gulp-sass'),
concat       = require('gulp-concat'),
sourcemaps   = require('gulp-sourcemaps'),
fileinclude  = require('gulp-file-include'),
autoprefixer = require('gulp-autoprefixer');
imagemin     = require('gulp-imagemin');
pngquant     = require('imagemin-pngquant');
spritesmith  = require('gulp.spritesmith');
base_url     = './src/',
dev          = true;
gulp.task('sprite', function () {
  var spriteData = gulp.src(base_url+'images/icons/*.+(jpeg|jpg|png)').pipe(spritesmith({
    imgName: 'icons_sprite.png',
    cssName: 'icons_sprite.css',
    cssFormat: 'css',
    padding: 10
  }));
  return spriteData.pipe(gulp.dest(base_url+'css'));
});
//图片压缩
gulp.task('images-opt', function () {
    gulp.src(base_url+'/_images/**/*.+(jpeg|jpg|png)')
        .pipe(imagemin({
            progressive: true,
            use: [pngquant({quality: '70'})]
        }))
        .pipe(gulp.dest(base_url+'/images/'));
});

gulp.task('sass', function () {
  var type = dev ? '':'compressed';
  gulp.src('src/sass/*.scss')
    .pipe(sourcemaps.init())
    .pipe(sass({outputStyle: type}).on('error', sass.logError))
    .pipe(autoprefixer({
        browsers: ['last 2 versions'],
        cascade: true
    }))
    /*.pipe(sourcemaps.write())*/
    .pipe(gulp.dest(base_url+'css'))
    .pipe(reload({stream:true}));
});
gulp.task('concat:css', function() {   
    gulp.src([base_url+'css/yi.css', base_url+'css/icons_sprite.css'])
        .pipe(concat('yi.min.css')) 
        .pipe(gulp.dest(base_url+'css')) 
});
gulp.task('autoPrefixer', function () {
    gulp.src(base_url+'css/*.css')
        .pipe(autoprefixer({
            browsers: ['last 2 versions'],
            cascade: true
        }))
        /*.pipe(sourcemaps.write('.'))*/
        .pipe(gulp.dest(base_url+'css'));
});
gulp.task('browser-sync', function() {
    browserSync({
        server: {
            baseDir: "./"
        }
    });
});
gulp.task('scripts:common', function() {
  return gulp.src([
      base_url+'js/base/mz.js',
      base_url+'js/base/browser.js',
      base_url+'js/base/utils.js',
      base_url+'js/base/cart.js',
      base_url+'js/base/mask.js',
      base_url+'js/base/ui.js',
      base_url+'js/base/wechat.js',
      base_url+'js/base/ajax.js',
      base_url+'js/base/echo.js',
      base_url+'js/base/app.js'
    ])
    .pipe(concat('common.js'))
    .pipe(gulp.dest(base_url+'js'));
});
gulp.task('fileinclude', function() {
  gulp.src(['_views/**/*.html'])
    .pipe(fileinclude({
      prefix: '@@',
      basepath: '@file'
    }))
    .pipe(gulp.dest('./views'));
});
gulp.task('normal', function() {
  gulp.src(['views/**/*.html']).pipe(reload({stream:true}));
});

gulp.task('default', ['sass','fileinclude','browser-sync','images-opt','sprite','concat:css','scripts:common'], function () {
  gulp.watch(['src/sass/**/*.scss'], ['sass','concat:css']);
  gulp.watch(['src/_images/**/*.+(jpeg|jpg|png)'], ['images-opt']);
  gulp.watch(['src/images/**/*.+(jpeg|jpg|png)'], ['sprite','concat:css']);
  gulp.watch(['src/js/base/*.js'], ['scripts:common']);
  gulp.watch(['_views/**/*.html'], ['fileinclude']);
  gulp.watch(['views/**/*.html'], ['normal']);
});