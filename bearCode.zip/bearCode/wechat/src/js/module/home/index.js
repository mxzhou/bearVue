define(function(require, exports,modules) {
    var App = {};
    var LoadMore = require('widgets/load-more');
    var win = window,
        doc = document;
    function layout(){
       
    }
    //图片延迟加载
    function initEcho(){
        echo.init({
            offset: 200,
            throttle: 250,
            unload: false,
            callback: function (element, op) {
                //console.log(element, 'has been', op + 'ed')
            }
        });
    }
    App.init = function(){
        addEvent();
        layout();
        //设置底部导航选中样式
        MZ.setNavStatus(0);
        setTimeout(function(){
            //中奖
            /*MZ.showPrize({
                id: 1,
                number: 123323432,
                name: '外星人 15.6 英寸游戏本'
            });*/
            //分享成功显示激励奖金
            /*MZ.showShareResult({
                title: '分享成功！恭喜你获得',
                desc: '1000元激励奖金'
            });*/
           /* $('#pageLottery').fadeIn();
            setTimeout(function(){
                $('#pageLottery').addClass('animatein');
            },500)*/
        },1000)
        //获取广告列表
        ajaxGetAd();
        //图片延迟加载
        MZ.utils.initEcho();
        //最易中 最新 最热...列表加载
        initTabContainer();
        //最新揭晓模块加载
        initNewOpenContainer();
        //获取信息数量
        ajaxGetMsgNum();
        //loopTime();
    }
    var LastId = 0;
    function initTabContainer(){
        //初始化下拉加载更多
        var $datalist = $('.datalist');
        //加载最热列表第一页
        getList(0,true);
        getList(1,true);
        getList(2,true);
        getList(3,true);
        getList(4,true);
        var activeTabIdx;
        $(document).on('scroll touchmove',function(){
            activeTabIdx = $('#fixedTab .active').index();
            if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
                if($('.animate-loading-spiner').length==0 && $('.nomore').length==0){
                    $('<div class="center loading-more"><div class="animate-loading-spiner"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div></div>').insertAfter($datalist.eq(activeTabIdx).find('.list-two'));
                }
                getList(activeTabIdx);
            }
        });
        var Loading = false;
        function getList(activeTabIdx,first){
            var typeid = activeTabIdx;
            if(!first){
                if(Loading)return;
                Loading = true;
            }
            var $list = $datalist.eq(activeTabIdx).find('.list-two');
            var page = $list.attr('data-page');
            if($list.hasClass('nodata')){
                Loading= false;
                LoadMore.finish();
                return;
            }
            var LastId = $list.attr('lastid') == null ? 0:$list.attr('lastid');
            Zepto.ajax({
                url: ApiPrefix + '/goods/list',
                type: 'post',
                cache: false,
                data: {"kgUid": kgUid,"token": MZ.utils.getToken(),"status": 0,"lastId": LastId,"pageNumber": page,"pageSize": 10,"type": typeid},
                dataType: 'json',
                success:function(data){
                    if(data.errorMessage=='token不合法'){
                        MZ.wechat.checkLogin(data);
                        return;
                      }
                    if(data.status==1){
                        var list = data.data.goodsList;
                        if(list.length!=0){
                            var str = '';
                            for(var i in list) {
                                var item = list[i];
                                str += '<li><a href="detail.html?goodsId='+item.goodsId+'&id='+item.id+'">'+
                                       ' <div class="pic"><img src="'+ImgBlank+'" alt="'+item.goodsName+'" data-echo="'+item.coverImgUrl+'"></div>'+
                                        '    <h4>'+item.goodsName+'</h4>'+
                                        '    <div class="goods-control">'+
                                        '      <div class="goods-status">'+
                                        '        <div class="progress-bar">'+
                                        '          <div class="inner" style="width:'+((item.needNumber-item.surplusNumber)/item.needNumber*100)+'%;"></div>'+
                                        '        </div>'+
                                        '        <div class="btn-area">'+
                                        '            <a href="javascript:" data-id="'+item.goodsId+'" class="btn btn-red-transparent fr jsAddCar">加入清单</a>'+
                                        '            <p>总需: '+item.needNumber+'</p>'+
                                        '            <p>剩余: <span class="yellow">'+item.surplusNumber+'</span></p>'+
                                        '        </div>'+
                                        '      </div>'+
                                        '    </div>'+
                                        '</a></li>';
                                if(i==0){
                                    //获取最新
                                    if(typeid==1 && i==list.length-1){
                                        $list.attr('lastid',item.id);
                                    }
                                }
                            }
                            $list.append(str);
                            $list.attr('data-page',page-1+2);
                            //延迟加载
                            MZ.utils.initEcho();
                            LoadMore.finish();
                        }else {
                            $list.addClass('nodata');
                            $('<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;border-top:1px solid #CCC;">暂无更多</div>').insertAfter($list);
                        }
                    }else{
                        MZ.alert({content: data.errorMessage});
                    }
                    Loading = false;
                },
                error: function(){
                    Loading = false;
                }
            })
            
        }
        //tab菜单
        $('#fixedTab a').on('click',function(){
            var $this = $(this),
                idx = $this.index();
            LastId = 0;
            $this.addClass('active').siblings('a').removeClass('active');
            $('.datalist').eq(idx).show().siblings('.datalist').hide();
            activeTabIdx = $('#fixedTab .active').index();
            //getList(activeTabIdx);
            //延迟加载
            MZ.utils.initEcho();
        })
    }
    function initNewOpenContainer(){
        var $newOpenList = $('#newOpenList');
        Zepto.ajax({
            url: ApiPrefix+'/goods/open',
            type: 'post',
            data: {"kgUid": kgUid,"token": MZ.utils.getToken(),"status": 0,"lastId": 0,"pageSize": 3},
            dataType: 'json',
            cache: false,
            success: function(data){
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    var list = data.data.goodsList;
                    var str = '';
                    for(var i in list){
                        var item = list[i];
                        if(i<=2){
                            //3正在计算，5已经揭晓
                            if(item.status==3){
                                str += '<li data-type="3" data-robid="'+item.id+'" servertime="'+data.servertime+'" startTime="'+(item.startTime+3*60*1000)+'"><a href="detail.html?id='+item.id+'">'+
                                '<div class="pic"><img src="'+item.coverImgUrl+'"></div>'+
                                '<h4>'+item.goodsName+'</h4>'+
                                '<div class="time">已揭晓</div>'+
                                '</a></li>';
                            }else if(item.status==5){
                                str += '<li data-type="5" data-robid="'+item.id+'" servertime="'+data.servertime+'" startTime="'+item.startTime+'"><a href="detail.html?id='+item.id+'">'+
                                '<div class="pic"><img src="'+item.coverImgUrl+'"></div>'+
                                '<h4>'+item.goodsName+'</h4>'+
                                '<div class="time">已揭晓</div>'+
                                '</a></li>';
                            }
                        }
                    }
                    $newOpenList.html(str);
                    initTicker();
                }else{
                    MZ.confirm({
                        content: data.errorMessage,
                        callback: function(e){
                            //确定后执行
                        }
                    });
                }
            }
        })
    }
    var ticker;
    function initTicker(){
        var $list = $('#newOpenList li');
        clearInterval(ticker);
        var systemTime,localTime=new Date().getTime();
        if($list.length!=0){
            systemTime = parseInt($list.eq(0).attr('servertime'));
            /*systemTime = new Date('2016/03/02 12:30:13').getTime();
            var t1 = new Date('2016/03/02 12:32:13').getTime();
            ticker = setInterval(function(){
                systemTime+=10;
                console.log(MZ.utils.leaveTime(systemTime,t1));
            },10)*/
            ticker = setInterval(function(){
                var stime = systemTime + (new Date().getTime()-localTime);
                for(var i=0;i<$list.length;i++){
                    (function(i){
                      var $item = $list.eq(i);
                      if($item.attr('data-type')!=3){
                        return;
                      }
                      var t = parseInt($item.attr('startTime'));
                      //console.log(time,t);
                      //1458043618243 "1458042973790"
                      var time = MZ.utils.leaveTime(stime,t);
                      if(time==0){
                        $item.find('.time').html('已揭晓');
                        if($item.attr('hasGetInfo')!='true'){
                            $item.attr('hasGetInfo','true');
                            var id = $item.attr('data-robid');
                            MZ.ajax.getWin({robid:id,callback:function(data){
                              if(data.data.myWin){
                                MZ.showPrize({id:id,name:$item.find('h4').html(),avatarUrl:$item.find('img').attr('src'),href:'user/address.html?robid='+id})
                              }
                            }})
                        }
                      }else{
                        $item.find('.time').html(time);
                      }
                    })(i)
                }
            },10)
        }
    }
    function addEvent(){
        var $body = $('body'),
            $fixedTab = $('#fixedTab'),
            $fixedTabHeight = $('#fixedTabHeight'),
            $fixedTabBody = $('.for-page-index .bd').eq(1);
        MZ.browser.sticky && $fixedTab.addClass('sticky');
        MZ.browser.sticky || (document.addEventListener("touchmove", function () {
            scroll();
        }), document.addEventListener("scroll", function () {
            scroll();
        }))      
        function scroll() {
            var top = $body.scrollTop();
            if(top>=810){
                $fixedTab.addClass('fixed-tab');
                $fixedTabHeight.height(96);
            }else{
                $fixedTab.removeClass('fixed-tab');
                $fixedTabHeight.height(0);
            }
        }
        //加入清单
        $(document).delegate('.jsAddCar','click',function(){
            var $this = $(this),
                $parentLi = $this.parents('li'),
                $img = $parentLi.find('img');
            var $animatePic = $('<div class="animate-pic"></div>');
            $('body').append($animatePic);
            var imgOffset = $img.offset();
            var scrollTop = $('body').scrollTop();
            $animatePic.css({'width':imgOffset.width,'height':imgOffset.height,'top':imgOffset.top-scrollTop,'left':imgOffset.left})
                .html('<img src="'+$img.attr('src')+'">');
            var addNumber = 1;
            if($parentLi.find('.yellow').html()>500){
                addNumber = 5;
            }
            MZ.cart.addCart({goodsList:[{goodsId:$this.attr('data-id'),number:addNumber}]});
            //购物车导航所在位置
            var $tabItemCar = $('.tab-item').eq(3);
                tabItemOffset = $tabItemCar.offset();
            var moveTop = $(window).height()-$('.footer-nav').height()-(imgOffset.top-scrollTop);
            TweenMax.fromTo($animatePic,2,
                {x:0,ease:Power2.easeOut},
                {x:tabItemOffset.left-imgOffset.left,y:moveTop,opacity:0,scale:0.2,ease:Power2.easeOut,
                onComplete:function(){
                    $animatePic.remove();
                }
            });
        })
        
    }
    function loopTime(){
        var t1 = new Date('2016/03/02 12:32:13').getTime(),
            t2 = new Date('2016/03/04 12:32:54').getTime(),
            t3 = new Date('2016/03/04 18:23:52').getTime();
        var systemTime = new Date('2016/03/02 12:32:10').getTime();
        var $listThirdLi = $('.list-third li');
        $listThirdLi.eq(0).find('.time').html(MZ.utils.leaveTime(systemTime,t1));
        $listThirdLi.eq(1).find('.time').html(MZ.utils.leaveTime(systemTime,t2));
        $listThirdLi.eq(2).find('.time').html(MZ.utils.leaveTime(systemTime,t3));
        setInterval(function(){
            t1-=1000;
            t2-=1000;
            t3-=1000;
            $listThirdLi.eq(0).find('.time').html(MZ.utils.leaveTime(systemTime,t1));
            $listThirdLi.eq(1).find('.time').html(MZ.utils.leaveTime(systemTime,t2));
            $listThirdLi.eq(2).find('.time').html(MZ.utils.leaveTime(systemTime,t3));
        },1000)
    }
    function ajaxGetAd(){
        Zepto.ajax({
            url: ApiPrefix+'/goods/head',
            type: 'get',
            data: {"kgUid": kgUid,"token": MZ.utils.getToken(),"status": 0,"lastId": 0,"pageSize": 3},
            dataType: 'json',
            cache: false,
            success:function(data){
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    var list = data.data;
                    var str = '';
                    for(var i in list){
                        var item = list[i];                        
                        if(item.type==1){
                            //url地址url有值
                            if(!/activity\/signin/gi.test(item.url)){
                                str+='<div class="swiper-slide" data-url="'+item.url+'" style="background:url('+item.coverImgUrl+') center center no-repeat;width:100%;height:300px;background-size:cover;"></div>';
                            }
                        }else if(item.type==2){
                            //商品详情id有值
                            str+='<div class="swiper-slide" data-url="detail.html?goodsId='+item.uniqueId+'&id=0" style="background:url('+item.coverImgUrl+') center center no-repeat;width:100%;height:300px;background-size:cover;"></div>';
                        }else if(item.type==3){
                            //搜索结果title有值
                            str+='<div class="swiper-slide" data-url="search.html?searchContent='+item.searchContent+'"style="background:url('+item.coverImgUrl+') center center no-repeat;width:100%;height:300px;background-size:cover;"></div>'
                        }
                    }
                    $('.swiper-wrapper').html(str);
                    var swiper = new Swiper('.swiper-container', {
                        pagination: '.swiper-pagination',
                        paginationClickable: true,
                        autoplayDisableOnInteraction : false,
                        autoplay: 3000,
                        width: window.innerWidth>750?750:window.innerWidth,
                        height: 100,
                        loop: true
                    });
                }
            }
        })
        //点击广告图片
        $(document).delegate('.swiper-slide','click',function(){
            window.location.href = $(this).attr('data-url');
        })
    }
    function ajaxGetMsgNum(){
        Zepto.ajax({
            url: ApiPrefix+'/messageNum/getNum',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid},
            cache: false,
            success: function(data){
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                log(data)
                if(data.status==1){
                    if(data.data!=null){
                        var msg =data.data;
                        var count = msg.sysNum+msg.activityNum+msg.logisticsNum;
                        if(count!=0){
                            $('.bar-nav.for-home .badge').html(count).show();
                        }
                    }
                }else{
                    //MZ.alert({content: data.errorMessage});
                }
            },
            error: function(){
            }
        })
    }
    modules.exports = App;
});
