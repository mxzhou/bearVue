define(function(require, exports,modules) {
    var App = {};
    var win = window,
    doc = win.document;
    var LoadMore = require('widgets/load-more');
    function layout(){
        
    }
    App.init = function(){
        addEvent();
        layout();
        loadmore();
        getList();
    }
    function loadmore(){
        //初始化下拉加载更多
        $(document).on('scroll touchmove',function(){
            if(HasNoMore){
              $('.loading-more').hide();
              return;
            }
            if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
                if($('.loading-more').length==0){
                    getList();
                }
            }
        });
    }
    var Page = 1;
    var Loading = false;
    var HasNoMore = false;
    function getList(){
        if(Loading)return;
        Loading = true;
        if(HasNoMore)return;
        var pageSize=10
        Zepto.ajax({
            url: ApiPrefix+'/find/waitingShare',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,"pageSize": pageSize,"pageNumber":Page},
            cache: false,
            dataType: 'json',
            success: function(data){
              if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                log(data)
                if(data.status==1){
                    var $list = $('.for-good-list');
                    var str = '';
                    var list  = data.data;
                    for(var i in list) {
                        var item = list[i];
                        str += '<li class="table-view-cell media">'+
                                '<div href="detail-calculation.html" class="navigate-right">'+
                                '  <div class="pic-left"><img class="media-object pull-left" src="'+ImgBlank+'" data-echo="'+item.sharePicUrl+'"></div>'+
                                '  <div class="media-body">'+
                                '    <div class="media-right">'+
                                '      <a href="javascript:" class="btn btn-red-transparent btnShowDialog">晒单</a>'+
                                '    </div>'+
                                '    <h3>'+item.goodsName+'</h3>'+
                                '    <p class="item">期号: '+item.goodsRobId+'</p>'+
                                '    <p class="item">总需: '+item.price+'</p>'+
                                '  </div>'+
                                '</div>'+
                              '</li>';
                    }
                    $list.append(str);
                    MZ.utils.initEcho();
                    if(Page==1 && list.length == 0){
                      var str = '<div class="cart-empty" style="margin-top:20%;">'+
                                 ' <i class="icon icon-cartempty"></i>'+
                                 ' <h3>暂无晒单记录</h3>'+
                                '</div>';
                      $('.footer-icon').hide();
                      if($('.cart-empty').length!=0){
                        $('.cart-empty').show();
                      }else{
                        $('body').append(str);
                      }
                      HasNoMore = true;
                    }else if(list.length<pageSize){
                     HasNoMore = true;
                     //var nomorestr='<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;">没有更多记录</div>';
                     //$list.append(nomorestr);
                    }
                    //图片延迟加载
                    MZ.utils.initEcho();
                    Page++;
                }else{
                    MZ.alert({content: data.errorMessage});
                }
                Loading = false;
            },
            error: function(){
              Loading = false;
            }
        })
        
    }
    function getListShare(){
        if(Loading)return;
        Loading = true;
        if(HasNoMore)return;
        var pageSize=10;
        Zepto.ajax({
            url: ApiPrefix+'/find/mySharelist',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,"pageSize": pageSize,"pageNumber":Page},
            cache: false,
            dataType: 'json',
            success: function(data){
              if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                log(data)
                if(data.status==1){
                    var $list = $('.for-share-list');
                    var str = '';
                    var list = data.data;
                    for(var i in list) {
                        var item = list[i];
                        var imgList = item.sharePicUrl.split(',');
                        var imgStr = '';
                        for(var i in imgList){
                          imgStr+='<dd><img src="'+ImgBlank+'" data-echo="'+imgList[i]+'"></dd>';
                        }
                        var userimg = item.avatarUrl;
                        if(userimg==''||userimg==null){
                            userimg = ImgUser;
                        }
                        str += '<li class="table-view-cell media" onclick="location.href=\'share-detail.html?id='+item.id+'\'">'+
                                '<div class="pic-left"><img src="'+userimg+'"></div>'+
                                '<div class="media-body">'+
                                 ' <h4><span class="fr">'+item.createTime+'</span>'+item.nickname+'</h4>'+
                                 ' <p>'+item.winWords+'</p>'+
                                 ' <dl class="pic-list">'+imgStr+
                                 ' </dl><div class="more">'+
                                 '   <div class="fr"><a href="../detail.html?id=0&goodsId='+item.goodsId+'" class="btn btn-red-transparent">我还要</a></div>'+
                                 '   <div class="fl">'+
                                 '     <p>'+item.goodsName+'</p>'+
                                 '     <p>期号：'+item.goodsRobId+'</p>'+
                                 '   </div>'+
                                 ' </div>'+
                                '</div>'+
                           ' </li>';
                    }
                    $list.append(str);
                    MZ.utils.initEcho();
                    if(Page==1 && list.length == 0){
                      var str = '<div class="cart-empty" style="margin-top:20%;">'+
                                 ' <i class="icon icon-cartempty"></i>'+
                                 ' <h3>暂无晒单记录</h3>'+
                                '</div>';
                      $('.footer-icon').hide();
                      if($('.cart-empty').length!=0){
                        $('.cart-empty').show();
                      }else{
                        $('body').append(str);
                      }
                    }else if(list.length<pageSize){
                     HasNoMore = true;
                     //var nomorestr='<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;">没有更多记录</div>';
                     //$list.append(nomorestr);
                    }
                    //图片延迟加载
                    MZ.utils.initEcho();
                    Page++;
                }else{
                    MZ.alert({content: data.errorMessage});
                }
                Loading = false;
            },
            error: function(){
              Loading = false;
            }
        })
        
    }
    function addEvent(){
        var $body = $('body'),
            $friendIndexFixed = $('#myRecordFixed'),
            $friendIndexFixedHeight = $('#myRecordFixedHeight');
        MZ.browser.sticky && $friendIndexFixed.addClass('sticky');
        MZ.browser.sticky || (document.addEventListener("touchmove", function () {
            scroll();
        }), document.addEventListener("scroll", function () {
            scroll();
        }))      
        function scroll() {
            var top = $body.scrollTop();
            if(top>=365){
                $friendIndexFixed.addClass('fixed-tab');
                $friendIndexFixedHeight.height(96);
            }else{
                $friendIndexFixed.removeClass('fixed-tab');
                $friendIndexFixedHeight.height(0);
            }
        }
        //tab
        $('#myRecordFixed a').on('touchend',function(e){
          var $this = $(this);
          Loading = false;
          HasNoMore = false;
          pageSize=10;
          Page = 1;
          lastId = 0;
          $this.addClass('active').siblings('a').removeClass('active');
          $('.cart-empty').hide();
          if($this.index()==0){
            $('.for-good-list').html('').show();
            $('.for-share-list').hide();
            getList();
          }else if($this.index()==1){
            $('.for-good-list').hide();
            $('.for-share-list').html('').show();
            getListShare();
          }
          e.preventDefault();
        })
        //晒单
        $('body').delegate('.btnShowDialog','click',function(){
          MZ.alert({content:'<div style="padding: 40px 0;font-size:32px;"><span class="icon icon-img_dlapp_2x" style="margin-bottom:20px;"></span><br>下载手机客户端<br>赢10夺宝币奖励<br><a href="http://a.app.qq.com/o/simple.jsp?pkgname=com.kugou.yiyuanmai" class="btn btn-red" style="width:300px;height:80px;line-height:80px;margin-top:30px;">立即下载</a></div>',footer:false});
        })
        $('body').delegate('.weui_mask','touchend',function(){
          $(this).parents('.weui_dialog_confirm').remove();
        })
    }
    
    modules.exports = App;
});
