define(function(require, exports,modules) {
    var App = {};
    var win = window,
    doc = win.document;
    function layout(){
        
    }
    App.init = function(){
        addEvent();
        layout();
        getRSA('ajaxMyExchange',JSON.stringify({'key':'1'}));
    }
    function addEvent(){
        if(!MZ.browser.isWechat){
          if(!MZ.browser.isIos){
             //$('.footer-fx-btn').hide();
          } 
        }
        //下载
        $('#btnDownload').on('click touchend',function(e){
            e.preventDefault();
            if(MZ.browser.isWechat){
              
            }else{
              if(MZ.browser.isIos){
                 location.href = 'https://itunes.apple.com/cn/app/ku-gou-yin-le-xiu/id774384491?mt=8';
              }else{
                window.clickListener.InstallApk('http://downmobile.kugou.com/upload/android_beta/fanxing_6572_2.9.8.2_555.apk')
                //location.href = 'http://downmobile.kugou.com/upload/android_beta/fanxing_6572_2.9.8.2_555.apk';
              }  
            }
        })
        //兑换繁星座骑
        $('#btnExchange').on('click touchend',function(e){
            e.preventDefault();
            if($(this).hasClass('disabled'))return;
            $('#pageInfo').addClass('active');
        })
        $('#btnExchangeOK').on('click touchend',function(e){
            e.preventDefault();
            var $fxId = $('#fxId'),
                $fxIdSure = $('#fxIdSure');
            var val1 = $fxId.val().replace(/\s/g,'');
            var val2 = $fxIdSure.val().replace(/\s/g,'');
            if(val1 == ''){
                $fxId.siblings('.error').html('请输入繁星账号');
                return;
            }else{
                $fxId.siblings('.error').html('');
            }
            if(val2 == ''){
                $fxIdSure.siblings('.error').html('请输入繁星账号');
                return;
            }else{
                $fxIdSure.siblings('.error').html('');
            }
            if(val1 != val2){
                $fxIdSure.siblings('.error').html('繁星账号两次输入不一致');
                return;
            }else{
                $fxIdSure.siblings('.error').html('');
            }
            getRSA('ajaxExchange',JSON.stringify({'fxUserId':val1}));
        })
        $('.btnClose').on('click touchend',function(e){
            e.preventDefault();
            $('#pageInfo').removeClass('active');
        })
    }
    
    //http://1.kmh.kugou.com/api/activity/dragonBoat/
    modules.exports = App;
});
function ajaxExchange(data){
    var data = JSON.parse(data);
    var urrstr,contentType='';
    if(MZ.browser.isWechat){
        data.token = MZ.utils.getToken();
        data.kgUid = kgUid;
        urlstr = ApiPrefix+'/user/exchange';
    }else{
        if(data.data.kgUid==0 || data.data.kgUid == undefined){
            MZ.alert({content:'您还未登录，请先登录',callback:function(){
                if(MZ.browser.isIos){
                    document.location = "KugouBuy:Login";
                }else{
                    window.clickListener.GoRegister();
                }
            }});
            return;
        }
        contentType = 'application/json';
        urlstr = '/api/user/exchange';
        data = JSON.stringify(data);
    }
    var loading = new MZ.loading({content:'请求中...'});
    Zepto.ajax({
        url: urlstr,
        type: 'post',
        data: data,
        contentType: contentType,
        success: function(data){
            loading.hide();
            if(data.status==1){
                if(data.data.total<=0){
                    MZ.alert({content:'没有可兑换天数',callback:function(){
                        $('.weui_dialog_confirm').remove();
                    }});
                }else{
                    MZ.alert({
                        content:'<div style="margin-top:-30px;padding-bottom:30px;">兑换成功</div>成功兑换胖熊座驾'+data.data.total+'天，请登录繁星直播查看',
                        text:'我知道了',
                        callback:function(){
                        $('#pageInfo').removeClass('active');
                        getRSA('ajaxMyExchange',JSON.stringify({'key':'1'}));
                    }});
                }
            }else{
                MZ.alert({content:data.errorMessage});
            }
        },
        error: function(e){
            loading.hide();
            MZ.alert({content: '网络连接错误'})
        }
    })
}
function ajaxMyExchange(data){
    var data = JSON.parse(data);
    var urrstr,contentType='';
    if(MZ.browser.isWechat){
        data.token = MZ.utils.getToken();
        data.kgUid = kgUid;
        urlstr = ApiPrefix+'/user/myExchange';
    }else{
        if(data.data.kgUid==0 || data.data.kgUid == undefined){
            MZ.alert({content:'您还未登录，请先登录',callback:function(){
                if(MZ.browser.isIos){
                    document.location = "KugouBuy:Login";
                }else{
                    window.clickListener.GoRegister();
                }
            }});
            return;
        }
        contentType = 'application/json';
        data = JSON.stringify(data);
        urlstr = '/api/user/myExchange';
    }
    Zepto.ajax({
        url: urlstr,
        type: 'post',
        data: data,
        contentType: contentType,
        success: function(data){
            if(data.status==1){
                if(data.data.total==0){
                    $('#btnExchange').addClass('disabled');
                }else{
                    $('#btnExchange').removeClass('disabled');
                }
                $('#pxDay').html(data.data.total+"天");
            }else{
                MZ.alert({content:data.errorMessage});
            }
        },
        error: function(e){
            MZ.alert({content: '网络连接错误'})
        }
    })
}
function setupWebViewJavascriptBridge(callback) {
    if (window.WebViewJavascriptBridge) { return callback(WebViewJavascriptBridge); }
    if (window.WVJBCallbacks) { return window.WVJBCallbacks.push(callback); }
    window.WVJBCallbacks = [callback];
    var WVJBIframe = document.createElement('iframe');
    WVJBIframe.style.display = 'none';
    WVJBIframe.src = 'wvjbscheme://__BRIDGE_LOADED__';
    document.documentElement.appendChild(WVJBIframe);
    setTimeout(function() { document.documentElement.removeChild(WVJBIframe) }, 0)
}
setupWebViewJavascriptBridge(function(bridge) {
    bridge.registerHandler('px_webSideHandler', function(data, responseCallback) {
    })
})
function getRSA(ajaxFunc,params){
    if(MZ.browser.isWechat){
        if(ajaxFunc=='ajaxMyExchange'){
            ajaxMyExchange(params);
        }
        if(ajaxFunc=='ajaxExchange'){
            ajaxExchange(params);
        }
    }else{
        if(navigator.userAgent.match(/(iPad|iPhone|iPod)/g)){
            setupWebViewJavascriptBridge(function(bridge) {
                bridge.callHandler('px_iosSideHandler', params , function responseCallback(Data) {
                    if(ajaxFunc=='ajaxMyExchange'){
                        ajaxMyExchange(Data);
                    }
                    if(ajaxFunc=='ajaxExchange'){
                        ajaxExchange(Data);
                    }
                })
            })
        }else{
            window.clickListener.fanxinrsa(ajaxFunc,params);
        }
    }
}
