define(function(require, exports,modules) {
    var App = {};
    function layout(){
        
    }
    App.init = function(){
        addEvent();
        layout();
    }

    function addEvent(){
        $('.btnShowDetail').on('touchend',function(e){
            var $this = $(this);
            if($this.html()=='收起'){
                $this.html('详情');
                $this.siblings('.detail').hide();
            }else{
                $this.html('收起');
                $this.siblings('.detail').show();
            }
            e.preventDefault();
        })
       
    }
    modules.exports = App;
});
