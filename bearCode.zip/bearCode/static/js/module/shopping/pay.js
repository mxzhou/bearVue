define(function(require, exports,modules) {
    var App = {};
    var totalCost = 0,money=0,redEnvelopeList=[];
    var redEnvelope = {
        money: 0,
        id: 0
    }
    App.init = function(){

        getList();        
        addEvent();

    }
    var GoodsList;
    function getList(){
        Zepto.ajax({
            url: ApiPrefix+'/cart/detail',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid},
            cache: false,
            success: function(data){
              log(data)
              if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    var data = data.data;
                    totalCost = data.totalCost;
                    $('#totalCost').html(totalCost)
                    var $list = $('.shopping-list');
                    var str = '';
                    var list  = data.goodsList;
                    GoodsList = list;
                    MZ.cart.update(data.total);
                    MZ.cart.init();
                    if(totalCost==0){
                        location.href = 'list.html';
                        return;
                    }
                    var $table = $('#tableData');
                    var str = '<table class="table">'+
                            '<thead>'+
                            '  <tr>'+
                            '    <th colspan="2"><div class="fr">数量: <span class="blue">'+data.total+'</span></div>注：请确认如下订单明细 </th>'+
                            '  </tr>'+
                            '</thead>'+
                            '<tbody>';
                    for(var i in list){
                        var item = list[i];
                        str+='<tr><td>'+item.goodsName+'</td><td width="170" align="right"><span class="red">'+item.number+'</span>人次</td></tr>'
                    }
                    //查询清单红包
                    cartRedEnvelope(list);
                    str+='</tbody></table>';
                    $table.html(str);
                    getConsumeMoney();
                }else{
                    MZ.alert({content: data.errorMessage});
                }
           
            },
            error: function(){
          
            }
        })
    }
    function cartRedEnvelope(list){
        var goodsList = [];
        for(var i in list){
            goodsList[i]= {
                goodsId:list[i].goodsId,
                total: list[i].number
            }
        }
        log(goodsList)
        var data = {token:MZ.utils.getToken(),kgUid:kgUid, goodIds:JSON.stringify(goodsList)};
        Zepto.ajax({
            url: ApiPrefix+'/cart/redEnvelope',
            type: 'post',
            data: data,
            success: function(data){
                if(data.errorMessage=='token不合法'){
                    MZ.wechat.checkLogin(data);
                    return;
                }
                if(data.status==1){
                    var list = data.data;
                    /*list=[{
                          id:1212,
                          name:'新手红包',
                          money:5,
                          limitSubMoney:1,
                          typeName:'全品类',
                          limitTime:'2015-07-02至2015-07-05',
                          useStatus:0
                    },{
                          id:12122,
                          name:'新手红包1',
                          money:1,
                          limitSubMoney:2,
                          typeName:'全品类',
                          limitTime:'2015-07-03至2015-07-07',
                          useStatus:0
                    }]*/
                    redEnvelopeList = list;
                    if(list.length!=0){
                        $('#btnShowBagList .fr').html(list.length+'个可用红包<span class="icon icon-right-nav"></span>');
                    }
                    renderRedList();
                }else{
                    MZ.alert({content: data.errorMessage});
                }
            }
        })
    }
    function renderRedList(){
        var str = '';      
        for(var i in redEnvelopeList){
            var item = redEnvelopeList[i];
            str += '<li data-money="'+item.money+'" data-id="'+item.id+'"><span class="fl"><i>￥</i>'+item.money+'</span>'+
                    '  <h3><span class="fr">满'+item.limitSubMoney+'元可用</span>'+item.name+'</h3>'+
                    '  <span class="type">'+item.typeName+'</span>'+
                    '  <p>'+item.limitTime+' 可用</p></li>';
        }
        $('.bag-list').html(str);
    }
    function getConsumeMoney(){
        Zepto.ajax({
            url: ApiPrefix+'/user/consumeMoney',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid},
            cache: false,
            success: function(data){
              if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    money = data.data;
                    $('#money').html(money);
                    initPay();

                }else{
                    MZ.alert({content: data.errorMessage});
                }
           
            },
            error: function(){
          
            }
        })
    }
    function initPay(type){

        if(redEnvelope.money!=0 && !$('#jsUse').hasClass('active')){
            $('#otherPayNum').html(totalCost-redEnvelope.money);     
            return;
        }
        //type=2 选择不使用红包
        if(type==2 && !$('#jsUse').hasClass('active') && $('#wechatPay').hasClass('active')){
            $('#otherPayNum').html(totalCost-redEnvelope.money);
            return;
        }
        if(money<=0){
            $('#jsUse').hide();
            $('#otherPayNum').html(totalCost-redEnvelope.money);
            $('#useComsume').remove();
        }else {
            $('#jsUse').addClass('active');
        }
        if(totalCost>money){
            $('#otherPay').add('#jsList').show();
            $('#wechatPay').addClass('active');
            if(totalCost-money>redEnvelope.money){
                $('#useComsume').html(money+"元").show();
                $('#otherPayNum').html(totalCost-money-redEnvelope.money);
            }else{
                $('#otherPay').add('#jsList').hide();
                $('#wechatPay').removeClass('active');
                if(totalCost-money==redEnvelope.money){
                    $('#useComsume').html(money+"元").show();
                }else{
                    $('#useComsume').html(totalCost-redEnvelope.money+"元").show();
                }
            }
        }else{
            $('#otherPay').hide();
            $('#wechatPay').removeClass('active');
            $('#useComsume').html(totalCost-redEnvelope.money+"元").show();
            $('#otherPayNum').html(0);
        }
    }
    function addEvent(){
        $('.for-slide .hd').on('click',function(){
            var $this = $(this),
                $parent = $this.parent('.for-slide');
            $parent.toggleClass('active');
            if($parent.hasClass('active')){
                $this.find('.icon').attr('class','icon icon-up-nav');
            }else{
                $this.find('.icon').attr('class','icon icon-down-nav');
            }
        })
        $('#jsShowlIST').on('click',function(){
            var $this = $(this);
            $this.toggleClass('active');
            $('#jsList').toggle();
            if($this.hasClass('active')){
                $this.find('.icon').attr('class','icon icon-up-nav');
            }else{
                $this.find('.icon').attr('class','icon icon-down-nav');
            }
        })
        $('#jsUse').on('click',function(){
            var $this = $(this);
            $this.toggleClass('active');
            if($this.hasClass('active')){
                if(totalCost>money){
                    if(totalCost-money-redEnvelope.money==0){
                        $('#jsList').add('#otherPay').hide();
                        $('#wechatPay').removeClass('active');
                    }else{
                        $('#jsList').add('#otherPay').show();
                        $('#wechatPay').addClass('active');
                    }
                    $('#otherPayNum').html(totalCost-money-redEnvelope.money);
                    $('#useComsume').html(money+"元").show();
                }else{
                    $('#otherPayNum').html(0);
                    $('#useComsume').html(totalCost-redEnvelope.money+"元").show();
                    $('#jsList').hide();
                    $('#otherPay').hide();
                    $('#wechatPay').removeClass('active');
                }
            }else{
                $('#jsList').show();
                $('#otherPay').show();
                $('#wechatPay').addClass('active');
                $('#useComsume').html("0元").hide();
                $('#otherPayNum').html(totalCost-redEnvelope.money);
            }
        })
        $('#wechatPay').on('click',function(){
            var $this = $(this);
            $this.toggleClass('active');
            if($this.hasClass('active')){
                $('#otherPay').show();
                if(totalCost-redEnvelope.money>money){   
                    if($('#jsUse').hasClass('active')){
                        //勾选使用余额
                        $('#otherPayNum').html(totalCost-money-redEnvelope.money);
                        $('#jsList').show();
                        $('#wechatPay').addClass('active');
                    }else{
                        //不使用余额
                        $('#otherPayNum').html(totalCost-redEnvelope.money);
                        $('#jsList').show();
                        $('#wechatPay').addClass('active');
                    }
                }else{
                    $('#otherPayNum').html(totalCost-redEnvelope.money);
                    $('#useComsume').html(0+"元").hide();
                    $('#jsUse').removeClass('active');
                    //$('#jsList').hide();
                    //$('#wechatPay').removeClass('active');
                }
            }else{
                $('#jsUse').addClass('active');
                if(totalCost>money && money!=0){
                    if(totalCost-money>redEnvelope.money){
                        $('#otherPayNum').html(totalCost-money-redEnvelope.money);
                        $('#jsList').show();
                        $('#useComsume').html(money+"元").show();
                        $('#wechatPay').addClass('active');
                    }else{
                        $('#jsList').hide();
                        $('#otherPay').hide();
                        $('#wechatPay').removeClass('active');
                        $('#otherPayNum').html(0);
                        if(totalCost-money==redEnvelope.money){
                            $('#useComsume').html(money+"元").show();
                        }else{
                            $('#useComsume').html(totalCost-redEnvelope.money+"元").show();
                        }
                    }
                }else{
                    $('#otherPay').hide();
                    $('#otherPayNum').html(0);
                    $('#otherPay').hide();
                    $('#useComsume').html(totalCost+"元").show();
                    $('#jsList').hide();
                    $('#otherPay').hide();
                    $('#wechatPay').removeClass('active');
                }
                
            }
        })
        $('#btnPay').on('click',function(e){
            var goodslist = [];
            var $this = $(this);
            if($this.hasClass('isLoading'))return;
            for(var i in GoodsList){
                goodslist[i]= {
                    goodsId:GoodsList[i].goodsId,
                    total: GoodsList[i].number
                }
            }
            var otherPayType=-1;
            if($('#jsUse').hasClass('active')){
                otherPayType = 0;
            }
            if($('#wechatPay').hasClass('active')){
                otherPayType = 5;
            }
            if(otherPayType==-1){
                MZ.alert({content:"至少选择一种支付方式"});
                return;
            }
            var load = new MZ.loading();
            $this.addClass('isLoading');
            var toast = new MZ.toast({content:'提交支付中...'});
            if($('#jsUse').hasClass('active') && $('#wechatPay').hasClass('active')){
                data = {token:MZ.utils.getToken(),kgUid:kgUid,redEnvelopeId:redEnvelope.id, goodIds:JSON.stringify(goodslist),otherPayType:otherPayType,consumeCost:$('#useComsume').html().replace('元','')}
            }else{
                data = {token:MZ.utils.getToken(),kgUid:kgUid,redEnvelopeId:redEnvelope.id, goodIds:JSON.stringify(goodslist),otherPayType:otherPayType}
            }
            Zepto.ajax({
                url: ApiPrefix+'/cart/submit',
                type: 'post',
                data: data,
                dataType:'json',
                cache: false,
                success: function(data){
                    if(data.errorMessage=='token不合法'){
                        MZ.wechat.checkLogin(data);
                        return;
                    }
                    load.hide();
                    if(data.status==1){
                    	 if(otherPayType==0){
                             localStorage.setItem('payResult',JSON.stringify(data));
                             location.href='pay-result.html?itemId='+data.data.orderNo;
	                     }else{
	                             var wxgzh = data.data.wxgzh;
	                             if(wxgzh.data.error_code==0){
	                             var payjson =JSON.parse( wxgzh.data.data);
	                             function jsApiCall() {
	                                WeixinJSBridge.invoke(
	                                    'getBrandWCPayRequest',
	                                    payjson,
	                                    function (res) {
	                                    if (res.err_msg == "get_brand_wcpay_request:ok") {
	                                        location.href = "pay-result.html?order_no="+data.data.payOrderNo;
	                                    } else {
	                                        if (res.err_msg != "get_brand_wcpay_request:cancel") {
	                                            MZ.alert({content:'请再试一次'});
	                                        }
	                                    }
	                                });
	                             }
	                             function callpay() {
	                                if (typeof WeixinJSBridge == "undefined") {
	                                    if (document.addEventListener) {
	                                        document.addEventListener('WeixinJSBridgeReady', jsApiCall, false);
	                                    } else if (document.attachEvent) {
	                                        document.attachEvent('WeixinJSBridgeReady', jsApiCall);
	                                        document.attachEvent('onWeixinJSBridgeReady', jsApiCall);
	                                    }
	                                } else {
	                                    jsApiCall();
	                                }
	                             }
	                             callpay();
                           }else{
                               MZ.alert({content: wxgzh.data.error_msg});
                           }
                    	}
                    }else{
                    	MZ.alert({content:data.errorMessage})
                    }
                    
                    toast.hide();
                    $this.removeClass('isLoading');
                },
                error: function(){
                    load.hide();
                    $this.removeClass('isLoading');
                }
            })
            e.preventDefault();
        })  
        //显示红包
        $('#btnShowBagList').on('click touchend',function(e){
            e.preventDefault();
            var $this = $(this);
            if($this.find('.icon-right-nav').length!=0){
                $('#pageBag').addClass('active');
            }
        })
        //关闭红包层
        $('.hideBag').on('touchend',function(e){
            e.preventDefault();
            $('#btnShowBagList .fr').html(redEnvelopeList.length+'个可用红包<span class="icon icon-right-nav"></span>');
            $('#pageBag').removeClass('active');
            redEnvelope.money = 0;
            redEnvelope.id = 0;
            initPay(2);
        })
        //选择红包
        $('.bag-list').delegate('li','click touchend',function(e){
            e.preventDefault();
            var $this = $(this);
            var moneyTemp = $this.attr('data-money');
            var $jsUse = $('#jsUse'),
                $wechatPay = $('#wechatPay');
            redEnvelope.money = $this.attr('data-money');
            redEnvelope.id = $this.attr('data-id');
            $('#btnShowBagList .fr').html('<span class="red">-'+redEnvelope.money+' 元 </span><span class="icon icon-right-nav"></span>');
            initPay();
            $('#pageBag').removeClass('active');
        })
    }
    function ajaxWechatPay(data){
        var data = data.data;
        Zepto.getJSON({
            url: data.wxgzh,
            cache: false,
            success: function(data){
                if(data.status==1){
                   //
                   
                }else{
                    MZ.alert({content: data.errorMessage});
                }
           
            },
            error: function(){
            }
        })
    }
    modules.exports = App;
});
