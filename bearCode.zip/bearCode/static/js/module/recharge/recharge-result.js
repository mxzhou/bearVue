define(function(require, exports,modules) {
    var App = {};
    var totalCost = 0,money=0;
    var orderNo;
    App.init = function(){
        orderNo = MZ.utils.getQueryString('order_no');
        if(orderNo == null || orderNo == 'null'){
            MZ.alert({content:'查询内容不正确',callback:function(){
                location.href = 'recharge.html';
            }})
        }else{
            checkPayResult();
        }
        //MZ.showPrize({id:1,number:23,name:'2343234'});
    }
    function checkPayResult(){
        Zepto.ajax({
            url: ApiPrefix+'/pay/result/get',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,payOrderNo:orderNo},
            cache: false,
            success: function(data){
                log(data)
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                $('#payStatus').hide();
                if(data.status==1){
                    $('#paySuccess').show();
                    $('#addMoney').html(data.data.addMoney);
                }else{
                    $('#payFail').show();
                    //MZ.alert({content: data.errorMessage});
                }
           
            },
            error: function(){
          
            }
        })
    }    
   
    modules.exports = App;
});
