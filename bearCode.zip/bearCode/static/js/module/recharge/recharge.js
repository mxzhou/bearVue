define(function(require, exports,modules) {
    var App = {};
    App.init = function(){

        addEvent();

    }

    function addEvent(){
        $('.jsItem').on('click',function(){
          var $this = $(this);
          if($this.find('input').length!=0){
            $(this).addClass('active').siblings('.jsItem').removeClass('active');
          }else{
            $(this).toggleClass('active').siblings('.jsItem').removeClass('active');
          }
        })
        $('#money').on('blur',function(){
          var $this = $(this);
          var value = $this.val();
          if(!/^[1-9]\d*$/g.test(value)){
            MZ.alert({content:'请输入数字'});
            $this.val(1);    
          }
          if(value<1){
            $this.val(1);            
          }
       })
        $('#btnRecharge').on('touchend',function(e){
            var $active = $('.jsItem.active');
            e.preventDefault();
            if($active.length==0){
                MZ.alert({content:'请先选择金额'});
                return;
            }
            var money=0;
            if($active.find('input').length!=0){
                var money = $('#money').val().replace(/\s/g,'');
                if(!/^[1-9]\d*$/g.test(money)){
                  MZ.alert({content:'请输入数字'});
                  $('#money').val(1);   
                  return;
                }
                if(money==''){
                    MZ.alert({content:'金额不能为空'});
                    return;
                }
                if(money<1){
                  MZ.alert({content:'最少充值1元'});
                  $('#money').val(1); 
                  return;
                }
            }else{
                money = $active.text();
            }
            Zepto.ajax({
                url: ApiPrefix+'/pay/submit',
                type: 'post',
                data: {token:MZ.utils.getToken(),kgUid:kgUid,money:money,payType:5,source:'wechat'},
                dataType:'json',
                cache: false,
                success: function(data){
                  if(data.errorMessage=='token不合法'){
                    MZ.wechat.checkLogin(data);
                    return;
                  }
                	if(data.status==1){
                		var wxgzh = data.data.wxgzh;
                        if(wxgzh.data.error_code==0){
                        var payjson =JSON.parse( wxgzh.data.data);
                        function jsApiCall() {
                           WeixinJSBridge.invoke(
                               'getBrandWCPayRequest',
                               payjson,
                               function (res) {
                               if (res.err_msg == "get_brand_wcpay_request:ok") {
                                   location.href = "../recharge/recharge-result.html?order_no="+data.data.payOrderNo;
                               } else {
                                   if (res.err_msg != "get_brand_wcpay_request:cancel") {
                                       MZ.alert({content:'请再试一次'});
                                   }
                               }
                           });
                        }
                        function callpay() {
                           if (typeof WeixinJSBridge == "undefined") {
                               if (document.addEventListener) {
                                   document.addEventListener('WeixinJSBridgeReady', jsApiCall, false);
                               } else if (document.attachEvent) {
                                   document.attachEvent('WeixinJSBridgeReady', jsApiCall);
                                   document.attachEvent('onWeixinJSBridgeReady', jsApiCall);
                               }
                           } else {
                               jsApiCall();
                           }
                        }
                        callpay();
                     }else{
                         MZ.alert({content: wxgzh.data.error_msg});
                     }
                   }else{
                   	MZ.alert({content:data.errorMessage})
                   }
                         
                },
                error: function(){
              
                }
            })
            e.preventDefault();
        })
    }
    modules.exports = App;
});
