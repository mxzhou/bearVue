define(function(require, exports,modules) {
    var App = {};
    var win = window,
    doc = win.document;
    var LoadMore = require('widgets/load-more');
    function layout(){
        
    }
    App.init = function(){
        addEvent();
        layout();
        loadmore();
        getList();
    }
    function loadmore(){
        //初始化下拉加载更多
        $(document).on('scroll touchmove',function(){
              if(HasNoMore){
                $('.loading-more').hide();
                return;
              }
              if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
                  if($('.loading-more').length==0){
                      getList();
                  }
              }
          });
    }
    var Loading = false;
    var HasNoMore = false;
    var pageSize=10;
    var Page = 1;
    var servertime;
    var lastId = 0;

    function getList(){
        if(Loading)return;
        Loading = true;
        Zepto.ajax({
            url: ApiPrefix+'/user/win/log',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,targetKgUid:0,"pageNumber": Page,"pageSize": pageSize},
            cache: false,
            success: function(data){
              if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
              servertime = data.servertime ;
                if(data.status==1){
                  var $list = $('.for-good-list');
                  var str = '';
                  var list  = data.data.winLogList;
                  if(list.length <pageSize){
                    HasNoMore = true;
                  }
                  for(var i in list) {
                      var item = list[i];
                      str += '<li class="table-view-cell media">'+
                          '<a class="navigate-right" href="prize-detail.html?id='+item.id+'">'+
                          '  <div class="media-body">'+
                          '    <div class="pic-left"><img class="media-object pull-left" src="'+ImgBlank+'" data-echo="'+item.coverImgUrl+'"></div>'+
                          '    <div class="media-right">'+
                          '      <div class="btnShare" data-joinNumber="'+item.joinNumber+'" data-id="'+item.id+'"><i class="icon icon-share-wechat"></i></div>'+
                          '    </div>'+
                          '    <h3>'+item.goodsName+'</h3>'+
                          '    <p class="item">期号: '+item.id+'</p>'+
                          '    <p class="item">总需:'+item.needNumber+'</p>'+
                          '    <p class="item">幸运号码: <span class="red">'+item.winCode+'</span> </p>'+
                          '    <p class="item">本期参与: <span class="red">'+item.joinNumber+'</span>人次 </p>'+
                          '    <p class="item">揭晓时间: '+MZ.utils.formatDate(item.openTime)+'</p>'+
                          '  </div>'+
                          '</a>'+
                        '</li>';
                      if(item.orderStatus==0){
                        //未下单
                        str+='<li class="table-view-cell media">'+
                         ' <div class="navigate-right">'+
                         '   <div class="fr"><a href="address.html?robid='+item.id+'" class="btn btn-blue-transparent">选择收货地址</a></div>'+
                         '   <div class="fl"><span class="gray">好运降临</span></div>'+
                         ' </div>'+
                        '</li>';
                      }else if(item.orderStatus == 1){
                        //下单
                        str+='<li class="table-view-cell media">'+
                         ' <div class="navigate-right">'+
                         '   <div class="fr"></div>'+
                         '   <div class="fl"><span class="gray">等待商品派发</span></div>'+
                         ' </div>'+
                        '</li>';
                      }else if(item.orderStatus == 2){
                        //出货
                        str+='<li class="table-view-cell media">'+
                         ' <div class="navigate-right">'+
                         '   <div class="fr"></div>'+
                         '   <div class="fl"><span class="gray">等待商品派发</span></div>'+
                         ' </div>'+
                        '</li>';
                      }else if(item.orderStatus == 3){
                        //已签收
                        /*str+='<li class="table-view-cell media">'+
                         ' <div class="navigate-right">'+
                         '   <div class="fr"><a href="../discover/rule.html?goodsRobId='+item.id+'" class="btn btn-blue-transparent">我要晒单</a></div>'+
                         '   <div class="fl"><span class="gray">已签收</span></div>'+
                         ' </div>'+
                        '</li>';*/
                        str+='<li class="table-view-cell media">'+
                         ' <div class="navigate-right">'+
                         '   <div class="fr"><a href="../discover/rule.html?goodsRobId='+item.id+'" class="btn btn-blue-transparent">我要晒单</a></div>'+
                         '   <div class="fl"><span class="gray">商品已发货</span></div>'+
                         ' </div>'+
                        '</li>';
                      }else if(item.orderStatus == 5){
                        //已晒单
                        str+='<li class="table-view-cell media">'+
                         ' <div class="navigate-right">'+
                         '   <div class="fr"></div>'+
                         '   <div class="fl"><span class="gray">已晒单</span></div>'+
                         ' </div>'+
                        '</li>';
                      }
                        
                  }
                  if(list.length!=0){
                    lastId = list[0].id;
                  }
                  $list.append(str);
                  if(Page==1 && (list.length==0||list==null)){
                    var str = '<div class="cart-empty" style="margin-top:30%;">'+
                         ' <i class="icon icon-cartempty"></i>'+
                         ' <h3>您还没有幸运记录</h3>'+
                         ' <a href="../index.html" class="btn btn-red-transparent">立即夺宝</a>'+
                        '</div>';
                    $('.footer-icon').hide();
                    $('body').append(str);
                  }else if(list.length<pageSize){
                   HasNoMore = true;
                  }
                  //图片延迟加载
                  MZ.utils.initEcho();
                  Page++;
              }else{
                log(data.errorMessage)
                  //MZ.alert({content: data.errorMessage});
              }
              Loading = false;
            },
            error: function(){
              Loading = false;
            }
        })
    }       
    function addEvent(){
        //分享
        $(document).delegate('.btnShare','touchend',function(e){
          MZ.showShare();
          var $this = $(this);
          var goodsName = $this.parents('li').find('h3').html();
          var useMoney = $this.attr('data-joinNumber');
          var rodid = $this.attr('data-id');
          e.stopPropagation();
          e.preventDefault();
          MZ.wechat.init({
             title: '我在胖熊1元买中奖啦~',
             desc: '我刚刚花'+useMoney+'元就买到了'+goodsName+',你也来试试吧',
             link: Domain+'/api/goodswin/'+rodid+'/share',
             imgUrl: JSSDK_ICONSTR,
             success: function(){
                Zepto.ajax({
                  url: ApiPrefix+'/user/share',
                  type: 'POST',
                  data: {token:MZ.utils.getToken(),kgUid:kgUid},
                  success: function(data){
                   /* MZ.ajax.getShareResult({
                      
                    })*/
                  }
                })
                $('#pageShare').removeClass('active');
             }
          })
        })
        //规则 
        $('.banner-rule').on('click touchend',function(e){
          e.preventDefault();
          MZ.alert({title:'<span style="font-weight:bold;color:#333;">规则说明</span>',content:'<div style="text-align:left;padding: 10px;"><p>1、将中奖喜悦分享到微信朋友圈、QQ空间、微博，即可获得红包</p><p>2、每次中奖只有第一次分享可获得红包</p><p style="margin-bottom:0;padding-bottom:0;">3、红包金额最高可得千元</p></div>'});
        })
    }
    
    modules.exports = App;
});
