define(function(require, exports,modules) {

	var Cart = {};

	Cart.init = function () {
		var list = localStorage.getItem('shoppingList');
		if(list==null){

		}
	};
	cart.getCartDetail = function(){
		
	}
	modules.exports = Loading;
});
