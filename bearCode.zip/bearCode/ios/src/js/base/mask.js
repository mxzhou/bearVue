;MZ.mask = {

	show : function($mask,type) {
		var $maskInner = $mask.find('.mask-inner'),
			$maskBg = $mask.find('.mask-bg');
		$mask.css({'height':window.innerHeight, 'display':'block'}).addClass('fadeIn');
		switch(type){
			case 'slideDown':
				$maskInner.addClass('slideDown');
				setTimeout(function(){
					$maskInner.addClass('in');
				},20)

		}
    },
    hide: function($mask,type) {
    	var $maskInner = $mask.find('.mask-inner'),
			$maskBg = $mask.find('.mask-bg');
		$mask.removeClass('fadeIn');
		$maskInner.removeClass('slideDown').removeClass('in');
		$mask.hide();
    }
    
}