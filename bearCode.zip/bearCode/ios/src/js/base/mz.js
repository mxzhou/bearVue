var MZ = (function(obj){
	
	return obj;
})(MZ || {})
var log = console.log.bind(console);
var Domain = document.domain;
var TEST = false;
if(/((?:(?:25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))\.){3}(?:25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d))))/g.test(Domain)){
	var ApiPrefix = 'http://'+Domain+':8811/api/weixin';
	var Prefix = 'http://'+Domain+':8811/api/wechat';
	var ImgBlank = 'http://'+Domain+':8811/api/wechat/src/images/blank.png';
	var ImgUser = 'http://'+Domain+':8811/api/wechat/src/images/default.png';
	var kgUid = 638535348;
  TEST = true;
}else{
	var ApiPrefix = 'http://'+Domain+'/api/weixin';
	var Prefix = 'http://'+Domain+'/api/wechat';
	var ImgBlank = 'http://'+Domain+'/api/wechat/src/images/blank.png';
	var ImgUser = 'http://'+Domain+'/api/wechat/src/images/default.png';
	var kgUid = 0;
  TEST = false;
}
var JSSDK_TITLE = '胖熊一元买',
	JSSDK_DESCSTR = '胖熊一元实现梦想',
	JSSDK_LINKSTR = Domain+'/api/wechat/views/index.html',
	JSSDK_ICONSTR = 'http://'+Domain+'/api/wechat/src/images/default.png';
