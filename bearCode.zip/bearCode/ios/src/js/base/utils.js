;MZ.utils = {

    getQueryString : function(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return r[2]; return null;
    },
    leaveTime: function(startTime,endTime){
        if(startTime>=endTime){
            return 0;
        }else{
            var t =  endTime - startTime;
            var h = 60*60*1000,
                m = 60*1000,
                s = 1000;
            var H = parseInt(t/h),
                M = parseInt((t-H*h)/m),
                S = parseInt((t-H*h-M*m)/s),
                HS = parseInt((t-H*h-M*m-S*s)/10);
            return intNumber(M)+":"+intNumber(S)+":"+intNumber(HS);
        }
        
    },
    formatDate: function(dt){
      if(/-/.test(dt)){
        var dt = new Date(dt.replace(/-/g,'/'));
      }else{
        var dt = new Date(dt);
      }
      return dt.getFullYear()+"-"+(dt.getMonth()+1)+"-"+dt.getDate()+" "+intNumber(dt.getHours())+":"+intNumber(dt.getMinutes())+":"+intNumber(dt.getSeconds());
    },
    formatFromToday: function(dtNow,dt){
      var dtNow = new Date(dtNow);
      if(/-/.test(dt)){
        var dt = new Date(dt.replace(/-/g,'/'));
      }else{
        var dt = new Date(dt);
      }
      var dt1 = new Date(dtNow.getTime() - 24*60*60*1000);
      if(dt.getFullYear()==dtNow.getFullYear() && dt.getMonth()==dtNow.getMonth() && dt.getDate()==dtNow.getDate()){
        return '今天'+intNumber(dt.getHours())+":"+intNumber(dt.getMinutes());
      }else {
        return dt.getFullYear()+"-"+(dt.getMonth()+1)+"-"+dt.getDate()+" "+intNumber(dt.getHours())+":"+intNumber(dt.getMinutes());
      }    
    },
    joinTime: function(t){
        var dt = new Date(t);
        return dt.getFullYear()+"-"+(dt.getMonth()+1)+"-"+dt.getDate()+" "+intNumber(dt.getHours())+":"+intNumber(dt.getMinutes())+":"+intNumber(dt.getSeconds())+"."+intNumberMil(dt.getMilliseconds());
    },
    initEcho: function(){
        echo.init({
            offset: 200,
            throttle: 250,
            unload: false,
            callback: function (element, op) {
                //console.log(element, 'has been', op + 'ed')
            }
        });
    },
    getToken: function(){
      return sessionStorage.getItem('wxtoken');
    }
    
};
function intNumber(n){
    return n<10?'0'+n:n;
}
function intNumberMil(n){
    return n<100?'0'+n:n;
}
