;MZ.wechat = {
  login: function(){
    Zepto.ajax({
      url: ApiPrefix+'/getCodeUrl',
      type: 'post',
      data: {url:encodeURIComponent(location.href.split('#')[0]),code:MZ.utils.getQueryString('code')},
      cache: false,
      async: false,
      success: function(data){
          if(data.errorCode==410018){
            MZ.alert({content:'<div style="padding:30px 0;">您的账号已被禁用</div>',footer:true});
            return;
          }
          if(data.errorCode==410019){
            MZ.alert({content:'<div style="padding:30px 0;">暂未开放，升级中...</div>',footer:true});
            return;
          }
          if(data.success == 1){
            alert(data.wxtoken)
            sessionStorage.setItem('wxtoken',data.wxtoken);            
          }else{
            if(!TEST){
              location.href = data.getCodeUrl;
            }
          }
      },
      error: function(){
      }
    })
  },
  getSignature: function(){
    Zepto.ajax({
      url: ApiPrefix+'/getSignature',
      type: 'post',
      data: {url:encodeURIComponent(location.href.split('#')[0])},
      cache: false,
      success: function(data){
          if(data.success == 1){            
            initJSSDK(data);
          }
      },
      error: function(){
      }
    })
  },
  checkLogin: function(data){
    if(data.errorMessage=='token不合法'){
      if($('.weui_dialog_confirm').length==0){
        MZ.alert({content:'欢迎回到酷狗一元买',text:'马上夺宝',callback:function(){
          MZ.wechat.login();
        }});
      }
    }
  },
  /**
   * 初始化微信分享配置
   */
   /*MZ.wechat.init({
    title: 'title',//不可为空
    desc: 'desc',//不可为空
    link: 'link',//不可为空
    imgUrl: 'imgUrl',//不可为空
    trigger: function(){},//可为空
    success: function(){},//可为空
    cancel: function(){},//可为空
    fail: function(){}//可为空
  })*/
  init: function(config){
    _czc = _czc || {};
    if(!config){
      alert('config undefined');
    }
    wx.ready(function () {
      //分享给朋友
      wx.onMenuShareAppMessage({
        title: config.title,
        desc: config.desc,
        link: ''+config.link+'',
        imgUrl: ''+config.imgUrl+'',
        trigger: function (res) {
          _czc.push(["_trackEvent", "点击弹出分享给朋友", "click", 'startup', 1]);
          config.trigger && config.trigger();
        },
        success: function (res) {
          _czc.push(["_trackEvent", "分享给朋友", "click", 'startup', 1]);
          config.success && config.success();
        },
        cancel: function (res) {
          _czc.push(["_trackEvent", "取消分享给朋友", "click", 'startup', 1]);
          config.cancel && config.cancel();
        },
        fail: function (res) {
          _czc.push(["_trackEvent", "分享到朋友失败", "click", 'startup', 1]);
          config.fail && config.fail();
        }
      });
      //分享到朋友圈
      wx.onMenuShareTimeline({
        title: config.title,
        desc: config.desc,
        link: ''+config.link+'',
        imgUrl: ''+config.imgUrl+'',
        trigger: function (res) {
          _czc.push(["_trackEvent", "点击弹出分享到朋友圈", "click", 'startup', 1]);
          config.trigger && config.trigger();
        },
        success: function (res) {
          _czc.push(["_trackEvent", "成功分享到朋友圈", "click", 'startup', 1]);
    config.success && config.success();
        },
        cancel: function (res) {
          _czc.push(["_trackEvent", "取消分享到朋友圈", "click", 'startup', 1]);
          config.cancel && config.cancel();
        },
        fail: function (res) {
          _czc.push(["_trackEvent", "分享到朋友圈失败", "click", 'startup', 1]);
          config.fail && config.fail();
        }
      });
  })
  wx.error(function (res) {
    alert(res.errMsg);
  });
  }

}
$(document).on('ajaxBeforeSend', function(e, xhr, options){
 /* if(sessionStorage.getItem('wxtoken')==null){
    MZ.wechat.login();    
  }*/
})
if(sessionStorage.getItem('wxtoken')==null){
  if(typeof noLogin == 'undefined'){
    MZ.wechat.login();
  }
}

function initJSSDK(data){
  if(!data)return;
  wx.config({
      debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
      appId: data.appId, // 必填，公众号的唯一标识
      timestamp: data.timestamp, // 必填，生成签名的时间戳
      nonceStr: data.nonceStr,   // 必填，生成签名的随机串
      signature: data.signature, // 必填，签名，见附录1
      jsApiList: [
          'onMenuShareTimeline',
          'onMenuShareAppMessage',
          'onMenuShareQQ',
          'onMenuShareWeibo'
      ] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
  });
  MZ.wechat.init({
     title: JSSDK_TITLE,
     desc: JSSDK_DESCSTR,
     link: JSSDK_LINKSTR,
     imgUrl: JSSDK_ICONSTR
  })
}
MZ.wechat.getSignature();
