;MZ.browser = {
	sticky: function(){
			var a,b="-webkit-sticky",
			c=document.createElement("i");
			return c.style.position=b,a=c.style.position,c=null,a===b
		}(),
	isIos: navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? !0 : !1,
	isWechat: navigator.userAgent.toLowerCase().match(/MicroMessenger/i)=="micromessenger" ? !0 : !1,
	isAndroid: -1 < navigator.userAgent.indexOf("Android"),
	isMobile: /AppleWebKit.*Mobile/i.test(navigator.userAgent) || (/MIDP|SymbianOS|NOKIA|SAMSUNG|LG|NEC|TCL|Alcatel|BIRD|DBTEL|Dopod|PHILIPS|HAIER|LENOVO|MOT-|Nokia|SonyEricsson|SIE-|Amoi|ZTE/.test(navigator.userAgent))
}
