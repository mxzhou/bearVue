;MZ.ajax = {

	getWin : function(params) {
		Zepto.ajax({
        type:'post',
        url: ApiPrefix+'/goods/win',
        data: {token:MZ.utils.getToken(),kgUid:kgUid,id:params.robid},
        dataType:'json',
            cache: false,
        success: function(data){
          if(data.errorMessage=='token不合法'){
            MZ.wechat.checkLogin(data);
            return;
          }
          log(data)
          if(data.status==1){
            params.callback(data);
          }else{
            MZ.alert({content:'查询中奖信息出错，请稍后再试'})
          }
        },
        error: function(err){
            MZ.alert({content:'网络连接出错，请稍后再试'})
        }
      })
  },
  getNewUser: function(){
    //新手红包
    Zepto.ajax({
        type:'post',
        url: ApiPrefix+'/user/newRedEnvelope',
        data: {token:MZ.utils.getToken(),kgUid:kgUid},
        dataType:'json',
        cache: false,
        success: function(data){
          if(data.errorMessage=='token不合法'){
            MZ.wechat.checkLogin(data);
            return;
          }
          if(data.status==1){
            var info = data.data;
            if(info.registerStatus==2){
              MZ.alert({content:info.failMsg});
            }
            if(info.registerStatus==1){
              var list = info.redEnvelopeList;
              /*list = [{
                        "id": 1,
                        "name": "过年红包",
                        "money": 50,
                        "limitSubMoney": 50,
                        "limitTime": "2016-04-27至2016-04-30",
                        "typeName": "iphone类",
                        "useStatus": 0
                    }]*/
              if(list.length!=0){
                var str = '';
                for(var i in list){
                  var item = list[i];
                  str += '<li><span class="fl"><i>￥</i>'+item.money+'</span><h3>'+item.name+'</h3><span class="type">'+item.typeName+'</span><p>满'+item.limitSubMoney+'元可用</p></li>';
                }
                MZ.showLuckyBag(str);
              }
            }
            localStorage.setItem('newUser',false);
          }
        },
        error: function(err){
        }
      })
  },
  getShareResult: function(config){
    var platform = config.platform, 
        type = config.type,
        id = config.id,
        source = config.source,
        shareUrl = location.href;
    //分享获得红包
    Zepto.ajax({
        type:'post',
        url: ApiPrefix+'/user/share',
        data: {token:MZ.utils.getToken(),kgUid:kgUid,platform:platform,id:id,type:type,shareUrl:shareUrl,source:source},
        dataType:'json',
        cache: false,
        success: function(data){
          if(data.errorMessage=='token不合法'){
            MZ.wechat.checkLogin(data);
            return;
          }
          if(data.status==1){
            var info = data.data;
            if(info.id!=0){
              MZ.showShareResult(info);
            }
          }else{
            MZ.alert({content:data.errorMessage});
          }
        },
        error: function(err){
        }
      })
  }
};
//分享获得红包
//MZ.ajax.getShareResult({platform:'朋友圈',type:1,id:120023,source:'wechat'});
//新用户则请求获取新手红包接口
if(localStorage){
  MZ.ajax.getNewUser();
  if(localStorage.getItem('newUser')==null){  
    if(typeof noLogin == 'undefined'){
      MZ.ajax.getNewUser();
    }
  }
}
