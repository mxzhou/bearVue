;(function(obj){
    var body = document.body;
    obj.dropdown = {
        init: function(){
            this.addEvent();
        },
        addEvent: function(){
           $(document).delegate('.for-slide .item-title','click',function(){
             var $this = $(this)
             $this.toggleClass('active');
             $this.next().toggle();
           })
        }
    }     
    obj.radio = {
        init: function(){
            this.addEvent();
        },
        addEvent: function(){
          return;
            $(document).delegate('.radio-list li','click',function(){
                var $this = $(this);
                $this.toggleClass('active').siblings('li').removeClass('active');
            })
        }
    }  
    obj.toggle = {
        init: function(){
            this.addEvent();
        },
        addEvent: function(){
            $(document).delegate('.toggle','click',function(){
                var $this = $(this);
                $this.toggleClass('active');
            })
        }
    }
    obj.confirm = function(config){
        var content = config.content ? config.content : '',
            title = config.title ? config.title : '确认提示',
            cancleFunc = config.cancle,
            callback = config.callback;
        var txt1 = config.text1 == undefined?'取消':config.text1;
        var txt2 = config.text2 == undefined?'确定':config.text2;
        var timestamp = new Date().getTime();
        var str = '<div class="weui_dialog_confirm" id="dialog'+timestamp+'">'+
                   ' <div class="weui_mask"></div>'+
                   ' <div class="weui_dialog">'+
                   '     <div class="weui_dialog_hd"><strong class="weui_dialog_title">'+title+'</strong></div>'+
                   '     <div class="weui_dialog_bd">'+content+'</div>'+
                   '     <div class="weui_dialog_ft">'+
                   '         <a href="javascript:;" class="weui_btn_dialog default jsCancle">'+txt1+'</a>'+
                   '         <a href="javascript:;" class="weui_btn_dialog primary jsOk">'+txt2+'</a>'+
                   '     </div>'+
                   ' </div>'+
                '</div>';
        $('body').append(str);
        var $dialog = $('#dialog'+timestamp);
        setTimeout(function(){
         $dialog.find('.weui_dialog').addClass('active');
        },50) 
        $dialog.find('.jsCancle').on('click touchend',function(e){
            e.preventDefault();
            $dialog.remove();
            cancleFunc && cancleFunc();
        })
        $dialog.find('.jsOk').on('click touchend',function(e){
            e.preventDefault();
            callback && callback(e);
            $dialog.remove();
        })
        this.hide = function(){
            $dialog.remove();
        }
        return 'dialog'+timestamp;
    }
    obj.alert = function(config){
        var content = config.content ? config.content : '',
            title = config.title ? config.title : '',
            cancleFunc = config.cancle,
            callback = config.callback,
            text = config.text ? config.text:'确定',
            footer = config.footer!=null?'display:none;':'';

        var timestamp = new Date().getTime();
        setTimeout(function(){
          $dialog.find('.weui_dialog').addClass('active');
        },50) 
        var str = '<div class="weui_dialog_confirm" id="alert'+timestamp+'">'+
                   ' <div class="weui_mask"></div>'+
                   ' <div class="weui_dialog">'+
                   '     <div class="weui_dialog_hd" style="'+footer+'"><strong class="weui_dialog_title">'+title+'</strong></div>'+
                   '     <div class="weui_dialog_bd">'+content+'</div>'+
                   '     <div class="weui_dialog_ft" style="'+footer+'">'+
                   '         <a href="javascript:;" class="weui_btn_dialog primary jsOk">'+text+'</a>'+
                   '     </div>'+
                   ' </div>'+
                '</div>';
        $('body').append(str);
        var $dialog = $('#alert'+timestamp);
        $dialog.find('.jsOk').on('click touchend',function(e){
            e.preventDefault();
            callback && callback(e);
            $dialog.remove();
        })
        return 'alert'+timestamp;
    }
    obj.loading = function(config){
      var content = arguments[0] ? config.content : '数据加载中';
      var timestamp = new Date().getTime();
      this.id = 'toast'+timestamp;
      var str = '<div id="'+this.id+'" class="weui_loading_toast" style="">'+
                '  <div class="weui_mask_transparent"></div>'+
                '  <div class="weui_toast">'+
                '      <div class="weui_loading">'+
                '          <div class="weui_loading_leaf weui_loading_leaf_0"></div>'+
                '          <div class="weui_loading_leaf weui_loading_leaf_1"></div>'+
                '          <div class="weui_loading_leaf weui_loading_leaf_2"></div>'+
                '          <div class="weui_loading_leaf weui_loading_leaf_3"></div>'+
                '          <div class="weui_loading_leaf weui_loading_leaf_4"></div>'+
                '          <div class="weui_loading_leaf weui_loading_leaf_5"></div>'+
                '          <div class="weui_loading_leaf weui_loading_leaf_6"></div>'+
                '          <div class="weui_loading_leaf weui_loading_leaf_7"></div>'+
                '          <div class="weui_loading_leaf weui_loading_leaf_8"></div>'+
                '          <div class="weui_loading_leaf weui_loading_leaf_9"></div>'+
                '          <div class="weui_loading_leaf weui_loading_leaf_10"></div>'+
                '          <div class="weui_loading_leaf weui_loading_leaf_11"></div>'+
                '      </div>'+
                '      <p class="weui_toast_content">'+content+'</p>'+
                '  </div>'+
              '</div>';
        $('body').append(str);
        this.$container = $('#'+this.id);
    }
    obj.loading.prototype = {
      finish: function(content){
        var _this = this;
        var content = arguments[0] ? content : '已完成';
        _this.$container.find('.weui_toast_content').html(content);
        _this.$container.find('.weui_loading').replaceWith('<i class="icon icon-check"></i>')
        setTimeout(function(){
          _this.$container.remove();
        },1000)
      },
      hide: function(){
        this.$container.remove();
      }
    }
    obj.toast = function(config){
        var content = config.content ? config.content : '';
        var timestamp = new Date().getTime();
        this.id = 'toast'+timestamp;
        var str = '<div class="toast" id="'+this.id+'">'+content+'</div>';
        $('body').append(str);
        var $container = $('#toast'+timestamp);
        setTimeout(function(){
         $container.addClass('active');
        },50) 
        if(config.hide){
            setTimeout(function(){
                $container.remove();
            },config.time||3000)
        }
        this.$container = $container;
    }
    obj.toast.prototype = {
      setContent: function(content){
        this.$container.html(content);
      },
      hide: function(){
        this.$container.remove();
      }
    }
    obj.showPrize = function(config){
      var id = config.id,          
          img = config.avatarUrl,
          name = config.name;
      var str = '<div class="modal transparent active" id="pageLottery" style="display: none;">'+
                '<div class="lottery-dialog">'+
                 '   <div class="inner">'+
                 '       <div class="pic"><img src="'+img+'"></div>'+
                 '       <p>期号：'+id+'</p>'+
                 '       <h3>'+name+'</h3>'+
                 '       <div class="btn-area">'+
                 '           <a href="'+config.href+'" class="btn btn-red">选择收货地址</a>'+
                 '       </div>'+
                 '   </div>'+
                '</div>'+
                '<a href="javascript:" class="btn-close"><i class="icon icon-close-wechat"></i></a>'+
            '</div>'
        var $pageLottery = $(str);
        $('body').append($pageLottery);
        $pageLottery.fadeIn();
        setTimeout(function(){
            $pageLottery.addClass('animatein');
        },500)
        $pageLottery.find('.btn-close').on('click touchend',function(e){
          e.preventDefault();
          $pageLottery.removeClass('active');
        })
    }
    obj.showShare = function(){
      var str = '<div class="modal transparent" id="pageShare">'+
               ' <i class="icon icon-img_sharearrow_2x"></i>'+
              '</div>';
      if($('#pageShare').length==0){
        $('body').append(str);
      }
      setTimeout(function(){
       $('#pageShare').addClass('active');
      },100)
      $(document).delegate('#pageShare','touchend touchend',function(e){
        $('#pageShare').removeClass('active');
        MZ.wechat.init({
           title: JSSDK_TITLE,
           desc: JSSDK_DESCSTR,
           link: JSSDK_LINKSTR,
           imgUrl: JSSDK_ICONSTR
        })
        e.preventDefault();
      })
    }
    obj.showSharePrize = function(config){
      var str = '<div class="modal transparent active" id="pageSharePrize" style="display: none;">'+
                '<div class="lottery-dialog">'+
                ''+
                '</div>'+
                '<a href="javascript:" class="btn-close"><i class="icon icon-close-wechat"></i></a>'+
            '</div>'
        var $pageSharePrize = $(str);
        $('body').append($pageSharePrize);
        $pageSharePrize.fadeIn();
        setTimeout(function(){
            $pageSharePrize.addClass('animatein');
        },500)
        $pageSharePrize.find('.btn-close').on('click touchend',function(e){
          e.preventDefault();
          $pageSharePrize.removeClass('active');
        })
    }
    obj.showLuckyBag = function(list){
      var str = '<div class="modal transparent active" id="pageLuckyBag" style="display: none;">'+
      '<div class="lucky-dialog"><div class="number"><span class="nicon nicon-1"></span></div><div class="lucky-list">'+
                  '<ul>'+list+'</ul>'+
                  '</div><div class="center"><a href="'+Prefix+'/views/user/luckybag.html" class="btn btn-green">领取红包</a></div></div>'+
                  '<a href="javascript:" class="btn-close"><i class="icon icon-close-wechat"></i></a>'+
              '</div>'
        var $pageLuckyBag = $(str);
        $('body').append($pageLuckyBag);
        $pageLuckyBag.fadeIn();
        setTimeout(function(){
            $pageLuckyBag.addClass('animatein');
        },500)
        $pageLuckyBag.find('.btn-close').on('click touchend',function(e){
          e.preventDefault();
          $pageLuckyBag.removeClass('active');
        })
    }
    obj.showFirst = function(){
      if(typeof noLogin!=undefined){
        return;
      }
      if(!/share.html/g.test(location.href)){
        if(localStorage.getItem('isFirst')==null){
          var str = '<div class="modal transparent active" id="pageFirst">'+
          ' <div class="leadin"><a href="javascript:" class="btn btn-red" id="btnStart">马上试试</a></div>'+
                  '</div>';
          if($('#pageFirst').length==0){
            $('body').append(str);
          }
        }
        $(document).delegate('#btnStart','click touchend',function(e){
          $('#pageFirst').fadeOut();
          localStorage.setItem('isFirst',false)
          e.preventDefault();
        })
      }

    }
    obj.showShareResult = function(info){     
      var str = '<div class="modal transparent active" id="pageShareResult" style="display: none;">'+
                '<div class="lottery-dialog">'+
                 '   <div class="inner">'+
                 '       <div class="pic">￥'+info.money+'<br><span>'+info.typeName+'</span></div>'+
                 '       <p>分享成功！<br>恭喜你获得 '+info.money+' 元红包</p>'+
                 '       <div class="btn-area">'+
                 '           <a href="'+Prefix+'/views/index.html" class="btn btn-red">马上购物</a>'+
                 '       </div>'+
                 '   </div>'+
                '</div>'+
                '<a href="javascript:" class="btn-close"><i class="icon icon-close-wechat"></i></a>'+
            '</div>'
        var $pageLottery = $(str);
        $('body').append($pageLottery);
        $pageLottery.fadeIn();
        setTimeout(function(){
            $pageLottery.addClass('animatein');
        },500)
        $pageLottery.find('.btn-close').on('click touchend',function(e){
          e.preventDefault();
          $pageLottery.removeClass('active');
        })
    }
    obj.setNavStatus = function(idx){
        var $footerNav = $('.footer-nav');
        $footerNav.find('.tab-item').eq(idx).addClass('active');
    }
    return obj;
})(MZ || {});
//:active效果
document.body.addEventListener('touchstart',function(){},false);
MZ.dropdown.init();
MZ.radio.init();
MZ.toggle.init();
MZ.showFirst();