;MZ.cart = {

	init : function() {
      if(!localStorage) return;
  		var $footerNav = $('.footer-nav');
      var cartNum = localStorage.getItem('cartNum');
  		if($footerNav.length!=0){
  			var  $badge = $footerNav.find('.tab-item').eq(3).find('.badge');
  			if(cartNum==null){
  				$badge.hide();
  			}else{
  				$badge.html(cartNum).show();
  			}
  		}
      var $btnCar = $('#btnCar').find('.badge');
      if($btnCar.length!=0){
        log("cartNum:"+cartNum)
        if(cartNum==null){
          $btnCar.hide();
        }else{
          $btnCar.html(cartNum).show();
        }
      }
    },
    getCartDetail: function() {
    	
    },
    update: function(number){
      if(number!=0){
        localStorage.setItem('cartNum',number);
      }else{
        localStorage.removeItem('cartNum',number);
      }
      MZ.cart.init();
    },
    addCart: function(config){    
    	var cartNum = localStorage.getItem('cartNum');
      console.log(config.goodsList);
    	Zepto.ajax({
    		type:'post',
    		url: ApiPrefix+'/cart/add',
    		data: {token:MZ.utils.getToken(),kgUid:kgUid,goodIds:JSON.stringify(config.goodsList)},
    		dataType:'json',
            cache: false,
  			success: function(data){
          log(data)
          if(data.errorMessage=='token不合法'){
            MZ.wechat.checkLogin(data);
            return;
          }
  				if(data.status==1){
            if(cartNum == null){
              if(data.data.totalNumber!=0){
                localStorage.setItem('cartNum',1);
              }
            }else{
              if(data.data.totalNumber!=0){
                localStorage.setItem('cartNum',data.data.totalNumber);
              }
            }
            config.callback&&config.callback();
  					MZ.cart.init();
  				}else{
            MZ.alert({content:'加入清单错误，请稍后再试'})
          }
  			},
        error: function(err){
        }
    	})
    }
    
};

MZ.cart.init();