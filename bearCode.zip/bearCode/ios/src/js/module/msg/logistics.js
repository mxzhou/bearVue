define(function(require, exports,modules) {
    var App = {};
    var win = window,
    doc = win.document;
    var LoadMore = require('widgets/load-more');
    function layout(){
        
    }
    App.init = function(){
        addEvent();
        layout();
        loadmore();
        getList();
        ajaxGetMsgNum();
    }
    function loadmore(){
        //初始化下拉加载更多
        $(document).on('scroll touchmove',function(){
            if(HasNoMore){
              $('.loading-more').hide();
              return;
            }
            if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
                if($('.loading-more').length==0){
                    getList();
                }
            }
        });
    }
    var Page = 1;
    var Loading = false;
    var HasNoMore = false;
    function getList(){
        if(Loading)return;
        Loading = true;
        if(HasNoMore)return;
        var pageSize=10
        Zepto.ajax({
            url: ApiPrefix+'/logisticsMessage/list',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,"pageSize": pageSize,"pageNumber":Page},
            cache: false,
            dataType: 'json',
            success: function(data){
                log(data)
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    var $list = $('.for-good-list');
                    var str = '';
                    var list  = data.data.messageList;
                    
                    for(var i in list) {
                        var item = list[i];
                        var status = '';
                        if(item.logisticsStatus==1){
                            status = '<span class="label yellow">下单</span>';
                        }else if(item.logisticsStatus==2){
                            status = '<span class="label yellow">出库</span>';
                        }else if(item.logisticsStatus==3){
                            status = '<span class="label yellow">已发货</span>';
                        }else if(item.logisticsStatus==4){
                            status = '<span class="label green">已签收</span>';
                        }
                        str += '<li class="table-view-cell media">'+
                                '<div href="detail-calculation.html" class="navigate-right">'+
                                 ' <div class="pic-left"><img class="media-object pull-left" src="'+ImgBlank+'" data-echo="'+item.coverImgUrl+'"></div>'+
                                 ' <div class="media-body">'+
                                 '   <h3>'+status+item.goodsName+'</h3>'+
                                 '   <p class="msg">'+item.content+'</p>'+
                                 '   <p class="item">'+item.updataTime+'</p>'+
                                 ' </div>'+
                                '</div>'+
                              '</li>';
                    }
                    $list.append(str);
                    //延迟加载
                    MZ.utils.initEcho();
                    if(Page==1 && list.length == 0){
                        var str = '<div class="center msg-empty">'+
                                '<img src="../../src/images/img_msg@2x.png"><br>暂无消息</div>';
                       $('body').append(str);
                       $('.footer-icon').hide();
                       HasNoMore = true;
                    }else if(list.length<pageSize){
                     HasNoMore = true;
                     var nomorestr='<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;">没有更多记录</div>';
                     $list.append(nomorestr);
                    }
                    Page++;
                }else{
                    MZ.alert({content: data.errorMessage});
                }
                Loading = false;
            },
            error: function(){
              Loading = false;
            }
        })
        
    }
    function addEvent(){
        
    }
    function ajaxGetMsgNum(){
        Zepto.ajax({
            url: ApiPrefix+'/messageNum/getNum',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid},
            cache: false,
            success: function(data){
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    if(data.data!=null){
                        var msg =data.data;
                        var $controlItem = $('.control-item');
                        if(msg.activityNum!=0){
                            $controlItem.eq(0).find('.badge').css('display','inline-block');
                        }
                        if(msg.sysNum!=0){
                            $controlItem.eq(2).find('.badge').css('display','inline-block');
                        }
                    }
                }else{
                    //MZ.alert({content: data.errorMessage});
                }
            },
            error: function(){
            }
        })
    }
    modules.exports = App;
});
