define(function(require, exports,modules) {
    var App = {};
    var win = window,
    doc = win.document;
    var LoadMore = require('widgets/load-more');
    function layout(){
        
    }
    App.init = function(){
        addEvent();
        layout();
        loadmore();
        ajaxGetMsgNum();
        getListTab01(true);
        getListTab02(true);
        getListTab03(true);
    }
    function loadmore(){
    	//初始化下拉加载更多
        $(document).on('scroll touchmove',function(){
            if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
                var idx = $('#fixedMsg a.active').index();
              if(idx==0){
                getListTab01();
              }else if(idx==1){
                getListTab02();
              }else{
                getListTab03();
              }
            }
        });
    }
    var Page1 = 1;
    var pageSize1=10
    var Loading1 = false;
    var HasNoMore1 = false;
    function getListTab01(init){
        if(!init){
            if(Loading1)return;
            Loading1 = true;
        }
        Zepto.ajax({
            url: ApiPrefix+'/activityMessage/list',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,"pageSize": pageSize1,"pageNumber":Page1},
            cache: false,
            dataType: 'json',
            success: function(data){
              if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                log(data)
                if(data.status==1){
                    var $list = $('#tabContent01');
                    var str = '';
                    var list  = data.data.messageList;
                    log(list)
                    for(var i in list) {
                        var item = list[i];
                        var time ;
                        (function(t1,t2){
                          time = MZ.utils.formatFromToday(t1,t2);
                        })(data.servertime,item.sendTime);
                        var type = item.jumpType;
                        var link = '';
                        if(type==1){
                          link = item.jumpValue;
                        }else if(type == 2){
                          link = '../detail.html?goodsId='+item.jumpValue+'&id=0';
                        }else if(type == 3){
                          link = '../search.html?searchContent='+item.jumpValue;
                        }
                        str += '<li>'+
                               ' <a href="'+link+'"><div class="pic-area">'+
                               '   <div class="pic">'+
                               '     <img src="'+ImgBlank+'" alt="'+item.goodsName+'" data-echo="'+item.imgUrl+'">'+
                               '     <div class="msg-title">'+item.title+'</div>'+
                               '   </div>'+
                               '   <div class="desc"><p>'+item.sendDesc+'</p><p class="timebar"><span class="fr">查看详情<i class="icon icon-right-nav"></i></span>'+time+'</p></div>'+
                               ' </div></a>'+
                              '</li>';
                    }
                    $list.append(str);
                    list = list == null?[]:list;
                    if(Page1==1 && list.length == 0){
                        var str = '<div class="center msg-empty">'+
                                '<img src="../../src/images/img_msg@2x.png"><br>暂无消息</div>';
                       $('.footer-icon').hide();
                       if($('.msg-empty').length==0){
                        $('body').append(str);
                       }
                       $('.msg-empty').hide();
                       HasNoMore1 = true;
                    }else if(list.length<pageSize1){
                     HasNoMore1 = true;
                     var nomorestr='<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;border-top:none;">没有更多记录</div>';
                     if($list.find('.nomore').length==0){
                      //$list.append(nomorestr);
                     }
                    }
                    //延迟加载
                    MZ.utils.initEcho();
                    Page1++;
                }else{
                    MZ.alert({content: data.errorMessage});
                }
                Loading = false;
            },
            error: function(){
              Loading = false;
            }
        })
    }
    var Page2 = 1;
    var pageSize2 = 10
    var Loading2 = false;
    var HasNoMore2 = false;
    function getListTab02(init){
        if(!init){
            if(Loading2)return;
            Loading2 = true;
            if(HasNoMore2)return;
        }
        var pageSize=10;
        Zepto.ajax({
            url: ApiPrefix+'/logisticsMessage/list',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,"pageSize": pageSize,"pageNumber":Page2},
            cache: false,
            dataType: 'json',
            success: function(data){
              if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                log(data)
                if(data.status==1){
                    var $list = $('#tabContent02');
                    var str = '';
                    var list  = data.data.messageList;
                    log(list)
                    for(var i in list) {
                        var item = list[i];
                        var status = '';
                        if(item.logisticsStatus==1){
                            status = '<span class="label yellow">下单</span>';
                        }else if(item.logisticsStatus==2){
                            status = '<span class="label yellow">出库</span>';
                        }else if(item.logisticsStatus==3){
                            status = '<span class="label yellow">已发货</span>';
                        }else if(item.logisticsStatus==4){
                            status = '<span class="label green">已签收</span>';
                        }
                        /*str += '<li class="table-view-cell media">'+
                                '<div href="detail-calculation.html" class="navigate-right">'+
                                 ' <div class="pic-left"><img class="media-object pull-left" src="'+ImgBlank+'" data-echo="'+item.coverImgUrl+'"></div>'+
                                 ' <div class="media-body">'+
                                 '   <h3>'+status+item.goodsName+'</h3>'+
                                 '   <p class="msg">'+item.content+'</p>'+
                                 '   <p class="item">'+item.updataTime+'</p>'+
                                 ' </div>'+
                                '</div>'+
                              '</li>';*/
                        var time ;
                        (function(t1,t2){
                          time = MZ.utils.formatFromToday(t1,t2);
                        })(data.servertime,item.updataTime);      
                        str += '<li style="height:auto;">'+
                                '<a href="http://m.kuaidi100.com/index_all.html?postid='+item.logisticsNo+'" class="item noafter" style="padding-left:190px;overflow:auto;height:auto;">'+
                                '<div class="pic" style="margin-left:-175px;"><img src="'+ImgBlank+'" data-echo="'+item.coverImgUrl+'"></div>'+
                                '  <h3><div class="t">您的商品已发货</div></h3>'+
                                '  <div class="desc">'+
                                '    <p>您的商品“（第'+item.goodRobId+'期）<span class="blue">'+item.goodsName+'</span>”已经发货，请耐心等待哦！</p>'+
                                '  </div><p class="timebar"><span class="fr">查看详情<i class="icon icon-right-nav"></i></span>'+time+'</p>'+
                                '</a>'+
                              '</li>';
                    }
                    $list.append(str);                   
                    //延迟加载
                    MZ.utils.initEcho();
                    list = list==null?[]:list;
                    if(Page2==1 && list.length == 0){
                        var str = '<div class="center msg-empty">'+
                                '<img src="../../src/images/img_msg@2x.png"><br>暂无消息</div>';
                       if($('.msg-empty').length==0){
                        $('body').append(str);
                       }
                       $('.msg-empty').hide();
                       $('.footer-icon').hide();
                       HasNoMore2 = true;
                    }else if(list.length<pageSize){
                     HasNoMore2 = true;
                     var nomorestr='<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;border-top:none;">没有更多记录</div>';
                     //$list.append(nomorestr);
                    }
                    if(logisticsNum!=0 && Page2 == 1){
                      $list.find('li').each(function(i){                        
                          var $this = $(this);
                          var $h = $this.find('h3 .t');
                          if($h.find('.badge').length==0){
                            $h.html('<span class="badge"></span>'+$h.html());
                          }
                      })
                    }
                    Page2++;
                }else{
                    MZ.alert({content: data.errorMessage});
                }
                Loading2 = false;
            },
            error: function(){
              Loading2 = false;
            }
        })
    }
    var Page3 = 1;
    var pageSize3 = 10
    var Loading3 = false;
    var HasNoMore3 = false;
    function getListTab03(init){
        if(!init){
            if(Loading3)return;
            Loading3 = true;
            if(HasNoMore3)return;
        }
        var pageSize=10
        Zepto.ajax({
            url: ApiPrefix+'/sysMessage/list',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,"pageSize": pageSize,"pageNumber":Page3},
            cache: false,
            dataType: 'json',
            success: function(data){
              if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    var $list = $('#tabContent03');
                    var str = '';
                    var list  = data.data.messageList;
                    for(var i in list) {
                        var item = list[i];
                        var time ;
                        (function(t1,t2){
                          time = MZ.utils.formatFromToday(t1,t2);
                        })(data.servertime,item.sendTime);
                        if(item.sendType==2){
                            //中奖消息
                            str += '<li style="height:auto;">'+
                                '<a href="../user/prize-record.html" class="item noafter" style="padding-left:190px;overflow:auto;height:auto;">'+
                                '<div class="pic" style="margin-left: -180px;"><img src="'+item.goodsImg+'"></div>'+
                                '  <h3><div class="t">'+item.title+'</div></h3>'+
                                '  <div class="desc" style="min-height:80px;">'+
                                '    <p>'+item.sendDesc+'</p>'+
                                '  </div><p class="timebar"><span class="fr">查看详情<i class="icon icon-right-nav"></i></span>'+time+'</p>'+
                                '</a>'+
                              '</li>';
                        }else if(item.sendType == 5){
                            //优秀晒单消息
                            str += '<li style="height:auto;">'+
                                '<a href="../discover/share-detail.html?id='+item.id+'" class="item" style="padding-left:190px;height:auto;overflow:auto;">'+
                                '  <h3 style="margin-left:-175px;"><div class="t">'+item.title+'</div></h3>'+
                                '  <div class="desc" style="min-height:80px;margin-left:-175px;">'+
                                '    <p>'+item.sendDesc+'</p>'+
                                '  </div><p class="timebar"><span class="fr">查看详情<i class="icon icon-right-nav"></i></span>'+time+'</p>'+
                                '</a>'+
                              '</li>';
                        }else if(item.sendType == 4){
                            //红包消息
                            str += '<li style="height:auto;">'+
                                '<a href="../user/luckybag.html" class="item" style="padding-left:190px;height:auto;overflow:auto;">'+
                                '  <h3 style="margin-left:-175px;"><div class="t">'+item.title+'</div></h3>'+
                                '  <div class="desc" style="min-height:80px;margin-left:-175px;">'+
                                '    <p>'+item.sendDesc+'</p>'+
                                '  </div><p class="timebar"><span class="fr">查看详情<i class="icon icon-right-nav"></i></span>'+time+'</p>'+
                                '</a>'+
                              '</li>';
                        }else{
                            str += '<li style="height:auto;">'+
                                '<a href="msg-detail.html?id='+item.id+'" class="item" style="padding-left:190px;height:auto;overflow:auto;">'+
                                '  <h3 style="margin-left:-175px;"><div class="t">'+item.title+'</div></h3>'+
                                '  <div class="desc" style="min-height:80px;margin-left:-175px;">'+
                                '    <p>'+item.sendDesc+'</p>'+
                                '  </div><p class="timebar"><span class="fr">查看详情<i class="icon icon-right-nav"></i></span>'+time+'</p>'+
                                '</a>'+
                              '</li>';
                        }
                    }
                    $list.append(str);
                    list = list==null?[]:list;
                    if(Page3==1 && list.length == 0){
                        var str = '<div class="center msg-empty">'+
                                '<img src="../../src/images/img_msg@2x.png"><br>暂无消息</div>';
                       $('.footer-icon').hide();
                       if($('.msg-empty').length==0){
                        $('body').append(str);
                       }                       
                       HasNoMore3 = true;
                    }else if(list.length<pageSize){
                     HasNoMore3 = true;
                     var nomorestr='<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;border-top:none;">没有更多记录</div>';
                     //$list.append(nomorestr);
                    }
                    if(sysNum!=0){
                      $list.find('li').each(function(i){  
                          if(i<sysNum){
                            var $this = $(this);
                            var $h = $this.find('h3 .t');
                            if($h.find('.badge').length==0){
                              $h.html('<span class="badge"></span>'+$h.html());
                            }
                          }
                      })
                    }

                    Page3++;
                }else{
                    MZ.alert({content: data.errorMessage});
                }
                if($('#tabContent0'+($('.control-item.active').index()+1)).find('li').length==0){
                  $('.msg-empty').show();
                 }else{
                  $('.msg-empty').hide();
                 }
                Loading3 = false;
            },
            error: function(){
              Loading3 = false;
            }
        })
    }

    function addEvent(){
        $('.control-item').on('touchend',function(e){
          var $this = $(this);
          $this.find('.badge').hide();
          $this.addClass('active').siblings('a').removeClass('active');
          $('.msg-empty').hide();
          if($this.index()==0){
            if($('#tabContent01 li').length==0){
              $('.msg-empty').show();
            }
            $('#tabContent02').add('#tabContent03').hide();
            $('#tabContent01').show();
          }else if($this.index()==1){
            if($('#tabContent02 li').length==0){
              $('.msg-empty').show();
            }
            $('#tabContent01').add('#tabContent03').hide();
            $('#tabContent02').show();
          }else {
            $('#tabContent01').add('#tabContent02').hide();
            if($('#tabContent03 li').length==0){
              $('.msg-empty').show();
            }else{
              $('#tabContent03').show();
            }
          }
          //图片延迟加载
          MZ.utils.initEcho();
          e.preventDefault();
        })
    }
    var activityNum=0,logisticsNum=0,sysNum=0;
    function ajaxGetMsgNum(){
        Zepto.ajax({
            url: ApiPrefix+'/messageNum/getNum',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid},
            cache: false,
            async: false,
            success: function(data){
              if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    if(data.data!=null){
                        var msg =data.data;
                        var $controlItem = $('.control-item');
                        activityNum = msg.activityNum;
                        sysNum = msg.sysNum;
                        logisticsNum = msg.logisticsNum;
                        if(msg.sysNum!=0){
                           $controlItem.eq(2).addClass('active');
                           $('#tabContent03').show();
                           if(msg.activityNum!=0){
                                $controlItem.eq(0).find('.badge').css('display','inline-block');
                            }
                            if(msg.logisticsNum!=0){
                                $controlItem.eq(1).find('.badge').css('display','inline-block');
                            }
                        }
                        if(msg.logisticsNum!=0){
                           $controlItem.removeClass('active');    
                           $controlItem.eq(1).addClass('active');
                           $('#tabContent02').show();
                           if(msg.activityNum!=0){
                                $controlItem.eq(0).find('.badge').css('display','inline-block');
                            }
                            if(msg.sysNum!=0){
                                $controlItem.eq(2).find('.badge').css('display','inline-block');
                            }
                        }
                        if(msg.activityNum!=0||(msg.activityNum==0 && msg.logisticsNum==0 && msg.sysNum==0)){
                           $controlItem.removeClass('active');
                           $controlItem.eq(0).addClass('active');
                           $('#tabContent01').show();
                           $controlItem.eq(0).find('.badge').hide();
                            if(msg.logisticsNum!=0){
                                $controlItem.eq(1).find('.badge').css('display','inline-block');
                            }
                            if(msg.sysNum!=0){
                                $controlItem.eq(2).find('.badge').css('display','inline-block');
                            }
                        }
                    }
                }else{
                    //MZ.alert({content: data.errorMessage});
                }
            },
            error: function(){
            }
        })
    }
    modules.exports = App;
});
