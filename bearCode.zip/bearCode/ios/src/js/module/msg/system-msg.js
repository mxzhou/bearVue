define(function(require, exports,modules) {
    var App = {};
    var win = window,
    doc = win.document;
    var LoadMore = require('widgets/load-more');
    function layout(){
        
    }
    App.init = function(){
        addEvent();
        layout();
        loadmore();
        getList();
        ajaxGetMsgNum();
    }
    function loadmore(){
        //初始化下拉加载更多
        $(document).on('scroll touchmove',function(){
            if(HasNoMore){
              $('.loading-more').hide();
              return;
            }
            if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
                if($('.loading-more').length==0){
                    getList();
                }
            }
        });
    }
    var Page = 1;
    var Loading = false;
    var HasNoMore = false;
    function getList(){
        if(Loading)return;
        Loading = true;
        if(HasNoMore)return;
        var pageSize=10
        Zepto.ajax({
            url: ApiPrefix+'/sysMessage/list',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,"pageSize": pageSize,"pageNumber":Page},
            cache: false,
            dataType: 'json',
            success: function(data){
                log(data)
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    var $list = $('.system-msg-list');
                    var str = '';
                    var list  = data.data.messageList;
                    for(var i in list) {
                        var item = list[i];
                        if(item.sendType==2){
                            str += '<li>'+
                                '<a href="msg-detail.html?id='+item.id+'">'+
                                '  <h3><span class="fr">'+MZ.utils.formatFromToday(data.servertime,item.sendTime)+'</span><div class="t">'+item.title+'</div></h3>'+
                                '  <div class="desc">'+
                                '<div class="pic"><img src="'+item.goodsImg+'"></div>'+
                                '    <p>'+item.sendDesc+'</p>'+
                                '  </div>'+
                                '</a>'+
                              '</li>';
                        }else{
                            str += '<li>'+
                                '<a href="msg-detail.html?">'+
                                '  <h3><span class="fr">'+MZ.utils.formatFromToday(data.servertime,item.sendTime)+'</span><div class="t">'+item.title+'</div></h3>'+
                                '  <div class="desc">'+
                                '    <p>'+item.sendDesc+'</p>'+
                                '  </div>'+
                                '</a>'+
                              '</li>';
                        }
                    }
                    $list.append(str);
                    if(Page==1 && list == null){
                        var str = '<div class="center msg-empty">'+
                                '<img src="../../src/images/img_msg@2x.png"><br>暂无消息</div>';
                       $('.footer-icon').hide();
                       $('body').append(str);
                       HasNoMore = true;
                    }else if(list.length<pageSize){
                     HasNoMore = true;
                     var nomorestr='<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;">没有更多记录</div>';
                     $list.append(nomorestr);
                    }
                    Page++;
                }else{
                    MZ.alert({content: data.errorMessage});
                }
                Loading = false;
            },
            error: function(){
              Loading = false;
            }
        })
        
    }
    function addEvent(){
        
    }
    function ajaxGetMsgNum(){
        Zepto.ajax({
            url: ApiPrefix+'/messageNum/getNum',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid},
            cache: false,
            success: function(data){
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    if(data.data!=null){
                        var msg =data.data;
                        var $controlItem = $('.control-item');
                        if(msg.activityNum!=0){
                            $controlItem.eq(0).find('.badge').css('display','inline-block');
                        }
                        if(msg.logisticsNum!=0){
                            $controlItem.eq(1).find('.badge').css('display','inline-block');
                        }
                    }
                }else{
                    //MZ.alert({content: data.errorMessage});
                }
            },
            error: function(){
            }
        })
    }
    modules.exports = App;
});
