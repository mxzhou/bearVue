define(function(require, exports,modules) {
    var App = {};
    var win = window,
    doc = win.document;
    App.init = function(){
        getDetail();
    }
    function getDetail(){
        Zepto.ajax({
            url: ApiPrefix+'/sysMessage/detail',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,id:MZ.utils.getQueryString('id')},
            cache: false,
            success: function(data){
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    var info = data.data;
                    if(info!=null){
                        $('#title').html(info.title);
                        $('#time').html(info.sendTime);
                        $('#content').html(info.sendDesc.replace(/\n/g,'<br>'));
                    }
                }else{
                    //MZ.alert({content: data.errorMessage});
                }
            },
            error: function(){
            }
        })
    }
    modules.exports = App;
});

