define(function(require, exports,modules) {
    var App = {};
    var win = window,
        doc = win.document;
    var LoadMore = require('widgets/load-more');
    function layout(){
        
    }
    App.init = function(){
        addEvent();
        layout();
        MZ.utils.initEcho();;
        loadmore();
        getList();
    }
    function loadmore(){
        //初始化下拉加载更多
        $(document).on('scroll touchmove',function(){
            if(HasNoMore){
              $('.loading-more').hide();
              return;
            }
            if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
                if($('.loading-more').length==0){
                    getList();
                }
            }
        });
    }
    var Loading = false;
    var HasNoMore = false;
    var LastId = 0;
    var Page = 1;
    function getList(){
        if(Loading)return;
        Loading = true;
        Zepto.ajax({
            url: ApiPrefix+'/find/waitingShare',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,status:1,pageNumber:Page,pageSize:20},
            cache: false,
            success: function(data){
              if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                log(data);
                if(data.status==1){
                    var $list = $('.for-good-list');
                    var str = '';
                    var list = data.data;
                    if(list.length==0){
                      HasNoMore = true;
                      if(Page==1){
                        str+='<div class="cart-empty" style="margin-top:30%;">'+
                                 ' <i class="icon icon-img_empty"></i>'+
                                 ' <h3>暂无晒单记录</h3>'+
                                '<a href="../index.html" class="btn btn-red-transparent">马上去夺宝</a></div>';
                        $('.footer-icon').hide();
                      }else{
                        str+='<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;border-top:none;">没有更多记录</div>';
                      }
                      $(str).insertAfter($list);
                    }else{
                      for(var i in list) {
                          var item = list[i];
                          str += '<li class="table-view-cell media">'+
                               ' <div class="navigate-right">'+
                                '  <div class="pic-left"><img class="media-object pull-left" src="'+ImgBlank+'" alt="photo" data-echo="'+item.sharePicUrl+'"></div>'+
                                '  <div class="media-body">'+
                                '    <div class="media-right">'+
                                '      <a href="rule.html?goodsRobId='+item.goodsRobId+'" class="btn btn-red-transparent">晒单</a>'+
                                '    </div>'+
                                '    <h3>'+item.goodsName+'</h3>'+
                                '    <p class="item">期号: 301395031</p>'+
                                '    <p class="item">总需: 10086</p>'+
                                '  </div>'+
                                '</div>'+
                              '</li>';
                      }
                      Page++;
                      $list.append(str);
                       //延迟加载
                      MZ.utils.initEcho();
                    }
                }else{
                    MZ.alert({content: data.errorMessage});
                }
                Loading = false;
            },
            error: function(){
              Loading = false;
            }
        })
    }
    function addEvent(){
        
    }
    
    modules.exports = App;
});
