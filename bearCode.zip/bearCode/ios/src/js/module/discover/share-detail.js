define(function(require, exports,modules) {
    var App = {};
    var LoadMore = require('widgets/load-more');
    function layout(){
        
    }
    App.init = function(){
        addEvent();
        layout();
        setTimeout(function(){
            $('#pageLottery').fadeIn();
            setTimeout(function(){
                $('#pageLottery').addClass('animatein');
            },500)
        },1000)
        $('.btn-close').on('click',function(){
            $('#pageLottery').removeClass('active');
        })
        getContent();
    }
    function getContent(){
      var id = MZ.utils.getQueryString('id');
      if(id==null || id=='null'){
        location.href='share-list.html';
      }else{
        Zepto.ajax({
          url: ApiPrefix+'/find/shareDetail',
          type: 'post',
          data: {token:MZ.utils.getToken(),shareId:id},
          cache: false,
          success: function(data){
            if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
              if(data.status==1){
                  var content = data.data;
                  $('#goodsName').html(content.goodsName);
                  $('#goodsName').on('touchend',function(e){
                    e.preventDefault();
                    location.href='../detail.html?goodsId='+content.goodsId+"&id="+content.goodsRobId;
                  }) 
                  var userimg = content.avatarUrl;
                  if(userimg==''||userimg==null){
                      userimg = ImgUser;
                  }
                  $('#avatarUrl').attr('src',userimg);
                  $('#avatarUrl').on('touchend',function(e){
                    e.preventDefault();
                    location.href='../user/friend-index.html?id='+content.kgUid;
                  })                
                  $('#createTime').html(MZ.utils.formatDate(content.createTime));
                  $('#openTime').html(MZ.utils.formatDate(content.openTime));
                  $('#joinNumber').html(content.joinNumber);
                  $('#nickname').html('<a href="../user/friend-index.html?id='+content.kgUid+'">'+content.nickname+'</a>');
                  $('#winWords').html(content.winWords);
                  $('#goodsRobId').html(content.goodsRobId);
                  $('#winerCode').html(content.winerCode);
                  $('#btnWant').attr('href','../detail.html?id=0&goodsId='+content.goodsId);
                  if(content.recommStatus==1){
                    $('.share-product-info').addClass('great');
                  }
                  var piclist = content.sharePicUrl.split(',');
                  var picstr = '';
                  for(var i in piclist){
                    var item = piclist[i];
                    picstr += '<img src="'+item+'">';
                  }
                  $('#imgList').html(picstr);
                  MZ.utils.initEcho();
              }else{
                  MZ.alert({content: data.errorMessage});
              }
          },
          error: function(){
            Loading = false;
          }
        })
        
      }

    }
    function addEvent(){
        
    }
    
    modules.exports = App;
});
