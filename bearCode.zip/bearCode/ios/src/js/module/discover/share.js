define(function(require, exports,modules) {
    var App = {},
        uploader = require('widgets/uploader-mutilple');
    function layout(){
        
    }
    App.init = function(){
        addEvent();
        layout();
        //uploader('dd');
        ajaxGetDetail();
        /*MZ.confirm({
            content: 'hello world!',
            callback: function(e){
                MZ.alert({
                    title: '系统确认弹窗',
                    content: 'hello world!',
                    callback: function(e){
                        $(e.target).parents('.weui_dialog_confirm').hide();
                    }
                });
            }
        });*/
    }
    var goodsRobId;
    function addEvent(){
      //提交分享
      $('#btnSubmit').on('click',function(e){
        var $content = $('#content');
        var content = $content.val();
        var $this = $(this);
        if($this.hasClass('isLoading'))return;
        if(!CanShare){
            MZ.alert({content:ErrorMessage});
            return;
        }
        if(content.replace(/\s/g,'')==''){
            MZ.alert({content:'请输入中奖感言'});
            return;
        }
        if(content.length<20){
            MZ.alert({content:'最少输入20个字'});
            return;
        }
        if($('.upload').length<3){
            MZ.alert({content:'需要上传三张奖品照片'});
            return;
        }
        var imgs = [];
        $('.pic-list dd').each(function(){
            imgs.push($(this).attr('data-src'));
        })
        $this.addClass('isLoading');
        $.ajax({
            url: ApiPrefix+'/find/share',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,goodsRobId:MZ.utils.getQueryString('goodsRobId'),
            winWords:content.replace(/<*>*/g,''),path:imgs.toString()},
            cache: false,
            success: function(data){
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
                  }
                if(data.status==1 && data.data!=null){
                    location.href='share-detail.html?id='+data.data;
                    CanShare = true;
                }else{
                    CanShare = false;
                    ErrorMessage = data.errorMessage;
                    MZ.alert({content: data.errorMessage});
                }
                $this.removeClass('isLoading');
            },
            error: function(){
              Loading = false;
              $this.removeClass('isLoading');
            }
        })
        e.preventDefault();
      })
    }
    var CanShare = true,ErrorMessage = '';
    function ajaxGetDetail(){
        var goodsRobId = MZ.utils.getQueryString('goodsRobId');
        if(goodsRobId=='null'||goodsRobId==null){
            location.href='share-list.html';
        }
        $.ajax({
            url: ApiPrefix+'/goods/detail',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,id:goodsRobId},
            cache: false,
            success: function(data){
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
                  }
                if(data.status==1 && data!=null){
                    data = data.data;
                    CanShare = true;
                    $('#goodsImg').html('<img class="media-object pull-left" src="'+data.coverImgUrl+'">');
                    $('#goodsName').html(data.goodsName);
                    $('#goodsRobId').html(data.id);
                    $('#joinNumber').html(data.needNumber);
                    $('#btnLink').on('touchend',function(e){
                        e.preventDefault();
                        location.href = '../detail.html?goodsId='+data.goodsId+"&id="+data.id;
                    })
                }else{
                    CanShare = false;
                    //MZ.alert({content: data.errorMessage});
                }
            },
            error: function(){
              Loading = false;
            }
        })
    }
    uploadImg();
    function uploadImg(){
        var $upload01 = $('#btnSelectPic1');
            upload01  = new mReSizeImg();
            upload01.photoContainer= $upload01;
        var toast1={};
        upload01.onUploadBegin(function(){
            $upload01.addClass('uploading');
            toast1 = new MZ.toast({content:'图片处理中...'})
        })
        upload01.onUploadComplete(function(data){
            $upload01.find('.btn-add').hide();
            $upload01.find('input').hide();
            toast1.hide();
            setTimeout(function(){
                ajaxpUload(upload01.getCanvasBase64Img(),1);
            },200)
            $upload01.append('<div class="btn-close"><span class="icon icon-close"></span></div>');
        })
        var toast2={};
        var $upload02 = $('#btnSelectPic2');
            upload02  = new mReSizeImg();
            upload02.photoContainer= $upload02;
        upload02.onUploadBegin(function(){
            $upload02.addClass('uploading');
            toast2 = new MZ.toast({content:'图片处理中...'})
        })
        upload02.onUploadComplete(function(data){
            $upload02.find('.btn-add').hide();
            $upload02.find('input').hide();
            toast2.hide();
            setTimeout(function(){
                ajaxpUload(upload02.getCanvasBase64Img(),2);
            },200)
            $upload02.append('<div class="btn-close"><span class="icon icon-close"></span></div>');
        })
        var toast3={};
        var $upload03 = $('#btnSelectPic3');
            upload03  = new mReSizeImg();
            upload03.photoContainer= $upload03;
        upload03.onUploadBegin(function(){
            $upload03.addClass('uploading');
            toast3 = new MZ.toast({content:'图片处理中...'})
        })
        upload03.onUploadComplete(function(data){
            $upload03.find('.btn-add').hide();
            $upload03.find('input').hide();
            toast3.hide();
            setTimeout(function(){
                ajaxpUload(upload03.getCanvasBase64Img(),3);
            },200)
            $upload03.append('<div class="btn-close"><span class="icon icon-close"></span></div>');
        })
        setTimeout(function(){
            upload01.init();
            upload02.init();
            upload03.init();
        },1000)

        $(document).delegate('.btn-close','touchend',function(e){
            var $this = $(this),
                $parent = $this.parent('dd');
            e.preventDefault();
            e.stopPropagation();
            $this.remove();
            var idx = $parent.index();
            switch(idx){
                case 0: 
                    upload01.remove();
                    break;
                case 1: 
                    upload02.remove();
                    break;
                case 2: 
                    upload03.remove();
                    break;
            }
            $parent.removeClass('uploading').removeClass('upload');
            $parent.find('.btn-add').css('display','block');
            $parent.find('input').css('opacity','0').val('');
            $parent.find('.hover').remove();

        })
        function ajaxpUload(userImgUrls,idx){
            var $btnSelectPic = $('#btnSelectPic'+idx);
            $btnSelectPic.append('<div class="hover">图片上传中...</div>');
            Zepto.ajax({
                type:'post',
                url: ApiPrefix+'/find/imgUpload',
                data: {imgData:userImgUrls},
                cache: false,
                success: function(data){
                  if(data.errorMessage=='token不合法'){
                    MZ.wechat.checkLogin(data);
                    return;
                  }
                  if(data.status==1){
                   $btnSelectPic.addClass('upload');
                   $btnSelectPic.attr('data-src',data.data)
                  }else{
                    MZ.alert({content:data.msg,callback:function(){
                        switch(idx){
                            case 1: 
                                upload01.remove();
                                break;
                            case 2: 
                                upload02.remove();
                                break;
                            case 3: 
                                upload03.remove();
                                break;
                        }
                        $btnSelectPic.find('.btn-add').css('display','block');
                        $btnSelectPic.find('input').css('opacity','0');
                        $btnSelectPic.find('.btn-close').remove();
                    }});
                  }
                  $btnSelectPic.find('.hover').remove();
                  $btnSelectPic.removeClass('uploading');
                },
                error: function(err){
                    $btnSelectPic.removeClass('uploading');
                    MZ.alert({content:'网络连接出错，图片上传失败'});
                    $btnSelectPic.find('.hover').remove();
                }
              })
        }
    }
    modules.exports = App;
});
