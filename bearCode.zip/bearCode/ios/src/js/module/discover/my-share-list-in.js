define(function(require, exports,modules) {
    var App = {};
    var LoadMore = require('widgets/load-more');
    function layout(){
        
    }
    App.init = function(){
        addEvent();
        layout();
        setTimeout(function(){
            $('#pageLottery').fadeIn();
            setTimeout(function(){
                $('#pageLottery').addClass('animatein');
            },500)
        },1000)
        $('.btn-close').on('click',function(){
            $('#pageLottery').removeClass('active');
        })
        MZ.utils.initEcho();
        loadmore();
        getList();
    }
    function loadmore(){
        //初始化下拉加载更多
        $(document).on('scroll touchmove',function(){
            if(HasNoMore){
              $('.loading-more').hide();
              return;
            }
            if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
                if($('.loading-more').length==0){
                    getList();
                }
            }
        });
    }
    var Page = 1;
    var Loading = false;
    var HasNoMore = false;
    function getList(){
        if(Loading)return;
        Loading = true;
        if(HasNoMore)return;
        var pageSize=10
        Zepto.ajax({
            url: ApiPrefix+'/find/mySharelist',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,"pageSize": pageSize,"pageNumber":Page},
            cache: false,
            dataType: 'json',
            success: function(data){
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                log(data)
                if(data.status==1){
                    var $list = $('.for-share-list');
                    var str = '';
                    var list = data.data;
                    for(var i in list) {
                        var item = list[i];
                        var imgList = item.sharePicUrl.split(',');
                        var imgStr = '';
                        for(var i in imgList){
                          imgStr+='<dd><img src="'+ImgBlank+'" data-echo="'+imgList[i]+'"></dd>';
                        }
                        str += '<li class="table-view-cell media" onclick="location.href=\'share-detail.html?id='+item.id+'\'">'+
                                '<div class="pic-left"><img src="'+item.avatarUrl+'"></div>'+
                                '<div class="media-body">'+
                                 ' <h4><span class="fr">'+item.createTime+'</span>'+item.nickname+'</h4>'+
                                 ' <p>'+item.winWords+'</p>'+
                                 ' <dl class="pic-list">'+imgStr+
                                 ' </dl><div class="more">'+
                                 '   <div class="fr"><a href="../detail.html?id=0&goodsId='+item.goodsId+'" class="btn btn-red-transparent">我也要</a></div>'+
                                 '   <div class="fl">'+
                                 '     <p>'+item.goodsName+'</p>'+
                                 '     <p>期号：'+item.goodsRobId+'</p>'+
                                 '   </div>'+
                                 ' </div>'+
                                '</div>'+
                           ' </li>';
                    }
                    $list.append(str);
                    MZ.utils.initEcho();
                    if(Page==1 && list.length == 0){
                      var str = '<div class="cart-empty" style="margin-top:20%;">'+
                                 ' <i class="icon icon-img_empty"></i>'+
                                 ' <h3>暂无晒单记录</h3>'+
                                '</div>';
                      $('.footer-icon').hide();
                      $('body').append(str);
                    }else if(list.length<pageSize){
                     HasNoMore = true;
                     var nomorestr='<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;">没有更多记录</div>';
                     $list.append(nomorestr);
                    }
                    //图片延迟加载
                    MZ.utils.initEcho();
                    Page++;
                }else{
                    MZ.alert({content: data.errorMessage});
                }
                Loading = false;
            },
            error: function(){
              Loading = false;
            }
        })
        
    }
    function addEvent(){
        var $body = $('body'),
            $friendIndexFixed = $('#friendIndexFixed'),
            $friendIndexFixedHeight = $('#friendIndexFixedHeight');
        MZ.browser.sticky && $friendIndexFixed.addClass('sticky');
        MZ.browser.sticky || (document.addEventListener("touchmove", function () {
            scroll();
        }), document.addEventListener("scroll", function () {
            scroll();
        }))      
        function scroll() {
            var top = $body.scrollTop();
            if(top>=365){
                $friendIndexFixed.addClass('fixed-tab');
                $friendIndexFixedHeight.height(96);
            }else{
                $friendIndexFixed.removeClass('fixed-tab');
                $friendIndexFixedHeight.height(0);
            }
        }
    }
    
    modules.exports = App;
});
