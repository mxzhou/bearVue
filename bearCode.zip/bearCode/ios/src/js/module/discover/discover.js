define(function(require, exports,modules) {
    var App = {};
    var LoadMore = require('widgets/load-more');
    function layout(){
        
    }
    App.init = function(){
        addEvent();
        layout();
        //设置底部导航选中样式
        MZ.setNavStatus(2);
        getList();
    }
    function addEvent(){
        
    }
    var Page = 1;
    function getList(){
      Zepto.ajax({
          url: ApiPrefix+'/find/list',
          type: 'post',
          data: {token:MZ.utils.getToken(),kgUid:kgUid,"status": 0,"pageSize": 10,"pageNumber":Page},
          cache: false,
          success: function(data){
              log(data)
              if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
              if(data.status==1){
                  var list = data.data.activityList;
                  var str = '';
                  for(var i in list){
                      var item = list[i];
                      var typestr = '' ;
                      if(item.sign==1){
                        typestr = '<span class="badge badge-positive">NEW</span>';
                      }else if(item.sign==2){
                        typestr = '<span class="badge badge-positive red">HOT</span>';
                      }
                      var link = '';
                      if(item.headType==1){
                          //url地址url有值
                          link = item.url;
                      }else if(item.headType==2){
                          link = '../search.html?searchContent='+item.searchContent;
                      }else if(item.headType==3){
                          link = '../detail.html?goodsId='+item.uniqueId+'&id=0';
                      }
                      str+='<li class="table-view-cell media">'+
                            '  <a href="'+link+'">'+
                            '    <div class="pic-left"><img src="'+item.coverImgUrl+'"></div>'+
                            '    <div class="media-body">'+
                            '      <h4>'+item.title+typestr+'</h4>'+
                            '      <p>'+item.remark+'</p>'+
                            '    </div>'+
                            '  </a>'+
                            '</li>';
                  }
                  $('#listDiscover').html(str);
              }else{
                  MZ.alert({content: data.errorMessage});
              }
          },
          error: function(){
            Loading = false;
          }
      })
    }
    modules.exports = App;
});
