define(function(require, exports,modules) {
    var App = {};
    var win = window,
        doc = win.document;
    var LoadMore = require('widgets/load-more');
    function layout(){
        
    }
    var GOODSID;
    App.init = function(){
        GOODSID = MZ.utils.getQueryString('goodsId');
        GOODSID = GOODSID == null?0:GOODSID;        
        addEvent();
        layout();
        setTimeout(function(){
            $('#pageLottery').fadeIn();
            setTimeout(function(){
                $('#pageLottery').addClass('animatein');
            },500)
        },1000)
        $('.btn-close').on('click',function(){
            $('#pageLottery').removeClass('active');
        })
        MZ.utils.initEcho();
        loadmore();
        getList();
    }
    function loadmore(){
        //初始化下拉加载更多
        $(document).on('scroll touchmove',function(){
            if(HasNoMore){
              $('.loading-more').hide();
              return;
            }
            if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
                if($('.loading-more').length==0){
                    getList();
                }
            }
        });
    }
    var Loading = false;
    var HasNoMore = false;
    var LastId = 0;
    var Page = 1;
    function getList(){
        if(Loading)return;
        Loading = true;
        Zepto.ajax({
            url: ApiPrefix+'/find/sharelist',
            type: 'post',
            data: {token:MZ.utils.getToken(),pageNumber:Page,pageSize:20,goodsId:GOODSID},
            cache: false,
            success: function(data){
              if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                log(data);
                if(data.status==1){
                    var $list = $('.for-share-list');
                    var str = '';
                    var list = data.data;
                    if(list.length==0){
                      HasNoMore = true;
                      if(Page==1){
                        str+='<div class="cart-empty" style="margin-top:30%;"> <i class="icon icon-cartempty"></i> <h3>暂无晒单记录</h3><a href="../index.html" class="btn btn-red-transparent">马上去夺宝</a></div>';
                        $('.footer-icon').hide();
                      }
                      $(str).insertAfter($list);
                    }else{
                      for(var i in list){
                        var item = list[i];
                        var imgList = item.sharePicUrl.split(',');
                        var imgStr = '';
                        for(var i in imgList){
                          imgStr+='<dd style="background:url('+imgList[i]+') center center;background-size:cover;"></dd>';
                        }
                        var userimg = item.avatarUrl;
                        if(userimg==''||userimg==null){
                            userimg = ImgUser;
                        }
                        var isGreat = '';
                        if(item.recommStatus==1){
                          isGreat = 'great';
                        }
                        str += '<li class="table-view-cell media '+isGreat+'" onclick="location.href=\'share-detail.html?id='+item.id+'\'">'+
                                '<div class="pic-left"><img src="'+userimg+'"></div>'+
                                '<div class="media-body">'+
                                 ' <h4><span class="fr">'+item.createTime+'</span>'+item.nickname+'</h4>'+
                                 ' <p>'+item.winWords+'</p>'+
                                 ' <dl class="pic-list">'+imgStr+
                                 ' </dl><div class="more">'+
                                 '   <div class="fr"><a href="../detail.html?id=0&goodsId='+item.goodsId+'" class="btn btn-red-transparent">我也要</a></div>'+
                                 '   <div class="fl">'+
                                 '     <p>'+item.goodsName+'</p>'+
                                 '     <p>期号：'+item.goodsRobId+'</p>'+
                                 '   </div>'+
                                 ' </div>'+
                                '</div>'+
                           ' </li>';
                      }
                      Page++;
                      $list.append(str);
                       //延迟加载
                      MZ.utils.initEcho();
                    }
                }else{
                    MZ.alert({content: data.errorMessage});
                }
                Loading = false;
            },
            error: function(){
              Loading = false;
            }
        })
        
    }
    function addEvent(){
        
    }
    
    modules.exports = App;
});
