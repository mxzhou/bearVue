define(function(require, exports,modules) {
    var App = {};
    var totalCost = 0,money=0;
    var orderNo,token,kgUid;
    App.init = function(){
    	token = sessionStorage.getItem('token');
        kgUid = sessionStorage.getItem('kgUid');
        orderNo = MZ.utils.getQueryString('order_no');
        if(orderNo == null || orderNo == 'null'){
            MZ.alert({content:'查询内容不正确',callback:function(){
                location.href = 'recharge.html';
            }})
        }else{
            checkPayResult();
        }
        //MZ.showPrize({id:1,number:23,name:'2343234'});
    }
    function checkPayResult(){
        Zepto.ajax({
            url: ApiPrefix+'/pay/result/get',
            type: 'post',
            data: {token:token,kgUid:kgUid,payOrderNo:orderNo},
            cache: false,
            success: function(data){
                log(data);
              /*  if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }*/
               // alert(JSON.stringify(data));
                $('#payStatus').hide();
                if(data.status==1){
                    $('#paySuccess').show();
                    $('#addMoney').html(data.data.addMoney);
                }else{
                    $('#payFail').show();
                    //MZ.alert({content: data.errorMessage});
                }
           
            },
            error: function(){
          
            }
        })
    }    
   
    modules.exports = App;
});
