define(function(require, exports,modules) {
    var App = {};
    App.init = function(){
    	sessionStorage.setItem('kgUid',MZ.utils.getQueryString('kgUid'));
    	sessionStorage.setItem('token',MZ.utils.getQueryString('token'));
        addEvent();

    }

    function addEvent(){
        $('.jsItem').on('click',function(){
          var $this = $(this);
          if($this.find('input').length!=0){
            $(this).addClass('active').siblings('.jsItem').removeClass('active');
          }else{
            $(this).toggleClass('active').siblings('.jsItem').removeClass('active');
          }
        })
        $('#money').on('blur',function(){
          var $this = $(this);
          var value = $this.val();
          if(!/^[1-9]\d*$/g.test(value)){
            MZ.alert({content:'请输入数字'});
            $this.val(1);    
          }
          if(value<1){
            $this.val(1);            
          }
       })
        $('#btnRecharge').on('touchend',function(e){
            var $active = $('.jsItem.active');
            e.preventDefault();
            if($active.length==0){
                MZ.alert({content:'请先选择金额'});
                return;
            }
            var money=0;
            if($active.find('input').length!=0){
                var money = $('#money').val().replace(/\s/g,'');
                if(!/^[1-9]\d*$/g.test(money)){
                  MZ.alert({content:'请输入数字'});
                  $('#money').val(1);   
                  return;
                }
                if(money==''){
                    MZ.alert({content:'金额不能为空'});
                    return;
                }
                if(money<1){
                  MZ.alert({content:'最少充值1元'});
                  $('#money').val(1); 
                  return;
                }
            }else{
                money = $active.text();
            }
            Zepto.ajax({
                url: ApiPrefix+'/pay/submit',
                type: 'post',
                data: {token:MZ.utils.getQueryString('token'),kgUid:MZ.utils.getQueryString('kgUid'),money:money,payType:6,source:'App Store'},
                dataType:'json',
                cache: false,
                success: function(data){
                  if(data.errorMessage=='token不合法'){
                    MZ.wechat.checkLogin(data);
                    return;
                  }
                	if(data.status==1){
                		location.href = data.data.wapalipay;
                   }else{
                   	MZ.alert({content:data.errorMessage});
                   }
                         
                },
                error: function(){
              
                }
            })
            e.preventDefault();
        })
    }
    modules.exports = App;
});
