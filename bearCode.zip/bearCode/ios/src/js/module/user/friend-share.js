define(function(require, exports,modules) {
    var App={};
    var LoadMore = require('widgets/load-more');
    var win = window,
    doc = win.document;
    var targetKgUid;
    App.init = function(){
       targetKgUid = MZ.utils.getQueryString('id');
       getUserDetail()
       addEvent();
       loadmore();
       getList();
    }
    function loadmore(){
        //初始化下拉加载更多
        $(document).on('scroll touchmove',function(){
            if(HasNoMore){
              $('.loading-more').hide();
              return;
            }
            if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
                if($('.loading-more').length==0){
                    getList();
                }
            }
        });
    }
    var Page = 1;
    var Loading = false;
    var HasNoMore = false;
    var lastId = 0;
    function getList(){
        if(Loading)return;
        Loading = true;
        if(HasNoMore)return;
        var pageSize=10
        Zepto.ajax({
            url: ApiPrefix+'/find/mySharelist',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,"pageSize": pageSize,pageNumber:Page,targetKgUid:targetKgUid},
            cache: false,
            success: function(data){
                log(data)
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    var $list = $('.for-good-list');
                    var str = '';
                    var list  = data.data.winLogList;                   
                    for(var i in list) {
                        var item = list[i];
                        str += '<li class="table-view-cell media" onclick="location.href=\'share-detail.html?'+item.uniqueNo+'\'">'+
                            '<div class="pic-left"><img src="../../src/images/user.jpg"></div>'+
                            '<div class="media-body">'+
                             ' <h4><span class="fr">01-25 22:32</span>'+item.nickname+'</h4>'+
                             ' <p>'+item.content+'</p>'+
                             ' <dl class="pic-list">'+imgStr+
                             ' </dl><div class="more">'+
                             '   <div class="fr"><a href="../detail.html?goodsId='+item.goodsId+'&id=0" class="btn btn-red-transparent">我也要</a></div>'+
                             '   <div class="fl">'+
                             '     <p>'+item.title+'</p>'+
                             '     <p>期号：'+item.uniqueNo+'</p>'+
                             '   </div>'+
                             ' </div>'+
                            '</div>'+
                       ' </li>';
                    }
                    $list.append(str);
                    if(Page==1 && list == null){
                      var str = '<div class="cart-empty" style="margin-top:10%;">'+
                                 ' <i class="icon icon-img_empty"></i>'+
                                 ' <h3>该用户暂无晒单记录</h3>'+
                                '</div>';
                      $('.footer-icon').hide();
                      $('body').append(str);
                    }else if(list.length<pageSize){
                     HasNoMore = true;
                     var nomorestr='<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;">没有更多记录</div>';
                     $list.append(nomorestr);
                    }
                    //图片延迟加载
                    MZ.utils.initEcho();
                    Page++;
                }else{
                  log(data.errorMessage)
                    //MZ.alert({content: data.errorMessage});
                }
                Loading = false;
            },
            error: function(){
              Loading = false;
            }
        })
        
    }
    function getUserDetail(){
      Zepto.ajax({
        type:'post',
        url: ApiPrefix+'/user/detail',
        data: {token:MZ.utils.getToken(),kgUid:kgUid,targetKgUid:targetKgUid},
        cache: false,
        success: function(data){
          if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
          if(data.status==1){
            var info = data.data;
            $('#username').html(info.nickname);
            $('#userid').html(info.kgUid);
            $('#userpic').html('<img src="'+info.avatarUrl+'">');
          }else{
            MZ.alert({content:data.errorMessage})
          }
        },
        error: function(err){
        }
      })
    }
    function addEvent(){
      var $body = $('body'),
            $friendIndexFixed = $('#friendIndexFixed'),
            $friendIndexFixedHeight = $('#friendIndexFixedHeight');
        MZ.browser.sticky && $friendIndexFixed.addClass('sticky');
        MZ.browser.sticky || (document.addEventListener("touchmove", function () {
            scroll();
        }), document.addEventListener("scroll", function () {
            scroll();
        }))      
        function scroll() {
            var top = $body.scrollTop();
            if(top>=365){
                $friendIndexFixed.addClass('fixed-tab');
                $friendIndexFixedHeight.height(96);
            }else{
                $friendIndexFixed.removeClass('fixed-tab');
                $friendIndexFixedHeight.height(0);
            }
        }
        $('.control-item').each(function(){
          var $this = $(this);
          $this.attr('href',$this.attr('href')+'?id='+targetKgUid);
        })
    }
    
    modules.exports = App;
});
