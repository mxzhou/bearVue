define(function(require, exports,modules) {
    var App={};
    App.init = function(){
    	addEvent();
    	ajaxGetUserDetail();
    }
    function addEvent(){
    	$('#btnSave').on('touchend',function(e){
    		var username = $('#username').val();
    		if(username.replace(/\s/g,'')==''){
    			MZ.alert({content:"请输入昵称"});
    			return;
    		}
    		if(username.replace(/\s/g,'').length<1){
    			MZ.alert({content:"至少输入1个字符"});
    			return;
    		}
    		Zepto.ajax({
		        url: ApiPrefix+'/user/nickname/update',
		        type: 'post',
		        data: {token:MZ.utils.getToken(),kgUid:kgUid,nickname:username.replace(/<*>*/g,'')},
		        cache: false,
		        success: function(data){
		        	if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
		        	log(data)
		            if(data.status==1){
		            	MZ.alert({content:'修改成功',callback:function(){
		            		location.href = 'userinfo.html'
		            	}});
		            }else{
		                MZ.alert({content: data.errorMessage});
		            }
		        },
		        error: function(){
		          Loading = false;
		        }
		    })
    		e.preventDefault();
    	})
    }
   	function ajaxGetUserDetail(){
	    Zepto.ajax({
	        url: ApiPrefix+'/user/detail',
	        type: 'post',
	        data: {token:MZ.utils.getToken(),targetKgUid:kgUid},
	        cache: false,
	        success: function(data){
	        	if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
	        	log(data)
	            if(data.status==1){
	            	var user = data.data;
	                $("#username").val(user.nickname);
	            }else{
	                MZ.alert({content: data.errorMessage});
	            }
	        },
	        error: function(){
	          Loading = false;
	        }
	    })
    }
    modules.exports = App;

});
