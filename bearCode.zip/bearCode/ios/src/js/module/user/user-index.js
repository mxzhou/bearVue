define(function(require, exports,modules) {
    var App={};
    
    App.init = function(){

       addEvent();
       ajaxGetUserDetail();
       ajaxGetMsgNum();
       ajaxGetUserMoney();
       //设置底部导航选中样式
       MZ.setNavStatus(4);
       getQQ();
       /*var loading = new MZ.loading();
       setTimeout(function(){
        loading.finish();
       },2000)*/
       //MZ.showShareResult({title:23,desc:34});
       //MZ.showLuckyBag({title:23,desc:34});
    }
    function addEvent() {
    	$('#btnFxPrize').on('touchend',function(e){
            MZ.alert({content:"此功能暂未开放"});
            e.preventDefault();
        })
    }
    function ajaxGetUserDetail(){
	    Zepto.ajax({
	        url: ApiPrefix+'/user/detail',
	        type: 'post',
	        data: {token:MZ.utils.getToken(),targetKgUid:kgUid},
	        cache: false,
	        success: function(data){
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
	            if(data.status==1){
	                $("#nickname").text(data.data.nickname);
	                $("#userId").text("ID:"+data.data.kgUid);
                    var userimg = data.data.avatarUrl;
                    if(userimg==''||userimg==null){
                        userimg = ImgUser;
                    }
	                $("#headImg").attr("src",userimg);
	            }else{
	                MZ.alert({content: data.errorMessage});
	            }
	        },
	        error: function(){
	          Loading = false;
	        }
	    })
    }
    function getQQ(){
        Zepto.ajax({
            url: ApiPrefix+'/server/qq',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid},
            cache: false,
            success: function(data){
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    log(data);
                    var qqlist = data.data;
                    var str = '';
                    for(var i in qqlist){
                        if(i==qqlist.length-1){
                            str+= qqlist[i].qqGroup;
                        }else{
                            str+= qqlist[i].qqGroup+ '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
                        }
                    }
                    $('#qq').html(str);
                }else{
                    
                }
            },
            error: function(){
              Loading = false;
            }
        })
    }
    function ajaxGetUserMoney(){
	    Zepto.ajax({
	        url: ApiPrefix+'/user/consumeMoney',
	        type: 'post',
	        data: {token:MZ.utils.getToken(),kgUid:kgUid},
	        cache: false,
	        success: function(data){
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
	        	log(data);
	            if(data.status==1){
	            	$("#money").text("余额: "+data.data+" 夺宝币");  
	            }else{
	                MZ.alert({content: data.errorMessage});
	            }
	        },
	        error: function(){
	          Loading = false;
	        }
	    })
    }
    function ajaxGetMsgNum(){
        Zepto.ajax({
            url: ApiPrefix+'/messageNum/getNum',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid},
            cache: false,
            success: function(data){
                log(data)
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    if(data.data!=null){
                        var msg =data.data;
                        var count = msg.sysNum+msg.activityNum+msg.logisticsNum;
                        log(data)
                        if(count!=0){
                            $('#btnMsg .badge').html(count).show();
                        }
                    }
                }else{
                    //MZ.alert({content: data.errorMessage});
                }
            },
            error: function(){
            }
        })
        
    }
    getMyRedEnvelopeNumber();
    function getMyRedEnvelopeNumber(){
        Zepto.ajax({
            url: ApiPrefix+'/user/redEnvelopeNumber',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid},
            cache: false,
            success: function(data){
                log(data)
                if(data.errorMessage=='token不合法'){
                  MZ.wechat.checkLogin(data);
                  return;
                }
                if(data.status==1){
                    log(data)
                    $('#redEnvelopeNumber').html(data.data+'个');
                }else{
                    //MZ.alert({content: data.errorMessage});
                }
            },
            error: function(){
            }
        })
    }
    modules.exports = App;

});
