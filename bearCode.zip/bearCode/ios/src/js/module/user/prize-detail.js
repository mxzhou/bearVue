define(function(require, exports,modules) {
    var App = {};
    var win = window,
    doc = win.document;
    function layout(){
        
    }
    var ID;
    App.init = function(){
        ID = MZ.utils.getQueryString('id');
        addEvent();
        layout();
        ajaxGetDetail();
    }
    
    function addEvent(){
        $('#btnLink').on('click',function(){
            location.href = $(this).attr('data-href');
        })
    }
    function ajaxGetDetail(){
        Zepto.ajax({
            url: ApiPrefix+'/user/win/logInfo',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,targetKgUid:0,id:ID},
            cache: false,
            success: function(data){
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    if(data.data!=null){
                        var info =data.data;
                        var orderStatus = info.orderStatus;
                        var $itemStatus = $('.item-status');
                        if(orderStatus==0) {
                            $('#addressInfo').hide();
                            $('#logisticInfo').hide();
                            $itemStatus.eq(0).addClass('active');
                        }else if(orderStatus==1){
                            $('#logisticInfo').hide();
                            $itemStatus.eq(0).addClass('done');
                            $itemStatus.eq(1).addClass('active');
                            $('#setAddressTime').html(MZ.utils.formatDate(info.setAddressTime));
                        }else if(orderStatus==2){
                            $('#logisticInfo').hide();
                            $itemStatus.eq(0).addClass('done');
                            $itemStatus.eq(1).addClass('active');
                            $('#setAddressTime').html(MZ.utils.formatDate(info.setAddressTime));
                        }else if(orderStatus==3){
                            $itemStatus.eq(0).addClass('done');
                            $itemStatus.eq(1).addClass('done');
                            $itemStatus.eq(2).addClass('active');
                            $('#setAddressTime').html(MZ.utils.formatDate(info.setAddressTime));
                            $('#sendTime').html(MZ.utils.formatDate(info.sendTime));
                            log(MZ.utils.formatDate(info.sendTime))
                        }else if(orderStatus==5){
                            $itemStatus.eq(0).addClass('done');
                            $itemStatus.eq(1).addClass('done');
                            $itemStatus.eq(2).addClass('done');
                            $itemStatus.eq(3).addClass('done');
                            $('#sendTime').html(MZ.utils.formatDate(info.sendTime));
                            $('#okTime').html(MZ.utils.formatDate(info.okTime));
                            $('#setAddressTime').html(MZ.utils.formatDate(info.setAddressTime));
                        }
                        $('#btnLogic').attr('href','http://m.kuaidi100.com/index_all.html?postid='+info.logisticsNo);
                        $('#logisticsCompany').html(info.logisticsCompany);
                        $('#logisticsNo').html(info.logisticsNo);
                        $('#mobile').html(info.mobile);
                        $('#address').html(info.address);
                        $('#receiver').html(info.receiver);
                        $('#number').html(info.id);
                        $('#needNumber').html(info.needNumber);
                        $('#winCode').html(info.winCode);
                        $('#joinNumber').html(info.joinNumber);
                        $('#openTime').add('#openTimeItem').html(MZ.utils.formatDate(info.openTime));
                        $('.goodsName').html('<a class="link-black" href="../detail.html?goodsId='+info.goodsId+'&id='+info.id+'">'+info.goodsName);
                        $('#coverImgUrl').attr('src',info.coverImgUrl);
                        $('#btnLink').attr('data-href','../detail.html?goodsId='+info.goodsId+"&id="+info.id);
                    }
                }else{
                    //MZ.alert({content: data.errorMessage});
                }
            },
            error: function(){
            }
        })
    }
    modules.exports = App;
});
