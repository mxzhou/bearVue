define(function(require, exports,modules) {
    var App={};
    App.init = function(){
    	ajaxGetUserDetail();
    	addEvent();
    }
    var CodeValid;
    function ajaxGetUserDetail(){
	    Zepto.ajax({
	        url: ApiPrefix+'/user/detail',
	        type: 'post',
	        data: {token:MZ.utils.getToken(),targetKgUid:kgUid},
	        cache: false,
            async: false,
	        success: function(data){
	        	if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
	        	log(data)
	            if(data.status==1){
	            	var user = data.data;
	                if(user.mobile!=null){
	                	location.href='edit-phone.html';
	                }
	            }else{
	                MZ.alert({content: data.errorMessage});
	            }
	        },
	        error: function(){
	          Loading = false;
	        }
	    })
    }
    var Timer;
    function addEvent(){
    	$('#btnCode').on('click',function(e){
    		var $this = $(this);
    		if($this.hasClass('disable'))return;
    		var $phone = $('#phone'),
    			phone = $phone.val().replace(/\s/g,'');
    		if(phone==''){
    			MZ.alert({content:"请输入手机号码"});
    			return;
    		}
    		if(!/^[1][0-9]{10}$/.test(phone)){ 
    			MZ.alert({content:"请输入正确的手机号码"});
    			return;
    		}
    		sendCode(phone)    		
    		$this.addClass('disable');
    		e.preventDefault();
    	})
    	$('#btnBanding').on('click',function(e){
    		var $this = $(this);
    		if($this.hasClass('disable'))return;
    		var $phone = $('#phone'),
    			phone = $phone.val().replace(/\s/g,'');
    		var $code = $('#code'),
    			code = $code.val().replace(/\s/g,'');
    		if(phone==''){
    			MZ.alert({content:"请输入手机号码"});
    			return;
    		}
    		if(!/^[1][0-9]{10}$/.test(phone)){ 
    			MZ.alert({content:"请输入正确的手机号码"});
    			return;
    		}
    		if(code==''){
    			MZ.alert({content:"请输入短信验证码"});
    			return;
    		}
    		if(code!=CodeValid){
    			MZ.alert({content:"验证码错误"});
    			return;
    		}
    		$this.hasClass('disable');
    		banding(phone,code);
    		e.preventDefault();
    	})
    }
    var Time = 60;
    function countDown(){
		if(Time>0){
            Time--;
            $('#btnCode').text(Time+'秒');
        }else{
            Time = 60;
            clearInterval(Timer);
            $('#btnCode').text('获取验证码').removeClass('disable');
        }
    }
   	function sendCode(phone){
   		var p = "54915177aa79e93afaf4ab66bbc4f123dfac4d81d9e7dac87a0d19aaf476dc0ec4583cf83beb8d3ee55ee1a5a87831a07abcd76480b33d513da70e030537da9aeea03e336953fab2fbae2873fc034236dda16fd93772512e8a2254e7611ec6747472c08d257c50bd3c61dc4d018ceb9b85b293f7c337e626ea92376e79963c8b";
	    Zepto.ajax({
	        url: ApiPrefix+'/message/mobileCode/send',
	        type: 'post',
	        data: {token:MZ.utils.getToken(),mobile:phone,businessid:2,p:p},
	        dataType: 'json',
	        cache: false,
	        success: function(data){
	        	if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
	        	log(data)
	            if(data.status==1){
	            	if(data.data.count==0){
	            		MZ.alert({content:'您今天发送短信的次数已经没有了'});
	            		$('#btnCode').removeClass('disable')
	            	}else{
	            		CodeValid = data.data.code;
	            		$('#tips').show();
	            		$('#phoneArea').html(phone);
	            		$('#btnCode').text('60秒');
	            		Time = 60;
	            		Timer = setInterval(countDown,1000);
	            	}
	            }else{
	            	$('#btnCode').removeClass('disable')
	                MZ.alert({content: data.errorMessage});
	            }
	        },
	        error: function(){
	         $('#btnCode').removeClass('disable')
	         MZ.alert({content: '发送出错，请重新尝试'});
	        }
	    })
    }
    function banding(phone,code){
	    Zepto.ajax({
	        url: ApiPrefix+'/user/mobile/bind',
	        type: 'post',
	        data: {token:MZ.utils.getToken(),kgUid:kgUid,mobile:phone,code:code},
	        dataType: 'json',
	        cache: false,
	        success: function(data){
	        	if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
	        	log(data)
	            if(data.status==1){
	            	MZ.alert({content: '绑定成功',callback:function(){
	            		location.href = 'userinfo.html';
	            	}});
	            }else{
	                MZ.alert({content: data.errorMessage});
	            }
	            $('#btnBanding').removeClass('active');
	        },
	        error: function(){
	        	MZ.alert({content: '服务器出错'});
	          $('#btnBanding').removeClass('active');
	        }
	    })
    }
    modules.exports = App;

});
