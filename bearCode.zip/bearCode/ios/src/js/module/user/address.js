define(function(require, exports,modules) {
    var App = {};
    var LoadMore = require('widgets/load-more');
    function layout(){
        
    }
    var RobId;
    App.init = function(){
        RobId = MZ.utils.getQueryString('robid');
        if(RobId!=null && RobId!='null'){
          $('#btnAddAddress').attr('href','address-add.html?robid='+RobId);
          $('#btnChoose').show();
        }else{
          $('#btnAddAddress').attr('href','address-add.html');
        }
        addEvent();
        layout();
        getList();
    }
    function getList(){
        Zepto.ajax({
        type:'post',
        url: ApiPrefix+'/user/address/list',
        data: {token:MZ.utils.getToken(),kgUid:kgUid},
        dataType:'json',
        cache: false,
        success: function(data){
          if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
          if(data.status==1){
            var $list = $('.address');
            var str = '';
            var list  = data.data;
            if(list.length == 0){
              /*MZ.confirm({content:'暂无收货地址，是否现在就去添加？',callback:function(){
                location.href = 'address-add.html';
              }})*/
              var str = '<div class="empty-address"><i class="icon icon-img_addaddressarrow"></i><div class="iconmsg"><i class="icon icon-img_noadd"></i><br>您尚未添加任何收货地址</div></div>';
              $('body').append(str);
              $('#btnChoose').hide();
             return; 
            }
            var Icon = '',
                Margin = '';
            if(RobId!=null && RobId!='null'){
              Icon = '<i class="icon icon-radio"></i>';
            }else{
              Margin = 'margin-left:20px;';
            }
            var defaultitem = '';
            for(var i in list) {
                var item = list[i];
                var ifDefault = item.ifDefault;
                if(ifDefault){
                  defaultitem = '<li class="table-view-cell media active" onclick="" data-id="'+item.id+'">'+
                         ' <div class="navigate-right">'+
                         '   <div class="media-left">'+Icon+'</div>'+
                         '   <div class="media-body" style="'+Margin+'">'+
                         '   <p class="blue"><span class="fr gray">'+item.mobile+'</span>'+item.receiver+'</p>'+
                         '   <p class="addres-desc"><a href="address-edit.html?id='+item.id+'&robid='+RobId+'" class="fr"><i class="icon icon-edit-wechat"></i></a><span class="green">[默认]</span>'+item.province+item.city+item.area+item.addressDetail+'</p>'+
                         '   </div>'+
                         ' </div>'+
                       ' </li>';
                }else{
                  str += '<li class="table-view-cell media" onclick="" data-id="'+item.id+'">'+
                         ' <div class="navigate-right">'+
                         '   <div class="media-left">'+Icon+'</div>'+
                         '   <div class="media-body" style="'+Margin+'">'+
                         '   <p class="blue"><span class="fr gray">'+item.mobile+'</span>'+item.receiver+'</p>'+
                         '   <p class="addres-desc"><a href="address-edit.html?id='+item.id+'&robid='+RobId+'" class="fr"><i class="icon icon-edit-wechat"></i></a>'+item.province+item.city+item.area+item.addressDetail+'</p>'+
                         '   </div>'+
                         ' </div>'+
                       ' </li>';
                }
                
            }
            $list.html(defaultitem+str);
          }else{
            MZ.alert({content:data.errorMessage})
          }
        },
        error: function(err){
        }
      })
        
    }
    function addEvent(){
        $(document).delegate('.radio-list li','click',function(){
            var $this = $(this);
            $this.toggleClass('active').siblings('li').removeClass('active');
        })
        //确定
        $('#btnChoose').on('touchend',function(e){
            var $choose = $('li.active');
            var addressId = $choose.attr('data-id');
            Zepto.ajax({
                type:'post',
                url: ApiPrefix+'/user/win/setAddress',
                data: {token:MZ.utils.getToken(),kgUid:kgUid,userAddressId:addressId,id:RobId},
                dataType:'json',
                cache: false,
                success: function(data){
                  if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                    if(data.status==1){
                        if(data.data){
                            MZ.alert({content:'设置成功',callback:function(){
                                location.href = 'prize-detail.html?id='+RobId;
                            }})
                        }else{
                            MZ.alert({content:'设置失败，请重新尝试'})
                        }
                    }else{
                        MZ.alert({content:data.errorMessage})
                    }
                }
            })
            e.preventDefault();
        })
    }
    modules.exports = App;
});
