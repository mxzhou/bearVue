define(function(require, exports,modules) {
    var App={};
    var ID,RobId;
    App.init = function(){
       ID = MZ.utils.getQueryString('id');
       RobId = MZ.utils.getQueryString('robid');
       getList();
       addEvent();

    }
    function getList(){
        Zepto.ajax({
	        type:'post',
	        url: ApiPrefix+'/user/address/list',
	        data: {token:MZ.utils.getToken(),kgUid:kgUid},
	        dataType:'json',
	        cache: false,
	        success: function(data){
	        	if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
	        	if(data.status==1){
	        		var data = data.data;
	        		var info = {};
	        		for(var i in data){
	        			var item = data[i];
	        			if(item.id == ID){
	        				info = item;
	        				$('#receiver').val(info.receiver);
	        				$('#mobile').val(info.mobile);
	        				$('#addressDetail').val(info.addressDetail);
	        				if(item.ifDefault){
	        					$('#isDefault').addClass('active');
	        				}
	        				//获取省份
	        				getAddress($('#s_province'),1,1);
	        				$('#s_province').val(info.province);
	        				$('#s_province').change();
	        				var provinceid = $('#s_province option').not(function(){ return !this.selected }).attr('data-id');
	        				//根据省份id查询省份下的城市列表
	        				getAddress($('#s_city'),2,provinceid);
	        				$('#s_city').val(info.city);
	        				$('#s_city').change();
	        				var cityid = $('#s_city option').not(function(){ return !this.selected }).attr('data-id');
	        				getAddress($('#s_county'),3,cityid);
	        				$('#s_county').val(info.area);
	        			}
	        		}
	        	}else{
	        		MZ.alert({content:data.errorMessage})
	        	}
	        }
	    })
    }
    function deleteAddress(){
    	Zepto.ajax({
	        type:'post',
	        url: ApiPrefix+'/user/address/delete',
	        data: {token:MZ.utils.getToken(),kgUid:kgUid,userAddressId:ID},
	        dataType:'json',
	        cache: false,
	        success: function(data){
	        	if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
	        	if(data.status==1){
	        		if(data.data){
	        			MZ.alert({content:'删除成功',callback:function(){
	        				location.href = 'address.html?robid='+RobId;
	        			}})
	        		}else{
	        			MZ.alert({content:'删除失败，请重新尝试'})
	        		}
	        	}else{
	        		MZ.alert({content:data.errorMessage})
	        	}
	        }
	    })
    }
    function addEvent(){

    	$('#btnDelete').on('touchend',function(e){
    		MZ.confirm({
    			content:"确定删除地址吗？",
    			callback:function(){
    				deleteAddress();
	    		}
	    	})
    		e.preventDefault();
    	})
    	$('#btnSave').on('touchend',function(e){
    		var mobile = $('#mobile').val();
    		var receiver = $('#receiver').val();
    		var addressDetail = $('#addressDetail').val();
    		var ifDefault = $('#isDefault').hasClass('active');
    		var province = $('#s_province').val();
    		var city = $('#s_city').val();
    		var area = $('#s_county').val();
    		if(receiver.replace(/\s/g,'')==''){
    			MZ.alert({content:'收货人姓名不能为空'});
    			return;
    		}
    		if(mobile.replace(/\s/g,'')==''){
    			MZ.alert({content:'手机号码不能为空'});
    			return;
    		}
    		if(!/^[1][0-9]{10}$/.test(mobile)){
    			MZ.alert({content:'请输入正确的手机号码'});
    			return;
    		}
    		if(province=='请选择'){
    			MZ.alert({content:'请选择省份'});
    			return;
    		}
    		if(city=='请选择'){
    			MZ.alert({content:'请选择城市'});
    			return;
    		}
    		if(area=='请选择'){
    			MZ.alert({content:'请选择地区'});
    			return;
    		}
    		if(addressDetail.replace(/\s/g,'')==''){
    			MZ.alert({content:'请输入详细地址'});
    			return;
    		}
    		Zepto.ajax({
		        type:'post',
		        url: ApiPrefix+'/user/address/update',
		        data: {token:MZ.utils.getToken(),kgUid:kgUid,
		        	countryId: 0,
		        	userAddressId:ID,
		        	defaultFlag: ifDefault,
		        	receiver: receiver,
		        	mobile: mobile,
		        	provinceId: $('#s_province option').not(function(){ return !this.selected }).attr('data-id'),
		        	cityId: $('#s_city option').not(function(){ return !this.selected }).attr('data-id'),
		        	areaId: $('#s_county option').not(function(){ return !this.selected }).attr('data-id'),
		        	addressDetail: addressDetail.replace(/<*>*/g,'')
		        },
		        dataType:'json',
		        cache: false,
		        success: function(data){
		        	if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
		        	if(data.status==1){
		        		if(data.data){
		        			location.href = 'address.html?robid='+RobId;
		        		}else{
		        			MZ.alert({content:'保存失败，请重新尝试'})
		        		}
		        	}else{
		        		MZ.alert({content:data.errorMessage})
		        	}
		        }
		    })
    		e.preventDefault();
    	})
    	//切换省份
    	var $province = $('#s_province');
    	var $city = $('#s_city');
    	var $county = $('#s_county');
    	$province.on('change',function(e){
	        var provinceid = $('#s_province option').not(function(){ return !this.selected }).attr('data-id');
	        if(provinceid!=null){
				getAddress($('#s_city'),2,provinceid);
			}else{
				$city.html('<option>请选择</option>');
			}
			$county.html('<option>请选择</option>');
    	})
    	//切换城市
    	$city.on('change',function(e){
	        var cityid = $('#s_city option').not(function(){ return !this.selected }).attr('data-id');
	        if(cityid!=null){
				getAddress($county,3,cityid);
			}else{
				$county.html('<option>请选择</option>');
			}
    	})
    }
    function getAddress($list,type,id){
    	Zepto.ajax({
	        type:'post',
	        url: ApiPrefix+'/address/get',
	        data: {token:MZ.utils.getToken(),kgUid:kgUid,addressType:type,addressId:id},
	        dataType:'json',
	        cache: false,
	        async: false,
	        success: function(data){
	        	if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
	        	if(data.status==1){
	        		var data = data.data;
	        		var info = {};
	        		log(data);
	        		var options = '<option>请选择</option>';
	        		for(var i in data){
	        			var item = data[i];
	        			options+='<option data-id="'+item.id+'">'+item.addressName+'</option>'
	        		}
	        		$list.html(options);
	        	}else{
	        		MZ.alert({content:data.errorMessage})
	        	}
	        }
	    })
    }
    modules.exports = App;

});
