define(function(require, exports,modules) {
    var App={};
    var LoadMore = require('widgets/load-more');
    var win = window,
    doc = win.document;
    var targetKgUid;
    App.init = function(){
       targetKgUid = MZ.utils.getQueryString('id');
       addEvent();
       loadmore();
       getList();
    }
    function loadmore(){
        //初始化下拉加载更多
        $(document).on('scroll touchmove',function(){
            if(HasNoMore){
              $('.loading-more').hide();
              return;
            }
            if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
                if($('.loading-more').length==0){
                    if($('.control-item').index()==0){
                        getList();
                    }else{
                        getListDisabled();
                    }
                }
            }
        });
    }
    var Page = 1;
    var Loading = false;
    var HasNoMore = false;
    var lastId = 0;
    function getList(){
        if(Loading)return;
        Loading = true;
        if(HasNoMore)return;
        var pageSize=10
        Zepto.ajax({
            url: ApiPrefix+'/user/redEnvelope',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,"pageSize": pageSize,useType:1,lastId:lastId},
            cache: false,
            success: function(data){
                log(data)
                if(data.errorMessage=='token不合法'){
                    MZ.wechat.checkLogin(data);
                    return;
                }
                if(data.status==1){
                    var $list = $('#tabContent01 ul');
                    var str = '';
                    var list  = data.data;  
                    log(list)                 
                    for(var i in list) {
                        var item = list[i];
                        str += '<li><span class="fl"><i>￥</i>'+item.money+'</span>'+
                               ' <h3><span class="fr">满'+item.limitSubMoney+'元可用</span>'+item.name+'</h3>'+
                               ' <span class="type">'+item.typeName+'</span>'+
                               ' <p>'+item.limitTime+' 可用</p></li>';
                    }
                    $list.append(str);
                    if(Page==1 && list.length == 0){
                      var str = '<div class="cart-empty" style="margin-top:10%;">'+
                                 ' <i class="icon icon-img_empty"></i>'+
                                 ' <h3>暂无红包</h3>'+
                                '</div>';
                      $('.footer-icon').hide();
                      $list.append(str);
                      HasNoMore = true;
                    }else if(list.length<pageSize){
                     HasNoMore = true;
                    }
                    if($('#tabContent01 li').length!=0){
                      $('.footer-icon').show();
                    }else{
                      $('.footer-icon').hide();
                    }
                }else{
                  log(data.errorMessage)
                  //MZ.alert({content: data.errorMessage});
                }
                Loading = false;
            },
            error: function(){
              Loading = false;
            }
        })
    }
    var Page1 = 1;
    var Loading1 = false;
    var HasNoMore1 = false;
    var lastId1 = 0;
    function getListDisabled(){
        if(Loading1)return;
        Loading1 = true;
        if(HasNoMore1)return;
        var pageSize=10
        Zepto.ajax({
            url: ApiPrefix+'/user/redEnvelope',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,"pageSize": pageSize,useType:0,lastId:lastId1},
            cache: false,
            success: function(data){
                log(data)
                if(data.errorMessage=='token不合法'){
                    MZ.wechat.checkLogin(data);
                    return;
                }
                if(data.status==1){
                    var $list = $('#tabContent02 ul');
                    var str = '';
                    var list  = data.data;     
                    log(list)              
                    for(var i in list) {
                        var item = list[i];
                        str += '<li class="disabled"><span class="fl"><i>￥</i>'+item.money+'</span>'+
                               ' <h3><span class="fr">满'+item.limitSubMoney+'元可用</span>'+item.name+'</h3>'+
                               ' <span class="type">'+item.typeName+'</span>'+
                               ' <p>'+item.limitTime+' 可用</p></li>';
                    }
                    $list.append(str);
                    if(Page==1 && list.length == 0){
                      var str = '<div class="cart-empty" style="margin-top:10%;">'+
                                 ' <i class="icon icon-img_empty"></i>'+
                                 ' <h3>暂无红包</h3>'+
                                '</div>';
                      $('.footer-icon').add('.luckbag-tips').hide();
                      $list.append(str);
                    }else if(list.length<pageSize){
                     HasNoMore1 = true;
                    }
                    if($('#tabContent02 li').length!=0){
                      $('.footer-icon').show();
                    }else{
                      $('.footer-icon').hide();
                    }
                }else{
                  log(data.errorMessage)
                  //MZ.alert({content: data.errorMessage});
                }
                Loading = false;
            },
            error: function(){
              Loading = false;
            }
        })
    }
    function addEvent(){
      $('.control-item').on('click touchend',function(e){
        e.preventDefault();
        var $this = $(this);
        $this.addClass('active').siblings('.control-item').removeClass('active');
        if($this.index()==0){
            $('#tabContent01').show();
            $('#tabContent02').hide();
            if($('#tabContent01 li').length!=0){
              $('.footer-icon').show();
            }else{
              $('.footer-icon').hide();
            }
        }else{
            $('#tabContent01').hide();
            $('#tabContent02').show();
            getListDisabled();
            if($('#tabContent02 li').length!=0){
              $('.footer-icon').show();
            }else{
              $('.footer-icon').hide();
            }
        }
      })
    }
    
    modules.exports = App;
});
