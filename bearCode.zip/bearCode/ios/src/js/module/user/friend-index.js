define(function(require, exports,modules) {
    var App={};
    var win = window,
    doc = win.document;
    var targetKgUid;
    App.init = function(){
       targetKgUid = MZ.utils.getQueryString('id');
       getUserDetail();
       addEvent();
       loadmore();
       getListTab01(true);
       getListTab02(true);
       getListTab03(true);

    }
    function loadmore(){
        //初始化下拉加载更多
        $(document).on('scroll touchmove',function(){
            
            if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
                if($('.loading-more').length==0){
                  var idx = $('#friendIndexFixed a.active').index();
                  if(idx==0){
                    getListTab01();
                  }else if(idx==1){
                    getListTab02();
                  }else{
                    getListTab03();
                  }
                }
            }
        });
    }
    var Page1 = 1;
    var Loading1 = false;
    var HasNoMore1 = false;
    var lastId1 = 0;
    var servertime = new Date().getTime();
    function getListTab01(init){
        if(!init){
          if(Loading1)return;
          Loading1 = true;
          if(HasNoMore1)return;
        }
        var pageSize=10;
        $('.cart-empty').hide();
        Zepto.ajax({
            url: ApiPrefix+'/user/buyLog/list',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,"pageSize": pageSize,pageNumber:Page1,targetKgUid:targetKgUid},
            cache: false,
            async: false,
            success: function(data){
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                log(data)
                servertime = data.servertime;
                if(data.status==1){
                    var $list = $('#tabContent01 ul');
                    var str = '';
                    var list  = data.data.buyLogList;                   
                    for(var i in list) {
                        var item = list[i];
                        if(item.status==0){
                            str += '<li class="table-view-cell media" data-goodsid="'+item.goodsId+'">'+
                                '<div class="navigate-right">'+
                                '  <div class="pic-left"><a href="../detail.html?goodsId='+item.goodsId+'&id='+item.id+'"><img class="media-object pull-left" src="'+ImgBlank+'" alt="'+item.goodsName+'" data-echo="'+item.coverImgUrl+'"></a></div>'+
                                '  <div class="media-body">'+
                                '    <div class="media-right">'+
                                '      <a href="javascript:" data-goodsid="'+item.goodsId+'" data-id="'+item.id+'" class="btn btn-red-transparent btnAdd">跟买</a>'+
                                '    </div>'+
                                '    <h3><a href="../detail.html?goodsId='+item.goodsId+'&id='+item.id+'" class="link-black">'+item.goodsName+'</a></h3>'+
                                '    <p class="item">期号: '+item.id+'</p>'+
                                '    <div class="goods-control">'+
                                '      <div class="goods-status">'+
                                '        <div class="progress-bar">'+
                                '          <div class="inner" style="width:'+((item.needNumber-item.surplusNumber)/item.needNumber)*100+'%"></div>'+
                                '        </div>'+
                                '        <span class="fl">总需：'+item.needNumber+'</span>'+
                                '        <span class="fr">剩余<em>'+item.surplusNumber+'</em></span>'+
                                '      </div>'+
                                '    </div>'+
                                '    <div class="bottom-link">'+
                                '        <div class="fr"><a href="../buy/buy-detail.html?id='+item.id+'&targetKgUid='+targetKgUid+'&goodsName='+encodeURIComponent(item.goodsName)+'&joinNumber='+item.userJoinNumber+'">查看详情&gt;&gt;</a></div>'+
                                '        <div class="fl">本期参与：<span class="red">'+item.userJoinNumber+'</span>人次</div>'+
                                '    </div>'+
                                '  </div>'+
                                '</div>'+
                              '</li>';
                        }else if(item.status==3){
                            str += '<li class="table-view-cell media new" data-robid="'+item.id+'" data-userJoinNumber="'+item.userJoinNumber+'" data-neednumber="'+item.needNumber+'" servertime="'+servertime+'" starttime="'+(item.startTime+3*60*1000)+'">'+
                                   ' <div class="navigate-right">'+
                                   '   <div class="pic-left"><a href="../detail.html?goodsId='+item.goodsId+'&id='+item.id+'"><img class="media-object pull-left" src="'+ImgBlank+'" alt="'+item.goodsName+'" data-echo="'+item.coverImgUrl+'"></a></div>'+
                                   '   <div class="media-body">'+
                                   '     <h3><a href="../detail.html?goodsId='+item.goodsId+'&id='+item.id+'" class="link-black">'+item.goodsName+'</a></h3>'+
                                   '     <p class="item">期号: '+item.id+'</p>'+
                                   '     <p class="item">总需:'+item.needNumber+'</p>'+
                                   '     <p class="item">倒计时: <span class="red ticktime"></span></p>'+
                                   '     <div class="bottom-link">'+
                                   '         <div class="fr"><a href="../buy/buy-detail.html?id='+item.id+'&targetKgUid='+targetKgUid+'&goodsName='+encodeURIComponent(item.goodsName)+'&joinNumber='+item.userJoinNumber+'">查看详情&gt;&gt;</a></div>'+
                                   '         <div class="fl">本期参与：<span class="red">'+item.userJoinNumber+'</span>人次</div>'+
                                   '     </div>'+
                                   '   </div>'+
                                   ' </div>'+
                                   '</li>';
                        }else if(item.status==5){
                            str += '<li class="table-view-cell media">'+
                                   ' <div class="navigate-right">'+
                                   '   <div class="pic-left"><a href="../detail.html?goodsId='+item.goodsId+'&id='+item.id+'"><img class="media-object pull-left" src="'+ImgBlank+'" alt="'+item.goodsName+'" data-echo="'+item.coverImgUrl+'"></a></div>'+
                                   '   <div class="media-body">'+
                                   '     <h3><a href="../detail.html?goodsId='+item.goodsId+'&id='+item.id+'" class="link-black">'+item.goodsName+'</a></h3>'+
                                   '     <p class="item">期号: '+item.id+'</p>'+
                                   '     <p class="item">总需: '+item.needNumber+'</p>'+
                                   '     <div class="bottom-link">'+
                                   '         <div class="fr"><a href="../buy/buy-detail.html?id='+item.id+'&targetKgUid='+targetKgUid+'&goodsName='+encodeURIComponent(item.goodsName)+'&joinNumber='+item.userJoinNumber+'">查看详情&gt;&gt;</a></div>'+
                                   '         <div class="fl">本期参与：<span class="red">'+item.userJoinNumber+'</span>人次</div>'+
                                   '     </div>'+
                                   '     <div class="bottom-desc">'+
                                   '         <p>幸运儿: <a href="friend-index.html?id='+item.kgUid+'"><span class="blue">'+item.nickname+'</span></p>'+
                                   '         <p class="gray">( '+item.address+item.ip+' )</p>'+
                                   '         <p>用户ID: '+item.kgUid+' </p>'+
                                   '         <p>幸运号码: <span class="red">'+item.code+'</span> </p>'+
                                   '         <p>本期参与: <span class="red">'+item.winnerJoinNumber+'</span>人次 </p>'+
                                   '         <p>揭晓时间: '+MZ.utils.joinTime(item.openTime)+'</p>'+
                                   '     </div>'+
                                   '   </div>'+
                                   ' </div>'+
                                   '</li>';
                        }
                    }
                    lastId1 = list[0].id;
                    $list.append(str);
                    list = list == null?[]:list;
                    if(Page1==1 && list.length == 0){
                      var str = '<div class="cart-empty" style="margin-top:10%;">'+
                                 ' <i class="icon icon-img_empty"></i>'+
                                 ' <h3>暂无记录</h3>'+
                                '</div>';
                      $('.footer-icon').hide();
                      if($('.cart-empty').length!=0){
                        if(!init){
                          $('.cart-empty').show();
                        }
                      }else{
                        $('body').append(str);
                      }
                      HasNoMore1 = true;
                    }else if(list.length<pageSize){
                     HasNoMore1 = true;
                     //var nomorestr='<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;">没有更多记录</div>';
                     //$list.append(nomorestr);
                     $('.cart-empty').hide();
                    }
                    if(list.length>0){
                      $('.cart-empty').hide();
                    }
                    initTicker();
                    //图片延迟加载
                    MZ.utils.initEcho();
                    Page1++;
                }else{
                  log(data.errorMessage)
                    //MZ.alert({content: data.errorMessage});
                }
                Loading1 = false;
            },
            error: function(){
              Loading1 = false;
            }
        })
        
    }
    var Page2 = 1;
    var Loading2 = false;
    var HasNoMore2 = false;
    var lastId2 = 0;
    function getListTab02(init){
        if(!init){
          if(Loading2)return;
          Loading2 = true;
          if(HasNoMore2)return;
        }
        $('.cart-empty').hide();
        var pageSize=10;
        Zepto.ajax({
            url: ApiPrefix+'/user/win/log',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,"pageSize": pageSize,pageNumber:Page2,targetKgUid:targetKgUid},
            cache: false,
            async: false,
            success: function(data){
                log(data)
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    var $list = $('#tabContent02 ul');
                    var str = '';
                    var list  = data.data.winLogList;                   
                    for(var i in list) {
                        var item = list[i];
                        str+='<li class="table-view-cell media"><a href="../detail.html?goodsId='+item.goodsId+'&id='+item.id+'">'+
                             ' <div class="navigate-right">'+
                             '   <div class="pic-left"><img class="media-object pull-left" src="'+ImgBlank+'" data-echo="'+item.coverImgUrl+'"></div>'+
                             '   <div class="media-body">'+
                             '     <h3>'+item.goodsName+'</h3>'+
                             '     <p>期号: '+item.id+'</p>'+
                             '     <p>总需: '+item.needNumber+'</p>'+
                             '     <p>幸运号码: <span class="red">'+item.winCode+'</span></p>'+
                             '     <p>本期参与: <span class="red">'+item.joinNumber+'</span>人次</p>'+
                             '     <p>揭晓时间: '+MZ.utils.formatDate(item.openTime)+'</p>'+
                             '   </div>'+
                             ' </div></a>'+
                             '</li>';
                    }
                    $list.append(str);
                    list = list == null?[]:list;
                    if(Page2==1 && list.length==0){
                      var str = '<div class="cart-empty" style="margin-top:10%;">'+
                                 ' <i class="icon icon-img_empty"></i>'+
                                 ' <h3>暂无记录</h3>'+
                                '</div>';
                      $('.footer-icon').hide();
                      if($('.cart-empty').length!=0){
                        if(!init){
                          $('.cart-empty').show();
                        }
                      }else{
                        $('body').append(str);
                      }
                      HasNoMore2 = true;
                    }else if(list.length<pageSize){
                     HasNoMore2 = true;
                     //var nomorestr='<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;">没有更多记录</div>';
                     //$list.append(nomorestr);
                     $('.cart-empty').hide();
                    }
                    if(list.length>0){
                      $('.cart-empty').hide();
                    }
                    //图片延迟加载
                    MZ.utils.initEcho();
                    Page2++;
                }else{
                  log(data.errorMessage)
                    //MZ.alert({content: data.errorMessage});
                }
                Loading2 = false;
            },
            error: function(){
              Loading2 = false;
            }
        })
    }
    var Page3 = 1;
    var Loading3 = false;
    var HasNoMore3 = false;
    var lastId3 = 0;
    function getListTab03(init){
        if(!init){
          if(Loading3)return;
          Loading3 = true;
          if(HasNoMore3)return;
        }
        $('.cart-empty').hide();
        var pageSize=10;
        Zepto.ajax({
            url: ApiPrefix+'/find/mySharelist',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,"pageSize": pageSize,pageNumber:Page3,targetKgUid:targetKgUid},
            cache: false,
            async: false,
            success: function(data){
                log(data)
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    var $list = $('#tabContent03 ul');
                    var str = '';
                    var list  = data.data;                   
                    for(var i in list) {
                        var item = list[i];
                        var imgList = item.sharePicUrl.split(',');
                        var imgStr = '';
                        for(var i in imgList){
                          imgStr+='<dd><img src="'+ImgBlank+'" data-echo="'+imgList[i]+'"></dd>';
                        }
                        var userimg = item.avatarUrl;
                        if(userimg==''||userimg==null){
                            userimg = ImgUser;
                        }
                        str += '<li class="table-view-cell media" onclick="location.href=\'../discover/share-detail.html?id='+item.id+'\'">'+
                                '<div class="pic-left"><img src="'+userimg+'"></div>'+
                                '<div class="media-body">'+
                                 ' <h4><span class="fr">'+item.createTime+'</span>'+item.nickname+'</h4>'+
                                 ' <p>'+item.winWords+'</p>'+
                                 ' <dl class="pic-list">'+imgStr+
                                 ' </dl><div class="more">'+
                                 '   <div class="fr"><a href="../detail.html?id=0&goodsId='+item.goodsId+'" class="btn btn-red-transparent">我也要</a></div>'+
                                 '   <div class="fl">'+
                                 '     <p>'+item.goodsName+'</p>'+
                                 '     <p>期号：'+item.goodsRobId+'</p>'+
                                 '   </div>'+
                                 ' </div>'+
                                '</div>'+
                           ' </li>';
                    }
                    $list.append(str);
                    list = list == null?[]:list;
                    if(Page3==1 && list.length == 0){
                      var str = '<div class="cart-empty" style="margin-top:10%;">'+
                                 ' <i class="icon icon-img_empty"></i>'+
                                 ' <h3>暂无晒单记录</h3>'+
                                '</div>';
                      $('.footer-icon').hide();
                      if($('.cart-empty').length!=0){
                        if(!init){
                          $('.cart-empty').show();
                        }
                      }else{
                        $('body').append(str);
                      }
                      HasNoMore3 = true;
                    }else if(list.length<pageSize){
                     HasNoMore3 = true;
                     //var nomorestr='<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;">没有更多记录</div>';
                     //$list.append(nomorestr);                     
                    }
                    if(list.length>0){
                      $('.cart-empty').hide();
                    }
                    //图片延迟加载
                    MZ.utils.initEcho();
                    Page3++;
                }else{
                  log(data.errorMessage)
                    //MZ.alert({content: data.errorMessage});
                }
                if($('#tabContent01 li').length!=0){
                  $('.cart-empty').hide();
                }
                Loading3 = false;
            },
            error: function(){
              Loading3 = false;
            }
        })
    }
    var ticker;
    function initTicker(){
        var $list = $('.new');
        clearInterval(ticker);
        var systemTime,localTime=new Date().getTime();
        if($list.length!=0){
            systemTime = servertime;
            ticker = setInterval(function(){
                var stime = systemTime + (new Date().getTime()-localTime);
                for(var i=0;i<$list.length;i++){
                    (function(i){
                      var $item = $list.eq(i);
                      var t = $item.attr('starttime');
                      var time = MZ.utils.leaveTime(stime,t);
                      if(time==0){
                        $item.find('.ticktime').html('正在揭晓中');
                        if($item.attr('hasGetInfo')!='true'){
                            $item.attr('hasGetInfo','true');
                            var id = $item.attr('data-robid');
                            MZ.ajax.getWin({robid:id,callback:function(data){
                              var data = data.data;
                              $item.removeClass('new');
                              if(data.myWin){
                                MZ.showPrize({id:id,name:$item.find('h3').text(),avatarUrl:$item.find('img').attr('src'),href:'../user/address.html?robid='+id})
                              }
                              if(data.status==5){
                                var str = '<h3><a href="../detail.html?goodsId='+$item.attr('data-goodsid')+'&id='+data.id+'" class="link-black">'+$item.find('h3').html()+'</a></h3>'+
                                          '     <p class="item">期号: '+data.id+'</p>'+
                                          '     <p class="item">总需: '+$item.attr('data-needNumber')+'</p>'+
                                          '     <div class="bottom-link">'+
                                          '         <div class="fr"><a href="../buy/buy-detail.html?id='+data.id+'&targetKgUid='+targetKgUid+'&goodsName='+encodeURIComponent($item.find('h3').html())+'&joinNumber='+data.joinNumber+'">查看详情&gt;&gt;</a></div>'+
                                          '         <div class="fl">本期参与：<span class="red">'+$item.attr('data-userJoinNumber')+'</span>人次</div>'+
                                          '     </div>'+
                                          '     <div class="bottom-desc">'+
                                          '         <p>幸运儿: <a href="friend-index.html?id='+data.kgUid+'"><span class="blue">'+data.nickname+'</span></p>'+
                                          '         <p class="gray">( '+data.address+data.ip+' )</p>'+
                                          '         <p>用户ID: '+data.kgUid+' </p>'+
                                          '         <p>幸运号码: <span class="red">'+data.joinCode+'</span> </p>'+
                                          '         <p>本期参与: <span class="red">'+data.joinNumber+'</span>人次 </p>'+
                                          '         <p>揭晓时间: '+MZ.utils.joinTime(data.openTime)+'</p>'+
                                          '     </div>';
                                $item.find('.media-body').html(str);
                              }
                            }})
                        }
                      }else{
                        $item.find('.ticktime').html(leaveTime(stime,t));
                      }
                    })(i)
                }
            },100)
        }
    }
    function getUserDetail(){
      Zepto.ajax({
        type:'post',
        url: ApiPrefix+'/user/detail',
        data: {token:MZ.utils.getToken(),targetKgUid:targetKgUid},
        dataType:'json',
        cache: false,
        success: function(data){
          if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
          if(data.status==1){
            var info = data.data;
            $('#username').html(info.nickname);
            $('#userid').html(info.kgUid);
            var userimg = info.avatarUrl;
            if(userimg==''||userimg==null){
                userimg = ImgUser;
            }
            $('#userpic').html('<img src="'+userimg+'">');
          }else{
            MZ.alert({content:data.errorMessage})
          }
        },
        error: function(err){
        }
      })
    }
    function addEvent() {
    	var $body = $('body'),
            $friendIndexFixed = $('#friendIndexFixed'),
            $friendIndexFixedHeight = $('#friendIndexFixedHeight');
        MZ.browser.sticky && $friendIndexFixed.addClass('sticky');
        MZ.browser.sticky || (document.addEventListener("touchmove", function () {
            scroll();
        }), document.addEventListener("scroll", function () {
            scroll();
        }))      
        function scroll() {
            var top = $body.scrollTop();
            if(top>=365){
                $friendIndexFixed.addClass('fixed-tab');
                $friendIndexFixedHeight.height(96);
            }else{
                $friendIndexFixed.removeClass('fixed-tab');
                $friendIndexFixedHeight.height(0);
            }
        }
        //跟买
        $(document).delegate('.btnAdd','touchend',function(e){
          var $this = $(this);
          var toast = new MZ.toast({content:'加入清单中...'});
           var number = 1;
            if($this.parents('li').find('.fr em').html()>500){
                number = 5;
            }
          MZ.cart.addCart({
              goodsList:[{goodsId:$this.attr('data-goodsid'),number:number}],
              callback:function(){
                  toast.setContent('添加成功，跳转页面中');
                  location.href = '../shopping/list.html';
              }
          });
          e.preventDefault();
        })
        $('.control-item').on('click',function(e){
          var $this = $(this);
          $this.addClass('active').siblings('a').removeClass('active');
          $('.cart-empty').hide();
          if($this.index()==0){
            if($('#tabContent01 li').length==0){
              $('.cart-empty').show();
            }
            $('#tabContent02').add('#tabContent03').hide();
            $('#tabContent01').show();
          }else if($this.index()==1){
            if($('#tabContent02 li').length==0){
              $('.cart-empty').show();
            }
            $('#tabContent01').add('#tabContent03').hide();
            $('#tabContent02').show();
          }else {
            if($('#tabContent03 li').length==0){
              $('.cart-empty').show();
            }
            $('#tabContent01').add('#tabContent02').hide();
            $('#tabContent03').show();
          }
          //图片延迟加载
          MZ.utils.initEcho();
          e.preventDefault();
        })
    }
    function leaveTime(startTime,endTime){
      if(startTime>=endTime){
            return 0;
        }else{
            var t =  endTime - startTime;
            var h = 60*60*1000,
                m = 60*1000,
                s = 1000;
            var H = parseInt(t/h),
                M = parseInt((t-H*h)/m),
                S = parseInt((t-H*h-M*m)/s),
                HS = parseInt((t-H*h-M*m-S*s)/100);
            return intNumber(M)+":"+intNumber(S)+":"+HS;
        }
    }
    modules.exports = App;

});
 