define(function(require, exports,modules) {
    var App={};
    App.init = function(){
    	addEvent();
    	ajaxGetUserDetail();
    }
    function addEvent(){
    	
    }
   	function ajaxGetUserDetail(){
	    Zepto.ajax({
	        url: ApiPrefix+'/user/detail',
	        type: 'post',
	        data: {token:MZ.utils.getToken(),targetKgUid:kgUid},
	        cache: false,
	        success: function(data){
	        	log(data)
	        	if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
	            if(data.status==1){
	            	var user = data.data;
	                $("#nickname").text(user.nickname);
	                $("#userId").text(user.kgUid);
	                var userimg = user.avatarUrl;
                    if(userimg==''||userimg==null){
                        userimg = ImgUser;
                    }
	                $("#headImg").attr("src",userimg);
	                if(user.mobile!=null){
		                $('#btnLink').attr('href','edit-phone.html?phone='+user.mobile);
		                $('#btnLink').find('.gray').html(user.mobile);
		                $('#btnTry').attr('href','startup.html?gameId='+data.gameId);
	                }else{
	                	$('#btnLink').attr('href','band-phone.html');
		                $('#btnLink').find('.gray').html('点击绑定');
	                }
	            }else{
	                MZ.alert({content: data.errorMessage});
	            }
	        },
	        error: function(){
	          Loading = false;
	        }
	    })
    }
    modules.exports = App;

});
