define(function(require, exports,modules) {
    var App = {};
    var win = window,
    doc = win.document;
    var LoadMore = require('widgets/load-more');
    function layout(){
        
    }
    var GOODSID;
    App.init = function(){
        addEvent();
        GOODSID = MZ.utils.getQueryString('goodsId');
        if(GOODSID==null || GOODSID=='null'){
            window.history.back();
            return;
        }
        layout();
        loadmore();
        getList();
    }
    function loadmore(){
        //初始化下拉加载更多
        $(document).on('scroll touchmove',function(){
            if(HasNoMore){
              $('.loading-more').hide();
              return;
            }
            if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
                if($('.loading-more').length==0){
                    getList();
                }
            }
        });
    }
    var Page = 1;
    var Loading = false;
    var HasNoMore = false;
    var lastId = 0;
    function getList(){
        if(Loading)return;
        Loading = true;
        if(HasNoMore)return;
        var pageSize=10
        Zepto.ajax({
            url: ApiPrefix+'/goods/past',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,pageSize: pageSize,lastId:lastId,goodsId:GOODSID},
            cache: false,
            dataType: 'json',
            success: function(data){
                log(data)
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    var $list = $('.list-wangqi');
                    var str = '';
                    var list  = data.data.goodsList;
                    for(var i in list) {
                        var item = list[i];
                        var userimg = item.avatarUrl;
                        if(userimg==''||userimg==null){
                            userimg = ImgUser;
                        }
                        str += '<li data-url="../user/friend-index.html?id='+item.kgUid+'">'+
                                '<div class="title-wangqi">'+
                                '  期号: '+item.id+'（揭晓时间: '+MZ.utils.formatDate(item.openTime)+'）'+
                                '</div>'+
                                '<div class="desc">'+
                                '<div class="pic"><img src="'+userimg+'"></div>'+
                                '  <p>幸运儿: <a href="../user/friend-index.html?id='+item.kgUid+'">'+item.nickname+'</a></p>'+
                                '  <p class="gray">( '+item.address+' IP:'+item.ip+' )</p>'+
                                '  <p>用户ID: '+item.kgUid+'</p>'+
                                '  <p>幸运号码: '+item.winCode+'</p>'+
                                '  <p>本期参与: <span class="red">'+item.joinNumber+'</span>人次</p>'+
                                '</div>'+
                              '</li>';
                    }
                    $list.append(str);
                    //延迟加载
                    MZ.utils.initEcho();
                    if(Page==1 && list.length ==0){
                        var str = '<div class="cart-empty" style="margin-top:30%;">'+
                                     ' <i class="icon icon-img_empty"></i>'+
                                     ' <h3>该商品还没有揭晓信息</h3>'+
                                     ' <a href="javascript:history.back()" class="btn btn-red-transparent">返回</a>'+
                                    '</div>';
                        $('.footer-icon').hide();
                       $(str).insertAfter($list);
                    }else if(list.length<pageSize){
                     HasNoMore = true;
                    }
                    Page++;
                }else{
                    MZ.alert({content: data.errorMessage});
                }
                Loading = false;
            },
            error: function(){
              Loading = false;
            }
        })
        
    }
    function addEvent(){
        $('.list-wangqi').delegate('li','click',function(e){
            location.href = $(this).attr('data-url');
            e.preventDefault();
        })
    }
   
    modules.exports = App;
});
