define(function(require, exports,modules) {
    var App = {};
    var win = window,
        doc = win.document;
    var LoadMore = require('widgets/load-more');
    App.init = function(){

        addEvent();
        loadmore();
        getList();
        //设置底部导航选中样式
        MZ.setNavStatus(3);
    }
    var $totalCoast = $('#totalCoast');
    var $total = $('#total');
    function addEvent(){
       //删除清单
       $(document).delegate('.icon-remove-wechat','touchend',function(e){
       	var $this = $(this),
       		dataid = $this.attr('data-id');
          MZ.confirm({
            content:'您确定要删除该商品吗？',
            text2: '删除',
            callback:function(){
              deleteGoods({$btn:$this,goodsId:dataid});              
            }
          })
          e.preventDefault();
       })
       //增加数量
       $(document).delegate('.btnPlus','touchend',function(e){
          var $this = $(this),
              $parent = $this.parents('li'),
              $input = $parent.find('input'),
              $status = $parent.find('.status');
          var surplusNumber = parseInt($parent.find('.surplusNumber').html());
          var number = $input.val();
          if(number>=surplusNumber){
            $status.html('<span class="red">剩余人次不足，只能购买'+surplusNumber+'份</span>');
          }else{
            $input.val(++number);
            update({goodsId:$parent.attr('data-goodsid'),total:number});
          }
          e.preventDefault();
       })
       //减少数量
       $(document).delegate('.btnMinus','touchend',function(e){
          var $this = $(this),
              $parent = $this.parents('li'),
              $input = $parent.find('input'),
              $status = $parent.find('.status');
          var number = $input.val();
          var surplusNumber = parseInt($parent.find('.surplusNumber').html());
          if(number>1){
            $input.val(--number);
            $totalCoast.html($totalCoast.html()-1);
            update({goodsId:$parent.attr('data-goodsid'),total:number});
            if(number<=surplusNumber){
              $status.html('商品夺宝正火热进行');
            }else{
              $status.html('<span class="red">剩余人次不足，只能购买'+surplusNumber+'份</span>');
            }
          }
          e.preventDefault();
       })
       // onkeyup="this.value=this.value.replace(/\D/g,'')"  onafterpaste="this.value=this.value.replace(/\D/g,'')" 
       $(document).delegate('.number','blur',function(){
          var $this = $(this),
              $parent = $this.parents('li'),
              $status = $parent.find('.status');
          var value = $this.val();
          var surplusNumber = parseInt($parent.find('.surplusNumber').html());
          if(!/^[1-9]\d*$/g.test(value)){
            $this.val(1);
            update({goodsId:$parent.attr('data-goodsid'),total:1});
            $status.html('<span class="red">请输入数字</span>');
            return;
          }
          if(value>surplusNumber){
            $this.val(surplusNumber);
            update({goodsId:$parent.attr('data-goodsid'),total:surplusNumber});
            $status.html('<span class="red">剩余人次不足，只能购买'+surplusNumber+'份</span>');
            return;
          }
          if(value<1){
            $this.val(1);
            update({goodsId:$parent.attr('data-goodsid'),total:1});
            return;
          }
          update({goodsId:$parent.attr('data-goodsid'),total:value});
          $status.html('商品夺宝正火热进行');
       })
    }
    function deleteGoods(params){
      var goodsId = params.goodsId;
      var $btn = params.$btn;
      var toast = new MZ.toast({content:'删除中...'});
      Zepto.ajax({
          url: ApiPrefix+'/cart/delete',
          type: 'post',
          data: {token:MZ.utils.getToken(),kgUid:kgUid,goodsId:goodsId},
          cache: false,
          success: function(data){
            if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
              if(data.status==1){
                MZ.cart.update(data.data.totalNumber);
                $('#totalCoast').html(data.data.totalCost);
                $('#total').html(data.data.totalNumber);
                $btn.parents('li').next('li').remove();
                $btn.parents('li').remove();
                if($('.shopping-list li').length==0){
                  var str = '<div class="cart-empty" style="margin-top:-10%;">'+
                      '<i class="icon icon-cartempty"></i>'+
                      '<h3>你的清单空空如也</h3>'+
                      '<a href="../index.html" class="btn btn-red-transparent">立即夺宝</a>'+
                    '</div>';
                getLike();
                $('.footer-fixed-buy').hide();
                    $('body').append(str);
                }
                toast.setContent('删除成功');
                setTimeout(function(){
                  toast.hide();
                },1000)
                MZ.utils.initEcho();
              }else{
                  MZ.alert({content: data.errorMessage});
              }
          },
          error: function(){
          }
      })
    }
    
    function getLike(){
      $('.fixed-bottom').show();
      var $li = $('.pro-list li');
       Zepto.ajax({
            url: ApiPrefix + '/goods/list',
            type: 'post',
            cache: false,
            data: {"kgUid": kgUid,"token": MZ.utils.getToken(),"status": 0,"lastId": 0,"pageNumber": 1,"pageSize": 10,"type": 0},
            dataType: 'json',
            success:function(data){
              if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                log(data)
                if(data.status==1){
                  var $list = $('#listLike');
                  var list = data.data.goodsList;
                  var str = '';
                  for(var i in list){
                    var item = list[i];
                    str += '<div class="swiper-slide">'+
                           ' <a href="../detail.html?goodsId='+item.goodsId+'&id=0">'+
                           '   <div class="pic"><img src="'+item.coverImgUrl+'"></div>'+
                           '   <p>'+item.goodsName+'</p>'+
                           '   <div class="goods-control">'+
                           '     <div class="goods-status">'+
                           '       <div class="progress-bar">'+
                           '         <div class="inner" style="width:'+((item.needNumber-item.surplusNumber)/item.needNumber*100)+'%;"></div>'+
                           '       </div>'+
                           '     </div>'+
                           '   </div>'+
                           ' </a>'+
                          '</div>'
                  }
                  $list.html(str);
                  var swiper = new Swiper('.swiper-container', {
                        slidesPerView: 3,
                        spaceBetween: 0,
                        width: 700,
                        spaceBetween: 30,
                        freeMode: true
                    });
                }else{
                    MZ.alert({content: data.errorMessage});
                }
            },
            error: function(){
            }
        })
    }
    function update(goods){
      Zepto.ajax({
            url: ApiPrefix+'/cart/edit',
            type: 'post',
            //dataType: 'json',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,goodsId:goods.goodsId,total:goods.total},
            cache: false,
            success: function(data){
              if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                  MZ.cart.update(data.data.totalNumber);
                  $('#totalCoast').html(data.data.totalCost);
                  $('#total').html(data.data.totalNumber);
                }else{
                    MZ.alert({content: data.errorMessage});
                }
            },
            error: function(){
            }
        })
    }
    function loadmore(){
    }
    function getList(){
        Zepto.ajax({
            url: ApiPrefix+'/cart/detail',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid},
            cache: false,
            success: function(data){
              if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
              log(data)
                if(data.status==1){
                    var data = data.data;
                    var $list = $('.shopping-list');
                    var str = '';
                    var list  = data.goodsList;
                    MZ.cart.update(data.total);
                    MZ.cart.init();
                    if(list.length == 0){
                      var str = '<div class="cart-empty" style="margin-top:-10%;">'+
                          '<i class="icon icon-cartempty"></i>'+
                          '<h3>你的清单空空如也</h3>'+
                          '<a href="../index.html" class="btn btn-red-transparent">马上去夺宝</a>'+
                        '</div>';
                      getLike();
                      $('.footer-fixed-buy').hide();
                      $('body').append(str);
                     return; 
                    }
                    $('#totalCost').html(data.totalCost)
                    $('#total').html(data.total)
                    $('.cart-empty').hide();
                    $('.footer-fixed-buy').show();
                    var totalCoast=0;
                    for(var i in list) {
                        var item = list[i];
                        totalCoast+=item.number;
                        var status = '';
                       if(item.status == 3){
                          //已进行计算则显示新一期
                          status = '商品已过期，自动更新为新一期';
                       }else{
                          status = '商品夺宝正火热进行';
                       }
                       var surplusNumber=0;
                       if(item.surplusStatus==1){
                        item.number = item.surplusNumber;
                        status = '剩余人次不足，只能购买'+item.surplusNumber+'份';
                       }
                        str += '<li class="table-view-cell media">'+
                      '    <div class="navigate-right">'+
                      '      <div class="fr"><a href="javascript:;"><i class="icon icon-remove-wechat" data-id="'+item.goodsId+'"></i></a></div>'+
                      '      <div class="fl">'+item.goodsName+'</div>'+
                      '    </div>'+
                      '  </li>'+
                      '  <li class="table-view-cell media" data-goodsid="'+item.goodsId+'">'+
                      '    <div class="navigate-right">'+
                      '      <div class="pic-left"><a href="../detail.html?goodsId='+item.goodsId+'&id='+item.lastId+'"><img class="media-object pull-left" src="'+ImgBlank+'" data-echo="'+item.coverImgUrl+'"></a></div>'+
                      '      <div class="media-body">'+
                      '        <p class="item">总需: '+item.needNumber+'人次，剩余: <span class="red surplusNumber">'+item.surplusNumber+'</span>人次</p>'+
                      '        <div class="segmented-control for-input-number">'+
                      '          <a class="control-item btnMinus">-</a>'+
                      '          <div class="control-item"><input type="tel" class="number" maxlength="8" value="'+item.number+'"></div>'+
                      '           <a class="control-item btnPlus">+</a>'+
                      '        </div>'+
                      '        <p class="status">'+status+'</p>'+
                      '      </div>'+
                      '    </div>'+
                      '  </li>';
                    }
                    $('#totalCoast').html(totalCoast);
                    $list.append(str);
                    //延迟加载
                    MZ.utils.initEcho();
                }else{
                    MZ.alert({content: data.errorMessage});
                }
              Loading = false;
            },
            error: function(){
              Loading = false;
            }
        })
        
    }
    modules.exports = App;
});
