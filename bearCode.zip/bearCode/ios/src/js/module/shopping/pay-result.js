define(function(require, exports,modules) {
    var App = {};
    var totalCost = 0,money=0;
    var orderNo,itemId,token,kgUid;
    App.init = function(){
        orderNo = MZ.utils.getQueryString('order_no');
        itemId = MZ.utils.getQueryString('itemId');
        localStorage.removeItem('cartNum');
        token = sessionStorage.getItem('token');
        kgUid = sessionStorage.getItem('kgUid');
        if(orderNo == null || orderNo == 'null'){
            var payResult = JSON.parse(localStorage.getItem('payResult'));
            log(payResult);
            if(itemId == payResult.data.orderNo) {
                payResult.payType = 0;
                render(payResult);
            }else{
                MZ.alert({content:'查询内容不正确',callback:function(){
                    location.href = 'list.html';
                }})
            }
        }else{
            getList();
        }
        addEvent();
    }
    function addEvent(){
        $(document).delegate('.btnShowCode','touchend',function(e){
            var $this = $(this);
            var goodsOrderId = $this.attr('data-id');
            Zepto.ajax({
                url: ApiPrefix+'/user/buyInfo/codes',
                type: 'post',
                data: {token:token,kgUid:kgUid,Id:goodsOrderId},
                cache: false,
                success: function(data){
                    if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                    var codeList = data.data;
                    if(data.status==1){
                        var code  = '';
                        for(var i in codeList){
                            code += codeList[i]+" ";
                        }
                        MZ.alert({title:'<strong class="weui_dialog_title"><span style="color:#333;font-weight:bold;font-size:32px;margin-top:10px;display:block;">幸运号码</span><br>本期参与了<span class="red">'+codeList.length+'</span>人次</strong>',content: '<div style="max-height:700px;overflow:auto;">'+code+'</div>'});
                    }else{
                        MZ.alert({content: data.errorMessage});
                    }
               
                },
                error: function(){
              
                }
            })
            
            e.preventDefault();
        })
    }
    function checkPayResult(){
        Zepto.ajax({
            url: ApiPrefix+'/pay/result/get',
            type: 'post',
            data: {token:token,kgUid:kgUid,payOrderNo:orderNo},
            cache: false,
            success: function(data){
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
              log(data)
                if(data.status==1){
                    render(data);
                }else{
                    MZ.alert({content: data.errorMessage});
                }
           
            },
            error: function(){
          
            }
        })
    }
    var GoodsList;
    function getList(){
    	
        Zepto.ajax({
            url: ApiPrefix+'/cart/pay',
            type: 'post',
            data: {token:token,kgUid:kgUid,payOrderNo:orderNo},
            cache: false,
            success: function(data){
              if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
              log(data)
                if(data.status==1){
                    render(data);
                }else{
                    MZ.alert({content: data.errorMessage});
                }
           
            },
            error: function(){
          
            }
        })
        
    }
    var successCode = [];
    function render(data){
        log(data);
        var result = data.data;
        $('#payStatus').hide();
        //if(data.payType==0){
            if(result.successCost==0){
                $('#paySuccess').hide();
                $('#payFail').show();
            }else{
                $('#paySuccess').show();
                $('#payFail').hide();
            }
        //}
        if(result.failList.length!=0){
            $('#fail').show();
            $('#totalFail').html(result.failList.length);
            $('#totalCoastFail').html(result.failCost);
            var $listFail = $('#fail .join-list');
            var str = '';
            for(var i in result.failList){
                var item = result.failList[i];
                str+='<li class="table-view-cell media">'+
                     '  <div class="navigate-right">'+
                     '     <div class="media-body">'+
                     '       <div class="join-title"><div class="fr"><span class="red">'+item.joinNumber+'</span>人次</div><span class="fl">'+item.goodsName+'</span></div>'+
                     '       <p>商品期号: '+item.id+'</p>'+
                     '       <p>失败原因：<span class="red">'+item.msg+'</span></p>'+
                     '     </div>'+
                     '   </div>'+
                     ' </li>'
            }
            $listFail.html(str);
        }
        successCode = result.successList;
        if(result.successList.length!=0){
            $('#success').show();
            $('#totalSuccess').html(result.successList.length);
            $('#totalCoastSuccess').html(result.successCost);
            var $listSuccess = $('#success .join-list');
            var str = '';
            for(var i in result.successList){
                var item = result.successList[i];
                var codeList = item.codes;
                var code = '';
                
                var showBtn = '',count=7;
                if(codeList.length<10){
                    showBtn = 'display:none;';
                    count = 10;
                }
                for(var i in codeList){
                    if(i<count){
                        code += codeList[i]+" ";
                    }
                }
                str+='<li class="table-view-cell media">'+
                     '   <div class="navigate-right">'+
                     '     <div class="media-body">'+
                     '       <div class="join-title"><div class="fr"><span class="red">'+item.joinNumber+'</span>人次</div><span class="fl">'+item.goodsName+'</span></div>'+
                     '       <p>商品期号: '+item.id+'</p>'+
                     '       <p>酷买号码: '+code+'</p>'+
                     '     </div>'+
                     '   </div>'+
                     ' </li>'
            }
            $listSuccess.html(str);
        }
    }
    modules.exports = App;
});
