define(function(require, exports,modules) {
    var App = {};
    var win = window,
    doc = win.document;
    var LoadMore = require('widgets/load-more');
    function layout(){
        
    }
    App.init = function(){
        addEvent();
        layout();
        loadmore();
        getList();
    }
    function loadmore(){
        //初始化下拉加载更多
        $(document).on('scroll touchmove',function(){
              if(HasNoMore){
                $('.loading-more').hide();
                return;
              }
              if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
                  if($('.loading-more').length==0){
                      getList();
                  }
              }
          });
    }
    var Loading = false;
    var HasNoMore = false;
    var pageSize=10;
    var Page = 1;
    var servertime;
    var lastId = 0;
    function getList(){
        if(Loading)return;
        Loading = true;
        Zepto.ajax({
            url: ApiPrefix+'/user/buyLog/list',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,targetKgUid:0,type:5,"lastId": lastId,"pageSize": pageSize},
            cache: false,
            success: function(data){
              servertime = data.servertime ;
                if(data.status==1){
                  var $list = $('.for-good-list');
                  var str = '';
                  var list  = data.data.buyLogList;
                  /*if(list.length == 0){
                    HasNoMore = true;
                    str = '<div class="cart-empty">'+
                               ' <i class="icon icon-cartempty"></i>'+
                               ' <h3>暂无酷买记录</h3>'+
                               ' <a href="../index.html" class="btn btn-red-transparent">马上去酷买</a>'+
                              '</div>';
                    $('body').append(str);
                   return; 
                  }*/
                  if(list.length <pageSize){
                    HasNoMore = true;
                  }
                  for(var i in list) {
                      var item = list[i];
                      str += '<li class="table-view-cell media">'+
                             ' <div class="navigate-right">'+
                             '   <div class="pic-left"><a href="../detail.html?goodsId='+item.goodsId+'&id=0"><img class="media-object pull-left" src="'+ImgBlank+'" alt="'+item.goodsName+'" data-echo="'+item.coverImgUrl+'"></a></div>'+
                             '   <div class="media-body">'+
                             '     <h3>'+item.goodsName+'</h3>'+
                             '     <p class="item">期号: '+item.id+'</p>'+
                             '     <p class="item">总需: '+item.needNumber+'</p>'+
                             '     <div class="bottom-link">'+
                                   '        <div class="fr"><a href="../buy/buy-detail.html?id='+item.id+'&goodsName='+encodeURIComponent(item.goodsName)+'&joinNumber='+item.userJoinNumber+'">查看详情&gt;&gt;</a></div>'+
                             '         <div class="fl">本期参与：<span class="red">'+item.userJoinNumber+'</span>人次</div>'+
                             '     </div>'+
                             '     <div class="bottom-desc">'+
                             '         <p>获奖者: <span class="blue">'+item.nickname+'</span></p>'+
                             '         <p class="gray">( '+item.address+item.ip+' )</p>'+
                             '         <p>用户ID: '+item.kgUid+' </p>'+
                             '         <p>幸运号码: '+item.winnerJoinNumber+' </p>'+
                             '         <p>本期参与: <span class="red">'+item.userJoinNumber+'</span>人次 </p>'+
                             '         <p>揭晓时间: '+MZ.utils.joinTime(item.openTime)+'</p>'+
                             '     </div>'+
                             '   </div>'+
                             ' </div>'+
                             '</li>';
                  }
                  lastId = list[0].id;
                  $list.append(str);
                  if(Page==1 && list.length==0){
                    var str = '<div class="cart-empty" style="margin-top:20%;">'+
                       ' <i class="icon icon-img_empty"></i>'+
                       ' <h3>暂无酷买记录</h3>'+
                       ' <a href="../index.html" class="btn btn-red-transparent">马上去酷买</a>'+
                      '</div>';
                    $('.footer-icon').hide();
                    $('body').append(str);
                  }else if(list.length<pageSize){
                   HasNoMore = true;
                   var nomorestr='<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;">没有更多记录</div>';
                   $list.append(nomorestr);
                  }
                  //图片延迟加载
                  MZ.utils.initEcho();
                  Page++;
              }else{
                log(data.errorMessage)
                  //MZ.alert({content: data.errorMessage});
              }
              Loading = false;
            },
            error: function(){
              Loading = false;
            }
        })
    }   
    function addEvent(){
       var $body = $('body'),
            $friendIndexFixed = $('#myRecord'),
            $friendIndexFixedHeight = $('#myRecordFixedHeight');
        MZ.browser.sticky && $friendIndexFixed.addClass('sticky');
        MZ.browser.sticky || (document.addEventListener("touchmove", function () {
            scroll();
        }), document.addEventListener("scroll", function () {
            scroll();
        }))      
        function scroll() {
            var top = $body.scrollTop();
            if(top>=365){
                $friendIndexFixed.addClass('fixed-tab');
                $friendIndexFixedHeight.height(96);
            }else{
                $friendIndexFixed.removeClass('fixed-tab');
                $friendIndexFixedHeight.height(0);
            }
        }
         //追加
        $(document).delegate('.btnAdd','touchend',function(e){
          var $this = $(this);
          var toast = new MZ.toast({content:'加入清单中...'});
          MZ.cart.addCart({
              goodsList:[{goodsId:$this.attr('data-goodsid'),number:1}],
              callback:function(){
                  toast.setContent('添加成功，跳转页面中');
                  location.href = '../shopping/list.html';
              }
          });
          e.preventDefault();
        })
    }
    
    modules.exports = App;
});
