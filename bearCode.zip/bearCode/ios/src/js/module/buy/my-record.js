define(function(require, exports,modules) {
    var App = {};
    var win = window,
    doc = win.document;
    var LoadMore = require('widgets/load-more');
    function layout(){
        
    }
    App.init = function(){
        addEvent();
        layout();
        loadmore();
        getListTab01();
    }
    function loadmore(){
        //初始化下拉加载更多
    	  $(document).on('scroll touchmove',function(){
              if(HasNoMore){
                $('.loading-more').hide();
                return;
              }
              if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
                  if($('.loading-more').length==0){
                    var idx = $('#myRecordFixed a.active').index();
                    log(idx)
                    if(idx==0){
                      getListTab01();
                    }else if(idx==1){
                      getListTab02();
                    }else{
                      getListTab03();
                    }
                  }
              }
          });
    }
    var Loading = false;
    var HasNoMore = false;
    var pageSize=10;
    var Page = 1;
    var lastId = 0;
	  var servertime;
    function getListTab01(){
        var $list = $('#tabContent01 .for-good-list');
        $('.cart-empty').hide();
        if($list.find('li').length!=0){
          $('.cart-empty').hide();
        }
        if(Loading)return;
    		Loading = true;
    		log(lastId)
        Zepto.ajax({
            url: ApiPrefix+'/user/buyLog/list',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,targetKgUid:0,type:0,"pageSize": pageSize,pageNumber:Page},
            cache: false,
            success: function(data){
              if(data.errorMessage=='token不合法'){
                  MZ.wechat.checkLogin(data);
                  return;
                }
            	servertime = data.servertime ;
                if(data.status==1){
			        var str = '';
			        var list  = data.data.buyLogList;
			        /*if(list.length == 0){
			          HasNoMore = true;
			          str = '<div class="cart-empty">'+
			                     ' <i class="icon icon-cartempty"></i>'+
			                     ' <h3>暂无夺宝记录</h3>'+
			                     ' <a href="../index.html" class="btn btn-red-transparent">马上去夺宝</a>'+
			                    '</div>';
			          $('body').append(str);
			         return; 
			        }*/
			        if(list.length <pageSize){
                    	HasNoMore = true;
                    }
			        for(var i in list) {
			            var item = list[i];
			            if(item.status==0){
			                str += '<li class="table-view-cell media">'+
			                    '<div class="navigate-right">'+
			                    '  <div class="pic-left"><a href="../detail.html?goodsId='+item.goodsId+'&id='+item.id+'"><img class="media-object pull-left" src="'+ImgBlank+'" alt="'+item.goodsName+'" data-echo="'+item.coverImgUrl+'"></a></div>'+
			                    '  <div class="media-body">'+
			                    '    <div class="media-right">'+
			                    '      <a href="javascript:" data-goodsid="'+item.goodsId+'" class="btn btn-red-transparent btnAdd">追加</a>'+
			                    '    </div>'+
			                    '    <h3>'+item.goodsName+'</h3>'+
			                    '    <p class="item">期号: '+item.id+'</p>'+
			                    '    <div class="goods-control">'+
			                    '      <div class="goods-status">'+
			                    '        <div class="progress-bar">'+
			                    '          <div class="inner" style="width:'+((item.needNumber-item.surplusNumber)/item.needNumber)*100+'%"></div>'+
			                    '        </div>'+
			                    '        <span class="fl">总需：'+item.needNumber+'</span>'+
			                    '        <span class="fr">剩余<em>'+item.surplusNumber+'</em></span>'+
			                    '      </div>'+
			                    '    </div>'+
			                    '    <div class="bottom-link">'+
                                '        <div class="fr"><a href="../buy/buy-detail.html?id='+item.id+'&goodsName='+encodeURIComponent(item.goodsName)+'&joinNumber='+item.userJoinNumber+'">查看详情&gt;&gt;</a></div>'+
			                    '        <div class="fl">本期参与：<span class="red">'+item.userJoinNumber+'</span>人次</div>'+
			                    '    </div>'+
			                    '  </div>'+
			                    '</div>'+
			                  '</li>';
			            }else if(item.status==3){
			                str += '<li class="table-view-cell media new" data-robid="'+item.id+'" data-userJoinNumber="'+item.userJoinNumber+'" data-needNumber="'+item.needNumber+'" servertime="'+servertime+'" starttime="'+(item.startTime+3*60*1000)+'">'+
			                       ' <div class="navigate-right">'+
			                       '   <div class="pic-left"><a href="../detail.html?goodsId='+item.goodsId+'&id='+item.id+'"><img class="media-object pull-left" src="'+ImgBlank+'" alt="'+item.goodsName+'" data-echo="'+item.coverImgUrl+'"></a></div>'+
			                       '   <div class="media-body">'+
			                       '     <h3>'+item.goodsName+'</h3>'+
			                       '     <p class="item">期号: '+item.id+'</p>'+
			                       '     <p class="item">总需: '+item.needNumber+'</p>'+
			                       '     <p class="item">倒计时: <span class="red ticktime"></span></p>'+
			                       '     <div class="bottom-link">'+
                                '        <div class="fr"><a href="../buy/buy-detail.html?id='+item.id+'&goodsName='+encodeURIComponent(item.goodsName)+'&joinNumber='+item.userJoinNumber+'">查看详情&gt;&gt;</a></div>'+
			                       '         <div class="fl">本期参与：<span class="red">'+item.userJoinNumber+'</span>人次</div>'+
			                       '     </div>'+
			                       '   </div>'+
			                       ' </div>'+
			                       '</li>';
			            }else if(item.status==5){
			                str += '<li class="table-view-cell media">'+
			                       ' <div class="navigate-right">'+
			                       '   <div class="pic-left"><a href="../detail.html?goodsId='+item.goodsId+'&id='+item.id+'"><img class="media-object pull-left" src="'+ImgBlank+'" alt="'+item.goodsName+'" data-echo="'+item.coverImgUrl+'"></a></div>'+
			                       '   <div class="media-body">'+
			                       '     <h3>'+item.goodsName+'</h3>'+
			                       '     <p class="item">期号: '+item.id+'</p>'+
			                       '     <p class="item">总需: '+item.needNumber+'</p>'+
			                       '     <div class="bottom-link">'+
                                   '        <div class="fr"><a href="../buy/buy-detail.html?id='+item.id+'&goodsName='+encodeURIComponent(item.goodsName)+'&joinNumber='+item.userJoinNumber+'">查看详情&gt;&gt;</a></div>'+
			                       '         <div class="fl">本期参与：<span class="red">'+item.userJoinNumber+'</span>人次</div>'+
			                       '     </div>'+
			                       '     <div class="bottom-desc">'+
			                       '         <p>幸运儿: <span class="blue"><a href="../user/friend-index.html?id='+item.kgUid+'">'+item.nickname+'</a></span></p>'+
			                       '         <p class="gray">( '+item.address+item.ip+' )</p>'+
			                       '         <p>用户ID: '+item.kgUid+' </p>'+
			                       '         <p>幸运号码: <span class="red">'+item.code+'</span> </p>'+
			                       '         <p>本期参与: <span class="red">'+item.winnerJoinNumber+'</span>人次 </p>'+
			                       '         <p>揭晓时间: '+MZ.utils.joinTime(item.openTime)+'</p>'+
			                       '     </div>'+
			                       '   </div>'+
			                       ' </div>'+
			                       '</li>';
			            }
			        }
			        $list.append(str);
              if(Page==1 && list.length == 0){
                var str = '<div class="cart-empty" style="margin-top:20%;">'+
                   ' <i class="icon icon-cartempty"></i>'+
                   ' <h3>暂无夺宝记录</h3>'+
                   ' <a href="../index.html" class="btn btn-red-transparent">马上去夺宝</a>'+
                  '</div>';
                $('.footer-icon').hide();
                if($('.cart-empty').length!=0){
                  $('.cart-empty').show();
                }else{
                  $('body').append(str);
                }
                HasNoMore = true;
              }else if(list.length<pageSize){
               HasNoMore = true;
               //var nomorestr='<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;">没有更多记录</div>';
               //$list.append(nomorestr);
              }
              initTicker();
              //图片延迟加载
              MZ.utils.initEcho();
              Page++;
          }else{
            log(data.errorMessage)
              //MZ.alert({content: data.errorMessage});
          }
          Loading = false;
		    },
		    error: function(){
		      Loading = false;
		    }
		})
    }
    var Page2 = 1;
    function getListTab02(){
        var $list = $('#tabContent02 .for-good-list');
        $('.cart-empty').hide();
        if($list.find('li').length!=0){
          $('.cart-empty').hide();
        }
        if(Loading)return;
        Loading = true;
        Zepto.ajax({
            url: ApiPrefix+'/user/buyLog/list',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,targetKgUid:0,type:3,"pageNumber": Page2,"pageSize": pageSize},
            cache: false,
            success: function(data){
              if(data.errorMessage=='token不合法'){
                  MZ.wechat.checkLogin(data);
                  return;
                }
              servertime = data.servertime ;
                if(data.status==1){
                  var str = '';
                  var list  = data.data.buyLogList;
                  /*if(list.length == 0){
                    HasNoMore = true;
                    str = '<div class="cart-empty">'+
                               ' <i class="icon icon-cartempty"></i>'+
                               ' <h3>暂无夺宝记录</h3>'+
                               ' <a href="../index.html" class="btn btn-red-transparent">马上去夺宝</a>'+
                              '</div>';
                    $('body').append(str);
                   return; 
                  }*/
                  if(list.length <pageSize){
                    HasNoMore = true;
                  }else{
                    lastId = list[list.length-1].id;                    
                  }
                  for(var i in list) {
                      var item = list[i];
                      if(item.surplusNumber==0){
                        str += '<li class="table-view-cell media new" data-robid="'+item.id+'" servertime="'+servertime+'" starttime="'+(item.startTime+3*60*1000)+'">'+
                             ' <div class="navigate-right">'+
                             '   <div class="pic-left"><a href="../detail.html?goodsId='+item.goodsId+'&id='+item.id+'"><img class="media-object pull-left" src="'+ImgBlank+'" alt="'+item.goodsName+'" data-echo="'+item.coverImgUrl+'"></a></div>'+
                             '   <div class="media-body">'+
                             '     <h3>'+item.goodsName+'</h3>'+
                             '     <p class="item">期号: '+item.id+'</p>'+
                             '     <p class="item">总需: '+item.needNumber+'</p>'+
                             '     <p class="item">倒计时: <span class="red ticktime"></span></p>'+
                             '     <div class="bottom-link">'+
                                '        <div class="fr"><a href="../buy/buy-detail.html?id='+item.id+'&goodsName='+encodeURIComponent(item.goodsName)+'&joinNumber='+item.userJoinNumber+'">查看详情&gt;&gt;</a></div>'+
                             '         <div class="fl">本期参与：<span class="red">'+item.needNumber+'</span>人次</div>'+
                             '     </div>'+
                             '   </div>'+
                             ' </div>'+
                             '</li>';
                      }else{
                        str += '<li class="table-view-cell media">'+
                            '<div class="navigate-right">'+
                            '  <div class="pic-left"><a href="../detail.html?goodsId='+item.goodsId+'&id='+item.id+'"><img class="media-object pull-left" src="'+ImgBlank+'" alt="'+item.goodsName+'" data-echo="'+item.coverImgUrl+'"></a></div>'+
                            '  <div class="media-body">'+
                            '    <div class="media-right">'+
                            '      <a href="javascript:" data-goodsid="'+item.goodsId+'" class="btn btn-red-transparent btnAdd">追加</a>'+
                            '    </div>'+
                            '    <h3>'+item.goodsName+'</h3>'+
                            '    <p class="item">期号: '+item.id+'</p>'+
                            '    <div class="goods-control">'+
                            '      <div class="goods-status">'+
                            '        <div class="progress-bar">'+
                            '          <div class="inner" style="width:'+((item.needNumber-item.surplusNumber)/item.needNumber)*100+'%"></div>'+
                            '        </div>'+
                            '        <span class="fl">总需：'+item.needNumber+'</span>'+
                            '        <span class="fr">剩余<em>'+item.surplusNumber+'</em></span>'+
                            '      </div>'+
                            '    </div>'+
                            '    <div class="bottom-link">'+
                            '        <div class="fr"><a href="../buy/buy-detail.html?id='+item.id+'&goodsName='+encodeURIComponent(item.goodsName)+'&joinNumber='+item.userJoinNumber+'">查看详情&gt;&gt;</a></div>'+
                            '        <div class="fl">本期参与：<span class="red">'+item.userJoinNumber+'</span>人次</div>'+
                            '    </div>'+
                            '  </div>'+
                            '</div>'+
                          '</li>';
                      }
                  }
                  $list.append(str);
                  initTicker();
                  if(Page2==1 && list.length == 0){
                    var str = '<div class="cart-empty" style="margin-top:20%;">'+
                       ' <i class="icon icon-cartempty"></i>'+
                       ' <h3>暂无夺宝记录</h3>'+
                       ' <a href="../index.html" class="btn btn-red-transparent">马上去夺宝</a>'+
                      '</div>';
                    $('.footer-icon').hide();
                    if($('.cart-empty').length!=0){
                      $('.cart-empty').show();
                    }else{
                      $('body').append(str);
                    }
                    HasNoMore = true;
                  }else if(list.length<pageSize){
                   HasNoMore = true;
                   //var nomorestr='<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;">没有更多记录</div>';
                   //$list.append(nomorestr);
                  }
                  //图片延迟加载
                  MZ.utils.initEcho();
                  Page2++;
              }else{
                log(data.errorMessage)
                  //MZ.alert({content: data.errorMessage});
              }
              Loading = false;
            },
            error: function(){
              Loading = false;
            }
        })
    }  
    var Page3 = 1;
    function getListTab03(){
        var $list = $('#tabContent03 .for-good-list');
        $('.cart-empty').hide();
        if($list.find('li').length!=0){
          $('.cart-empty').hide();
        }
        if(Loading)return;
        Loading = true;
        Zepto.ajax({
            url: ApiPrefix+'/user/buyLog/list',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,targetKgUid:0,type:5,"pageNumber": Page3,"pageSize": pageSize},
            cache: false,
            success: function(data){
              if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
              servertime = data.servertime ;
                if(data.status==1){
                  var str = '';
                  var list  = data.data.buyLogList;
                  /*if(list.length == 0){
                    HasNoMore = true;
                    str = '<div class="cart-empty">'+
                               ' <i class="icon icon-cartempty"></i>'+
                               ' <h3>暂无夺宝记录</h3>'+
                               ' <a href="../index.html" class="btn btn-red-transparent">马上去夺宝</a>'+
                              '</div>';
                    $('body').append(str);
                   return; 
                  }*/
                  if(list.length <pageSize){
                    HasNoMore = true;
                  }else{
                    lastId = list[0].id;
                    $('.cart-empty').hide();
                  }
                  for(var i in list) {
                      var item = list[i];
                      str += '<li class="table-view-cell media">'+
                             ' <div class="navigate-right">'+
                             '   <div class="pic-left"><a href="../detail.html?goodsId='+item.goodsId+'&id='+item.id+'"><img class="media-object pull-left" src="'+ImgBlank+'" alt="'+item.goodsName+'" data-echo="'+item.coverImgUrl+'"></a></div>'+
                             '   <div class="media-body">'+
                             '     <h3>'+item.goodsName+'</h3>'+
                             '     <p class="item">期号: '+item.id+'</p>'+
                             '     <p class="item">总需: '+item.needNumber+'</p>'+
                             '     <div class="bottom-link">'+
                                   '        <div class="fr"><a href="../buy/buy-detail.html?id='+item.id+'&goodsName='+encodeURIComponent(item.goodsName)+'&joinNumber='+item.userJoinNumber+'">查看详情&gt;&gt;</a></div>'+
                             '         <div class="fl">本期参与：<span class="red">'+item.userJoinNumber+'</span>人次</div>'+
                             '     </div>'+
                             '     <div class="bottom-desc">'+
                             '         <p>幸运儿: <span class="blue"><a href="../user/friend-index.html?id='+item.kgUid+'">'+item.nickname+'</a></span></p>'+
                             '         <p class="gray">( '+item.address+item.ip+' )</p>'+
                             '         <p>用户ID: '+item.kgUid+' </p>'+
                             '         <p>幸运号码: <span class="red">'+item.code+'</span> </p>'+
                             '         <p>本期参与: <span class="red">'+item.winnerJoinNumber+'</span>人次 </p>'+
                             '         <p>揭晓时间: '+MZ.utils.joinTime(item.openTime)+'</p>'+
                             '     </div>'+
                             '   </div>'+
                             ' </div>'+
                             '</li>';
                  }
                  $list.append(str);
                  if(Page3==1 && list.length==0){
                    var str = '<div class="cart-empty" style="margin-top:20%;">'+
                       ' <i class="icon icon-cartempty"></i>'+
                       ' <h3>暂无夺宝记录</h3>'+
                       ' <a href="../index.html" class="btn btn-red-transparent">马上去夺宝</a>'+
                      '</div>';
                    $('.footer-icon').hide();
                    if($('.cart-empty').length!=0){
                      $('.cart-empty').show();
                    }else{
                      $('body').append(str);
                    }
                    HasNoMore = true;
                  }else if(list.length<pageSize){
                   HasNoMore = true;
                   //var nomorestr='<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;">没有更多记录</div>';
                   //$list.append(nomorestr);
                  }
                  //图片延迟加载
                  MZ.utils.initEcho();
                  Page3++;
              }else{
                log(data.errorMessage)
                  //MZ.alert({content: data.errorMessage});
              }
              Loading = false;
            },
            error: function(){
              Loading = false;
            }
        })
    }
    function addEvent(){
    	var $body = $('body'),
            $friendIndexFixed = $('#myRecordFixed'),
            $friendIndexFixedHeight = $('#myRecordFixedHeight');
        MZ.browser.sticky && $friendIndexFixed.addClass('sticky');
        MZ.browser.sticky || (document.addEventListener("touchmove", function () {
            scroll();
        }), document.addEventListener("scroll", function () {
            scroll();
        }))      
        function scroll() {
            var top = $body.scrollTop();
            if(top>=365){
                $friendIndexFixed.addClass('fixed-tab');
                $friendIndexFixedHeight.height(96);
            }else{
                $friendIndexFixed.removeClass('fixed-tab');
                $friendIndexFixedHeight.height(0);
            }
        }
        //查看详情
        $(document).delegate('li h3','click',function(e){
          var $this = $(this);
          location.href = $this.parents('li').find('.pic-left a').attr('href');
          e.preventDefault();
        })
         //追加
        $(document).delegate('.btnAdd','click',function(e){
          var $this = $(this);
          var toast = new MZ.toast({content:'加入清单中...'});
          var number = 1;
          if($this.parents('li').find('.fr em').html()>500){
              number = 5;
          }
          MZ.cart.addCart({
              goodsList:[{goodsId:$this.attr('data-goodsid'),number:number}],
              callback:function(){
                  toast.setContent('添加成功，跳转页面中');
                  location.href = '../shopping/list.html';
              }
          });
          e.preventDefault();
        })
        //tab
        $('#myRecordFixed a').on('click',function(e){
          var $this = $(this);
          Loading = false;
          HasNoMore = false;
          pageSize=10;
          Page = 1;
          Page2 = 1;
          Page3 = 1;
          lastId = 0;
          $this.addClass('active').siblings('a').removeClass('active');
          if($this.index()==0){
            getListTab01();
            $('#tabContent01 .for-good-list').html('');
            $('#tabContent02').add('#tabContent03').hide();
            $('#tabContent01').show();
          }else if($this.index()==1){
            getListTab02();
            $('#tabContent02 .for-good-list').html('');
            $('#tabContent01').add('#tabContent03').hide();
            $('#tabContent02').show();
          }else {
            $('#tabContent03 .for-good-list').html('');
            $('#tabContent01').add('#tabContent02').hide();
            $('#tabContent03').show();
            getListTab03();
          }
          e.preventDefault();
        })
    }
    
    var ticker;
    function initTicker(){
        var $list = $('.new');
        clearInterval(ticker);
        var systemTime = servertime,localTime=new Date().getTime();

        if($list.length!=0){
            /*systemTime = new Date('2016/03/02 12:30:13').getTime();
            var t1 = new Date('2016/03/02 12:32:13').getTime();
            ticker = setInterval(function(){
                systemTime+=10;
                console.log(MZ.utils.leaveTime(systemTime,t1));
            },10)*/
            ticker = setInterval(function(){
                var stime = systemTime + (new Date().getTime()-localTime);
                for(var i=0;i<$list.length;i++){
                    (function(i){
                      var $item = $list.eq(i);
                      var t = parseInt($item.attr('startTime'));
                      var time = leaveTime(stime,t);
                      if(time==0){
                        $item.find('.ticktime').html('正在揭晓中');
                        if($item.attr('hasGetInfo')!='true'){
                            $item.attr('hasGetInfo','true');
                            var id = $item.attr('data-robid');
                            MZ.ajax.getWin({robid:id,callback:function(data){
                              var data = data.data;
                              $item.removeClass('new');
                              if(data.myWin){
                                MZ.showPrize({id:id,name:$item.find('h3').html(),avatarUrl:$item.find('img').attr('src'),href:'../user/address.html?robid='+id})
                              }
                              if(data.status==5){
                                var str = '<h3><a href="../detail.html?goodsId='+$item.attr('data-goodsid')+'&id='+data.id+'" class="link-black">'+$item.find('h3').html()+'</a></h3>'+
                                          '     <p class="item">期号: '+id+'</p>'+
                                          '     <p class="item">总需: '+$item.attr('data-needNumber')+'</p>'+
                                          '     <div class="bottom-link">'+
                                          '         <div class="fr"><a href="../buy/buy-detail.html?id='+data.id+'&goodsName='+encodeURIComponent($item.find('h3').html())+'&joinNumber='+data.joinNumber+'">查看详情&gt;&gt;</a></div>'+
                                          '         <div class="fl">本期参与：<span class="red">'+$item.attr('data-userJoinNumber')+'</span>人次</div>'+
                                          '     </div>'+
                                          '     <div class="bottom-desc">'+
                                          '         <p>幸运儿: <a href="friend-index.html?id='+data.kgUid+'"><span class="blue">'+data.nickname+'</span></p>'+
                                          '         <p class="gray">( '+data.address+data.ip+' )</p>'+
                                          '         <p>用户ID: '+data.kgUid+' </p>'+
                                          '         <p>幸运号码: <span class="red">'+data.joinCode+'</span> </p>'+
                                          '         <p>本期参与: <span class="red">'+data.joinNumber+'</span>人次 </p>'+
                                          '         <p>揭晓时间: '+MZ.utils.joinTime(data.openTime)+'</p>'+
                                          '     </div>';
                                $item.find('.media-body').html(str);
                              }
                            }})

                          }
                      }else{
                        $item.find('.ticktime').html(leaveTime(stime,t));
                      }
                    })(i)
                }
            },100)
        }
    }
    function leaveTime(startTime,endTime){
      if(startTime>=endTime){
            return 0;
        }else{
            var t =  endTime - startTime;
            var h = 60*60*1000,
                m = 60*1000,
                s = 1000;
            var H = parseInt(t/h),
                M = parseInt((t-H*h)/m),
                S = parseInt((t-H*h-M*m)/s),
                HS = parseInt((t-H*h-M*m-S*s)/100);
            return intNumber(M)+":"+intNumber(S)+":"+HS;
        }
    }
    modules.exports = App;
});
