define(function(require, exports,modules) {
    var App = {};
    var LoadMore = require('widgets/load-more');
    function layout(){
        
    }
    var id,targetKgUid,goodsName;
    App.init = function(){

        id = MZ.utils.getQueryString('id');
        goodsName = MZ.utils.getQueryString('goodsName');
        targetKgUid = MZ.utils.getQueryString('targetKgUid');
        targetKgUid = targetKgUid==null?0:targetKgUid;
        joinNumber = MZ.utils.getQueryString('joinNumber');
        $('#goodsName').html(decodeURIComponent(goodsName));
        $('#number').html(id);
        $('#joinNumber').html(joinNumber);
        addEvent();
        layout();
        getDetail();
    }
    function addEvent(){
        $(document).delegate('.showCode','touchend',function(e){
            var $this = $(this);
            showCode($this.attr('data-id'));
            e.preventDefault();
        })
    }
    function showCode(id){
        Zepto.ajax({
            type:'post',
            url: ApiPrefix+'/user/buyInfo/codes',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,targetKgUid:targetKgUid,id:id},
            dataType:'json',
                cache: false,
            success: function(data){
              if(data.errorMessage=='token不合法'){
                  MZ.wechat.checkLogin(data);
                  return;
                }
              if(data.status==1){
                var codeList = data.data;
                var cardstr = '<div style="max-height:700px;overflow:auto;">';
                var str = '';
                for(var i in codeList){
                    var item = codeList[i];
                    str+= item + " ";
                }
                cardstr+=str+"</div>";
                MZ.alert({title:'<span style="color:#333;font-weight:bold;font-size:32px;margin-top:10px;display:block;">幸运号码</span><br>本期参与了<span class="red">'+codeList.length+'</span>人次',content:cardstr});
              }else{
            MZ.alert({content:data.errorMessage})
          }
        },
        error: function(err){
        }
      })
    }
    function getDetail(){
      Zepto.ajax({
        type:'post',
        url: ApiPrefix+'/user/buyInfo/list',
        data: {token:MZ.utils.getToken(),kgUid:kgUid,targetKgUid:targetKgUid,id:id},
        dataType:'json',
            cache: false,
        success: function(data){
          if(data.errorMessage=='token不合法'){
                  MZ.wechat.checkLogin(data);
                  return;
                }
          if(data.status==1){
            var info = data.data;
            var table = '<table class="table">'+
                        '<thead>'+
                        '  <tr>'+
                        '    <th>购买时间</th>'+
                        '    <th width="30%">参与人数</th>'+
                        '  </tr>'+
                        '</thead>'+
                        '<tbody>';
            var list = data.data;
            for(var i in list){
                var item = list[i];
                table += '<tr>'+
                          '  <td>'+MZ.utils.joinTime(item.buyTime)+'</td>'+
                          '  <td><span class="red">'+item.buyNumber+'</span>人次<br><a href="javascript:" class="showCode" data-id="'+item.id+'">查看号码&gt;&gt;</a></td>'+
                          '</tr>';
            }
            table+='</tbody></table>';
            $('#buytable').html(table)
          }else{
            MZ.alert({content:data.errorMessage})
          }
        },
        error: function(err){
        }
      })
    }
    modules.exports = App;
});
