define(function(require, exports,modules) {
    var App = {};
    var win = window,
    doc = win.document;
    var LoadMore = require('widgets/load-more');
    function layout(){
        
    }
    App.init = function(){
        addEvent();
        layout();
        loadmore();
        getList();
    }
    function loadmore(){
        //初始化下拉加载更多
        $(document).on('scroll touchmove',function(){
            if(HasNoMore){
              $('.loading-more').hide();
              return;
            }
            if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
                if($('.loading-more').length==0){
                    getList();
                }
            }
        });
    }
    var Page = 1;
    var Loading = false;
    var HasNoMore = false;
    var lastId = 0;
    function getList(){
        if(Loading)return;
        Loading = true;
        if(HasNoMore)return;
        var pageSize=10
        Zepto.ajax({
            url: ApiPrefix+'/user/payLog',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,"pageSize": pageSize,lastId:lastId},
            cache: false,
            dataType: 'json',
            success: function(data){
                log(data)
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    var $list = $('.recharge-record-list');
                    var str = '';
                    var list  = data.data.payLogList;
                    for(var i in list) {
                        var item = list[i];
                        //1微信，2支付宝,4信用卡，3储蓄卡
                        var type = '';
                        if(item.payType == 1){
                            type = '微信支付';
                        }else if(item.payType==2){
                            type = '支付宝支付';
                        }else if(item.payType==3){
                            type = '储蓄卡支付';
                        }else if(item.payType==4){
                            type = '信用卡支付';
                        }else if(item.payType==5){
                            type = '微信支付';
                        }
                        str += '<li class="table-view-cell media active">'+
                                '  <div class="navigate-right">'+
                                '    <div class="media-body">'+
                                '      <div class="pull-right">'+item.money+'元</div>'+type+
                                '      <p class="gray">'+MZ.utils.formatDate(item.createTime)+'<br>已付款</p>'+
                                '    </div>'+
                                '  </div>'+
                                '</li>';
                    }
                    $list.append(str);
                    if(list.length!=0){
                        lastId = list[list.length-1].id;
                    }
                    if(Page==1 && list.length == 0){
                       var str = '<div class="cart-empty" style="margin-top:40%;">'+
                                 ' <i class="icon icon-img_empty"></i>'+
                                 ' <h3>暂无赠品</h3>'+
                                 ' <a href="../index.html" class="btn btn-red-transparent">立即夺宝</a>'+
                                '</div>';
                      $('.footer-icon').hide();
                      $('body').append(str);
                      HasNoMore = true;
                    }else if(list.length<pageSize){
                     HasNoMore = true;
                     //var nomorestr='<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;">没有更多记录</div>';
                     //$list.append(nomorestr);
                    }
                    Page++;
                }else{
                    MZ.alert({content: data.errorMessage});
                }
                Loading = false;
            },
            error: function(){
              Loading = false;
            }
        })
        
    }
    
    function addEvent(){
        
    }
    
    modules.exports = App;
});
