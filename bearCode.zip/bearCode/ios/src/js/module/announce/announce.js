define(function(require, exports,modules) {
    var App = {};
    var win = window,
        doc = win.document;
    var LoadMore = require('widgets/load-more');
    function layout(){
        
    }
    App.init = function(){
        addEvent();
        layout();
        //设置底部导航选中样式
        MZ.setNavStatus(1);
        setTimeout(function(){
            $('#pageLottery').fadeIn();
            setTimeout(function(){
                $('#pageLottery').addClass('animatein');
            },500)
        },1000)
        $('.btn-close').on('click',function(){
            $('#pageLottery').removeClass('active');
        })
        loadmore();
        getList();
    }
    function loadmore(){
        //初始化下拉加载更多
        $(document).on('scroll touchmove',function(){
            if(HasNoMore){
              $('.loading-more').hide();
              return;
            }
            if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
                if($('.loading-more').length==0){
                    getList();
                }
            }
        });
    }
    var Loading = false;
    var HasNoMore = false;
    var LastId = 0;
    var Page = 1;
    function getList(){
        if(HasNoMore)return;
        if(Loading)return;
        Loading = true;
        var PageSize = 10;
        log({"kgUid": kgUid,"token": MZ.utils.getToken(),"status": 0,"lastId": LastId,"pageSize": PageSize})
        Zepto.ajax({
            url: ApiPrefix+'/goods/open',
            type: 'post',
            data: {"kgUid": kgUid,"token": MZ.utils.getToken(),"status": 0,"lastId": LastId,"pageSize": PageSize},
            dataType: 'json',
            cache: false,
            success: function(data){
                log(data)
                if(data.errorMessage=='token不合法'){
                  MZ.wechat.checkLogin(data);
                  return;
                }
                if(data.status==1){
                    var $list = $('.for-good-list');
                    var list = data.data.goodsList;
                    var str='';
                    log(list)
                    if(list.length==0){
                      HasNoMore = true;
                      if(Page==1){
                        str+='<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;">暂无最新揭晓</div>';
                      }else{
                        str+='<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;">没有更多记录</div>';
                      }
                    }else{
                      for(var i in list){
                          var item = list[i];
                          var isNew = item.status ==3 ?'new':'';
                          str += '<li data-robid="'+item.id+'" class="table-view-cell media '+isNew+'" servertime="'+data.servertime+'" startTime="'+(item.startTime+3*60*1000)+'">'+
                                 ' <a href="../detail.html?id='+item.id+'" class="navigate-right">'+
                                 '  <div class="pic-left"><img class="media-object pull-left" src="'+ImgBlank+'" data-echo="'+item.coverImgUrl+'"></div>';
                          if(item.status==5){
                              str+='  <div class="media-body">'+
                                     '    <h3>'+item.goodsName+'</h3>'+
                                     '    <p class="item"><span class="total">总需：'+item.needNumber+'</span><span class="join">参与：<em class="red">'+item.joinNumber+'</em>人次</span></p>'+
                                     '    <p class="item">幸运儿：<span class="blue">'+item.nickname+'</span></p>'+
                                     '    <p class="item">揭晓时间：'+formatDate(data.servertime,item.openTime)+'</p>'+
                                     '  </div>'+
                                     ' </a>'+
                                    '</li>'
                          }else if(item.status==3){
                              str+='  <div class="media-body">'+
                                     '    <h3>'+item.goodsName+'</h3>'+
                                     '    <p class="item"><span class="total" data-total="'+item.needNumber+'">总需：'+item.needNumber+'</span></p>'+
                                     '    <div class="time"></div>'+
                                     '  </div>'+
                                     ' </a>'+
                                    '</li>'
                          }
                          if(i==list.length-1){
                            LastId=item.id;
                          }
                      }
                      /*if(PageSize>list.length){
                        str+='<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;">没有更多记录</div>';
                      }*/
                      Page++;
                    }
                    if(Page==1 && list.length==0){
                        $list.html(str);
                    }else{
                        $list.append(str);
                        //延迟加载
                        MZ.utils.initEcho();
                        initTicker();
                    }
                }else{
                    MZ.alert({content: data.errorMessage});
                }
                Loading = false;
            },
            error: function(){
              Loading = false;
            }
        })
        
    }
    function formatDate(servertime,date){
      var st = new Date(servertime);
      var dt = new Date(date);
      if(st.getFullYear()==dt.getFullYear() && st.getMonth()==dt.getMonth() && st.getDate()==dt.getDate()){
        return '今天'+intNumber(dt.getHours())+":"+intNumber(dt.getMinutes());
      }else {
        return dt.getFullYear()+'-'+(dt.getMonth()+1)+'-'+dt.getDate()+' '+intNumber(dt.getHours())+":"+intNumber(dt.getMinutes());
      }
    }
    function addEvent(){
        
    }
    var ticker;
    function initTicker(){
        var $list = $('.media.new');
        clearInterval(ticker);
        var systemTime,localTime=new Date().getTime();
        if($list.length!=0){
            systemTime = parseInt($list.eq(0).attr('servertime'));
            /*systemTime = new Date('2016/03/02 12:30:13').getTime();
            var t1 = new Date('2016/03/02 12:32:13').getTime();
            ticker = setInterval(function(){
                systemTime+=10;
                console.log(MZ.utils.leaveTime(systemTime,t1));
            },10)*/
            ticker = setInterval(function(){
                var stime = systemTime + (new Date().getTime()-localTime);
                for(var i=0;i<$list.length;i++){
                    (function(i){
                      var $item = $list.eq(i);
                      var t = parseInt($item.attr('startTime'));
                      var time = MZ.utils.leaveTime(stime,t);
                      if(time==0){
                        $item.find('.time').html('<span style="font-size:40px;">正在揭晓中</span>');
                        setTimeout(function(){
                          $item.removeClass('new');
                          if($item.attr('hasGetInfo')!='true'){
                            $item.attr('hasGetInfo','true');
                            var id = $item.attr('data-robid');
                            MZ.ajax.getWin({robid:id,callback:function(data){
                              var data = data.data;
                              if(data.myWin){
                                MZ.showPrize({id:id,name:$item.find('h3').html(),avatarUrl:$item.find('img').attr('src'),href:'../user/address.html?robid='+id})
                              }
                              if(data.status==5){
                                var str = '<h3>'+$item.find('h3').html()+'</h3>'+
                                       '<p class="item"><span class="total">总需：'+$item.find('.total').attr('data-total')+'</span><span class="join">参与：<em class="red">'+data.joinNumber+'</em>人次</span></p>'+
                                       '<p class="item">幸运儿：<span class="blue">'+data.nickname+'</span></p>'+
                                       '<p class="item">揭晓时间：'+MZ.utils.formatDate(data.openTime)+'</p>';
                                $item.find('.media-body').html(str);
                              }
                            }})
                          }
                        },1000)
                      }else{
                        $item.find('.time').html(leaveTime(stime,t));
                      }
                    })(i)
                }
            },100)
        }
    }
    function leaveTime(startTime,endTime){
      if(startTime>=endTime){
            return 0;
        }else{
            var t =  endTime - startTime;
            var h = 60*60*1000,
                m = 60*1000,
                s = 1000;
            var H = parseInt(t/h),
                M = parseInt((t-H*h)/m),
                S = parseInt((t-H*h-M*m)/s),
                HS = parseInt((t-H*h-M*m-S*s)/100);
            return intNumber(M)+":"+intNumber(S)+":"+HS;
        }
    }
    modules.exports = App;
});
