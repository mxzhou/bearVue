define(function(require, exports,modules) {
    var App = {};
    var Page = 1;
    var win = window,
        doc = win.document;
    var $dataList = $('#dataList');
    function layout(){
        var winH = $(window).height();
        $('.tab-nav-slide').css({height:winH-180,'overflow':'auto'})
    }
    var CODE;
    App.init = function(){
        addEvent();
        layout();
        CODE = MZ.utils.getQueryString('code');
        var params = {};
        if(CODE=='null'||CODE==null){
            params.goodsCode = 'all';
        }else{
            params.goodsCode = CODE;
        }
        params.type = 0;        
        ajaxGetHotSort();
        loadMore();
    }
    var HasNoMore = false;
    var Loading = false;
    function loadMore(){
        $(document).on('scroll touchmove',function(){
            if($('.nomore').css('display')=='block')return;
            if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
                if($('.loading-more').length==0){
                    $('<div class="center loading-more"><div class="animate-loading-spiner"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div></div>').insertAfter($dataList);
                    getList({type:$('#typeDl dd.active a').attr('data-type'),code:$('#cotegoryList dd.active a').attr('data-code')});
                }
            }
        });
    }
    function getList(params){
        if(Loading)return;
        Loading = true;
        if(HasNoMore)return;
        var type = params.type;
        var code = params.code;
        $('.loading-more').show();
        var PageSize = 10;
        Zepto.ajax({
            url: ApiPrefix+'/goods/type/list',
            type: 'post',
            data: {kgUid: kgUid,"token": MZ.utils.getToken(),"status": 0,"lastId": 0,"pageNumber": Page,"pageSize": PageSize,"type":type,"goodsCode": code},
            cache: false,
            success:function(data){
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    var data = data.data;
                    var list = data.goodsList;
                    var str = '';
                    log(data);
                    if(list.length==0){
                    }else{
                        for(var i in list){
                            var item = list[i];
                            str+='<li class="table-view-cell media">'+
                                '<div href="detail-calculation.html" class="navigate-right">'+
                                '  <div class="pic-left"><a href="detail.html?goodsId='+item.goodsId+'&id='+item.id+'"><img class="media-object pull-left" src="'+ImgBlank+'" data-echo="'+item.coverImgUrl+'"></div>'+
                                '  <div class="media-body">'+
                                '    <div class="media-right">'+
                                '      <a href="javascript:" data-id="'+item.goodsId+'" class="btn btn-red-transparent btn-small jsAddCar">加入清单</a>'+
                                '    </div>'+
                                '    <h3><a href="detail.html?goodsId='+item.goodsId+'&id='+item.id+'" class="link-black">'+item.goodsName+'</a></h3>'+
                                '    <div class="goods-control">'+
                                '      <div class="goods-status">'+
                                '        <div class="progress-bar">'+
                                '          <div class="inner" style="width:'+((item.needNumber-item.surplusNumber)/item.needNumber*100)+'%;"></div>'+
                                '        </div>'+
                                '        <span class="fl">总需：'+item.needNumber+'</span>'+
                                '        <span class="fr">剩余<em>'+item.surplusNumber+'</em></span>'+
                                '      </div>'+
                                '    </div>'+
                                '  </div>'+
                                '</div>'+
                              '</li>'
                        }
                        Page++;
                    }
                    if(Page==1 && list.length==0){
                        $dataList.html(str);
                    }else{
                        $dataList.append(str);
                    }
                    if(list.length < PageSize){
                        if($('.nomore').length==0){
                            //$('<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;">暂无更多</div>').insertAfter($dataList);
                        }
                    }
                    //延迟加载
                    MZ.utils.initEcho();
                }else{
                    MZ.alert({content: data.errorMessage});
                }
                Loading = false;
                $('.loading-more').hide();
            },
            error: function(){
                Loading = false;
                $('.loading-more').hide();
            }
        })
    }
    function ajaxGetHotSort(){
        Zepto.ajax({
            url: ApiPrefix+'/goods/type',
            type: 'get',
            data: {token:MZ.utils.getToken()},
            cache: false,
            success:function(data){
                if(data.errorMessage=='token不合法'){
                 MZ.wechat.checkLogin(data);
                 return;
                }
                if(data.status==1){
                    var list = data.data;
                    var str = '<dd><a href="javascript:" data-code="all"><span class="icon icon-play"></span>全部</a></dd>';
                    for(var i in list){
                        var item = list[i];
                        str+='<dd><a href="javascript:" data-code="'+item.code+'"><span class="icon icon-play"></span>'+item.name+'</a></dd>';
                    }
                    var $cotegoryList = $('#cotegoryList');
                    $cotegoryList.html(str);
                    var $dd;

                    $cotegoryList.find('dd').each(function(){
                        var $this = $(this);
                        if(CODE==$this.find('a').attr('data-code')){
                            $dd = $this;
                        }
                    })
                    var params;
                    if($dd!=undefined){
                        params = {type:0,code:$dd.find('a').attr('data-code')};
                        $('#jsHotCategory span').html($dd.find('a').text()+'<i class="icon icon-down-nav"></i>');
                        $dd.addClass('active');
                    }else{
                        params = {type:0,code:'all'};
                        $('#jsHotCategory span').html('全部<i class="icon icon-down-nav"></i>');
                    }
                    getList(params);

                }else{
                    MZ.alert({content: data.errorMessage});
                }
            },
            error: function(){
            }
        })
        $('.list-search-history').delegate('dd','click',function(){
            var $this = $(this);
            HasNoMore = false;
            Page = 1;
        })
    }
    function addEvent(){
        $('#jsHotRank').on('click',function(){
            var $this = $(this);
            $('.tab-nav-slide').hide();
            $('#jsHotCategory').removeClass('active');
            if($this.hasClass('active')){
                $this.removeClass('active');
                $('#hotRank').hide();
            }else{
                $this.addClass('active');
                $('#hotRank').show();
            }
        })
        $('#jsHotCategory').on('click',function(){
            var $this = $(this);
            $('.tab-nav-slide').hide();
            $('#jsHotRank').removeClass('active');
            if($this.hasClass('active')){
                $this.removeClass('active');
                $('#hotCategory').hide();
            }else{
                $this.addClass('active');
                $('#hotCategory').show();
            }
        })
        //选择热门分类
        $('#cotegoryList').delegate('dd','click',function(){
            HasNoMore = false;
            Page = 1;
            var $this = $(this);
                code = $this.find('a').attr('data-code');
            $this.addClass('active').siblings('dd').removeClass('active');
            var type = $('#typeDl dd.active a').attr('data-type');
            var params = {
                code: code,
                type: type
            }
            $dataList.html('');
            $('#jsHotCategory').removeClass('active');
            $('#jsHotCategory span').html($this.find('a').text()+'<i class="icon icon-down-nav"></i>');
            $('.tab-nav-slide').hide();
            getList(params);
        })
        //选择类型
        $('#typeDl').delegate('dd','click',function(){
            HasNoMore = false;
            Page = 1;
            var $this = $(this);
            $dataList.html('');
            $this.addClass('active').siblings('dd').removeClass('active');
            $('#jsHotRank').removeClass('active');
            $('#jsHotRank span').html($this.find('a').text()+'<i class="icon icon-down-nav"></i>');
            $('.tab-nav-slide').hide();
            var code = $('#cotegoryList dd.active a').attr('data-code');
            var params = {
                code: code,
                type: $this.find('a').attr('data-type')
            }
            getList(params);
        })
        //加入清单
        MZ.cart.init();
        $(document).delegate('.jsAddCar','touchend',function(){
            var $this = $(this),
                $parentLi = $this.parents('li'),
                $img = $parentLi.find('img');
            var $animatePic = $('<div class="animate-pic"></div>');
            $('body').append($animatePic);
            var imgOffset = $img.offset();
            var scrollTop = $('body').scrollTop();
            $animatePic.css({'width':imgOffset.width,'height':imgOffset.height,'top':imgOffset.top-scrollTop,'left':imgOffset.left-30})
                .html('<img src="'+$img.attr('src')+'">');
            var number = 1;
            if($parentLi.find('.fr em').html()>500){
                number = 5;
            }
            MZ.cart.addCart({goodsList:[{goodsId:$this.attr('data-id'),number:number}]});
            var $tabItemCar = $('.icon-ic_shoppingcart');
                tabItemOffset = $tabItemCar.offset();
            var moveTop = scrollTop-imgOffset.top-70;
            TweenMax.fromTo($animatePic,2,
                {x:0,ease:Power2.easeOut},
                {x:tabItemOffset.left-imgOffset.left,y:moveTop,opacity:0,scale:0.2,ease:Power2.easeOut,
                onComplete:function(){
                    $animatePic.remove();
                }
            });
        })
    }
    modules.exports = App;
});
