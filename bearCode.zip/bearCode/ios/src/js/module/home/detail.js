define(function(require, exports,modules) {
    var App = {};
    var Page = 1;
    var win = window,
        doc = win.document;
    var $joinList = $('#joinList');
    function layout(){
        var winH = $(window).height();
        $('.tab-nav-slide').css({height:winH-180,'overflow':'auto'})
    }
    var ID,GOODSID;
    App.init = function(){
        ID = MZ.utils.getQueryString('id');
        ID = ID == null?0:ID;
        GOODSID = MZ.utils.getQueryString('goodsId');
        GOODSID = GOODSID == null?0:GOODSID;
        addEvent();
        layout();
        getJoin();
        getDetail();
        loadMore();
        
        MZ.cart.init();
    }
    var Loading = false;
    function loadMore(){
        $(document).on('scroll touchmove',function(){
            if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
                if($('.loading-more').length==0){
                    getList();
                }
            }
        });
    }
    var serverTime = new Date().getTime();
    var startTime;
    function getDetail(){
        Zepto.ajax({
            url: ApiPrefix+'/goods/detail',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,id:ID,goodsId:GOODSID},
            cache: false,
            success: function(data){
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                serverTime = data.servertime;
                if(data.status==1){
                    var info = data.data;
                    ID = info.id;
                    GOODSID = info.goodsId;
                    getList();
                    startTime = info.startTime+3*60*1000;
                    $('.goodsName').html(info.goodsName);
                    $('.goodsDesc').html(info.goodsDesc);
                    $('.number').html(info.id);
                    $('#linkPicDetail').attr('href','/api/goods/'+info.goodsId+'/info');
                    $('#linkWangqi').attr('href','yi/wangqi.html?goodsId='+info.goodsId);
                    $('#linkShare').attr('href','discover/share-list-empty.html?goodsId='+info.goodsId);
                    if(info.status==-1){
                        //已下架
                        $('#statusDisabledBar').hide();
                        $("#statusDisabled").show();
                    }else if(info.status==5){
                        //已揭晓
                        var winner = info.winner;
                        $('#status3').hide();
                        $("#status5").show();
                        $('.winnerName').html('<a href="user/friend-index.html?id='+winner.kgUid+'">'+winner.nickname+"</a>");
                        var userimg = winner.avatarUrl;
                        if(userimg==''||userimg==null){
                            userimg = ImgUser;
                        }
                        $('.winnerImg').html('<a href="user/friend-index.html?id='+winner.kgUid+'"><img src="'+userimg+'"></a>');
                        $('.winnerAddress').html(winner.address);
                        $('.winnerIp').html(winner.ip);
                        $('.winnerKgUid').html(winner.kgUid);
                        $('.winnerJoinNumber').html(winner.joinNumber);
                        $('.winnerJoinCode').html(winner.joinCode);
                        $('.winnerOpenTime').html(MZ.utils.formatDate(winner.openTime));
                        $('#statusForNewBar').show();
                        $('#statusForNewBar a').attr('href','detail.html?goodsId='+info.goodsId+'&id=0');
                        $('#linkComplte').attr('href','/api/goods/'+info.id+'/complete');
                    }else if(info.status==3){
                        //计算中
                        $('#status3').show();
                        $('#statusForNewBar').show();
                        $('#statusForNewBar a').attr('href','detail.html?goodsId='+info.goodsId+'&id=0');
                        initTicker();
                    }else if(info.status == 0){
                        //进行中
                        $('#status0').show();
                        $('#toolBar').show();
                        $('.needNumber').html(info.needNumber);
                        $('.surplusNumber').html(info.surplusNumber);
                        $('#progress').css('width',((info.needNumber-info.surplusNumber)/info.needNumber*100)+'%')
                    }
                    $('#startTime').html(getStartTime(info.beginTime));
                    var imgStr = '';
                    for(var i in info.goodsImgList){
                        var item = info.goodsImgList[i];
                        imgStr += '<div class="swiper-slide"><img src="'+item.goodsImgUrl+'" style="height:380px;"></div>'
                    }
                    $('.swiper-wrapper').html(imgStr);
                    var swiper = new Swiper('.swiper-container', {
                        pagination: '.swiper-pagination',
                        paginationClickable: true,
                        loop: true,
                        autoplayDisableOnInteraction : false,
                        autoplay: 3000,
                        width: 750,
                        height: 380
                    });
                }else{
                    MZ.alert({content: data.errorMessage});
                }
            },
            error: function(){
              Loading = false;
            }
        })
    }
    var ticker;
    var HasGet = false;
    function initTicker(){
        var $panel = $('#status3');
        var localTime=new Date().getTime();
        clearInterval(ticker);
        ticker = setInterval(function(){
            var stime = serverTime + (new Date().getTime()-localTime);
            var time = MZ.utils.leaveTime(stime,startTime);
            if(time==0){
                $('#timeStatus').html('正在揭晓中');
                setTimeout(function(){
                    if(!HasGet){
                        //倒计时结束请求奖品揭晓信息
                        getDetail();
                        HasGet = true;
                    }
                },1000)
            }else{
                $('#time').html(time);
            }
        },10)
    }
    //商品用户关系
    var UserPage = 1;
    var codeList=[];//酷买号码
    function getJoin(){   
        Zepto.ajax({
            url: ApiPrefix+'/goods/user',
            type: 'post',
            //dataType: 'json',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,id:ID,pageNumber:UserPage,pageSize:10,goodsId:GOODSID},
            cache: false,
            success: function(data){
                var data = typeof data == 'object'?data:JSON.parse(data);
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    var info = data.data;
                    if(info.joinFlag && info.joinCodeList!=null && info.joinCodeList.length != 0){
                        $('#join').show();
                        var cardstr = '';
                        codeList = info.joinCodeList;
                        for(var i in codeList){
                            var item = codeList[i];
                            if(i<7){
                                cardstr+= item + " ";
                            }
                        }
                        $('#joinNumber').html(info.joinNumber);
                        $('#cardList').html(cardstr);
                    }else{
                        $('#noJoin').show();
                    }
                }else{
                    $('#noJoin').show();
                    /*if(typeof data=='string'){
                        MZ.alert({content: JSON.parse(data).errorMessage});
                    }else{
                        MZ.alert({content: data.errorMessage});
                    }*/
                }
            },
            error: function(){
            }
        })
    }
    //商品往期揭晓
    getpass();
    function getpass(){
        return;
        log(ApiPrefix+'/goods/past')
        Zepto.ajax({
            url: ApiPrefix+'/goods/past',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,id:ID,pageNumber:UserPage,pageSize:10},
            cache: false,
            success: function(data){
                var data = typeof data == 'object'?data:JSON.parse(data);
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    var info = data.data;
                    if(info.joinFlag){
                        $('#join').show();
                    }else{
                        $('#noJoin').show();
                    }
                }else{
                    MZ.alert({content: data.errorMessage});
                }
            },
            error: function(){
            }
        })
    }
    //参与者列表
    var lastId=0;
    var HasNoMore=false;
    function getList(){
        if(Loading)return;
        Loading = true;
        if(HasNoMore)return;
        Zepto.ajax({
            url: ApiPrefix+'/goods/joiner/list',
            type: 'post',
            data: {token:MZ.utils.getToken(),kgUid:kgUid,"lastId": lastId,"pageSize": 10,"id": ID},
            cache: false,
            success:function(data){
                if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    var data = data.data;
                    var list = data.userList;
                    var str = '';
                    if(list.length==0){
                        HasNoMore = true;
                    }else{
                        for(var i in list){
                            var item = list[i];
                            var userimg = item.avatarUrl;
                            if(userimg==''||userimg==null){
                                userimg = ImgUser;
                            }
                            str+='<li class="table-view-cell media">'+
                            ' <div class="pic-left"><a href="user/friend-index.html?id='+item.kgUid+'"><img src="'+ImgBlank+'" data-echo="'+userimg+'"></a></div>'+
                                   ' <div class="media-body">'+
                                   '   <h4><a href="user/friend-index.html?id='+item.kgUid+'">'+item.nickname+'</a></h4>'+
                                   '   <p><span  class="gray">('+item.address+' IP:'+item.ip+')</span></p>'+
                                   '   <p>参与 <span class="red">'+item.joinNumber+'</span> 人次<span class="gray"> '+MZ.utils.joinTime(item.joinTime)+'</span></p>'+
                                   ' </div>'+
                                '</li>'
                        }
                        lastId = list[list.length-1].id;
                        Page++;
                    }
                    if(Page==1 && list.length==0){
                        str+='<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;">暂无参与者</div>';
                        $joinList.html(str);
                    }else{
                        $joinList.append(str);
                    }
                    //延迟加载
                    MZ.utils.initEcho();
                }else{
                    //MZ.alert({content: data.errorMessage});
                }
                Loading = false;
                $('.loading-more').remove();
            },
            error: function(){
                Loading = false;
                $('.loading-more').remove();
            }
        })
    }

    function getStartTime(t){
        var dt = new Date(t);
        return dt.getFullYear()+"-"+intNumber(dt.getMonth()+1)+"-"+intNumber(dt.getDate())+" "+intNumber(dt.getHours())+":"+intNumber(dt.getMinutes())+":"+intNumber(dt.getSeconds());
    }
    function addEvent(){
       //查看全部酷买号码
       $('#showAllCard').on('touchend',function(e){
        var cardstr = '<div style="max-height:700px;overflow:auto;">';
        var str = '';
        for(var i in codeList){
            var item = codeList[i];
            str+= item + " ";
        }
        cardstr+=str+"</div>";
        MZ.alert({title:'<span style="color:#333;font-weight:bold;font-size:32px;margin-top:10px;display:block;">幸运号码</span><br>本期参与了<span class="red">'+codeList.length+'</span>人次',content:cardstr});
        e.preventDefault();
       })
       //加入清单
       $('#btnAddCar').on('touchend',function(e){
            var $this = $(this);
            var toast = new MZ.toast({content:'加入清单中...'});
            var number = 1;
            if($('.surplusNumber').html()>500){
                number = 5;
            }
            MZ.cart.addCart({
                goodsList:[{goodsId:GOODSID,number:number}],
                callback:function(){
                    toast.setContent('添加成功');
                    setTimeout(function(){
                        toast.hide();
                    },1000)
                }
            });
            e.preventDefault();
       })
       //立即参与
        $('#btnJoinNow').on('touchend',function(e){
          var $this = $(this);
          var toast = new MZ.toast({content:'加入清单中...'});
          var number = 1;
            if($('.surplusNumber').html()>500){
                number = 5;
            }
          MZ.cart.addCart({
              goodsList:[{goodsId:GOODSID,number:number}],
              callback:function(){
                  toast.setContent('添加成功，跳转页面中');
                  location.href = 'shopping/list.html';
              }
          });
          e.preventDefault();
        })
       
    }
    modules.exports = App;
});
