define(function(require, exports,modules) {
    var App = {};
    var $listResult = $('#listResult');
    var $searchInput = $('#searchInput');
    var $resultList = $('.for-good-list');
    var $btnClearHistory = $('#btnClearHistory');
    var win = window, 
    doc = document;
    var searchContent,page=1;
    function layout(){
        
    }
    App.init = function(){
      searchContent = decodeURIComponent(MZ.utils.getQueryString('searchContent'));
      if(searchContent!='null'&&searchContent!=null){
        $('#searchbar').addClass('active-search');
        saveSearchContent(searchContent);
        $('#searchInput').val(searchContent);
        page=1;
        $resultList.removeClass('nodata')
        $resultList.html('');
        ajaxGetSearchList();
      }
      addEvent();
      layout();
      ajaxGetHotSearch();
      loadmore();
      searchHistory();
      ajaxGetCategory();
      MZ.cart.init();
    }

    function addEvent(){
        $('#searchInput').on('focus',function(){
            $('#searchArea').show();
            $('#hotArea').hide();
            $listResult.hide();
            $('.footer-icon').hide();
            $('.footer-fixed').hide();
            $('#searchbar').addClass('active-search');
            $('#cancelSearch').show();
            $('#btnCar').hide();
            renderHistory();
            MZ.cart.init();
        })
        $('#cancelSearch').on('click',function(){
            $('#searchArea').hide();
            $('#hotArea').show();
            $listResult.hide();
            $('.footer-icon').hide();
            $('.footer-fixed').hide();
            $searchInput.val('');
            $('#searchbar').removeClass('active-search');
        })
        $('#formSearch').on('submit',function(e){
            searchContent = $searchInput.val().replace(/\s/g,'');
            if(searchContent == ''){
                MZ.alert({content:'请输入搜索内容'})
            }else{
              page=1;
              $resultList.removeClass('nodata')
              $resultList.html('');
              ajaxGetSearchList();
              saveSearchContent(searchContent);
              $('#searchInput').val(searchContent);
            }
            $searchInput.blur();            
            e.preventDefault();
            return false;
        })
        //热门搜索点击
        $('.list-search-hot').delegate('a','click',function(){
          var $this = $(this);
          searchContent = $this.text();
          saveSearchContent(searchContent);
          $('#searchInput').val(searchContent);
          page=1;
          $resultList.removeClass('nodata')
          $resultList.html('');
          ajaxGetSearchList();
        })
        $('#listHistory').delegate('a','click',function(){
          var $this = $(this);
          searchContent = $this.text();
          saveSearchContent(searchContent);
          $('#searchInput').val(searchContent);
          page=1;
          $resultList.removeClass('nodata')
          $resultList.html('');
          ajaxGetSearchList();
        })
        //加入清单
        MZ.cart.init();
        $(document).delegate('.jsAddCar','touchend',function(){
            var $this = $(this),
                $parentLi = $this.parents('li'),
                $img = $parentLi.find('img');
            var $animatePic = $('<div class="animate-pic"></div>');
            $('body').append($animatePic);
            var imgOffset = $img.offset();
            var scrollTop = $('body').scrollTop();
            $animatePic.css({'width':imgOffset.width,'height':imgOffset.height,'top':imgOffset.top-scrollTop,'left':imgOffset.left})
                .html('<img src="'+$img.attr('src')+'">');
            var number = 1;
            if($parentLi.find('.fr em').html()>500){
                number = 5;
            }
            MZ.cart.addCart({goodsList:[{goodsId:$this.attr('data-id'),number:number}]});
            var $tabItemCar = $('.icon-ic_shoppingcart');
                tabItemOffset = $tabItemCar.offset();
            var moveTop = scrollTop-imgOffset.top-70;
            TweenMax.fromTo($animatePic,2,
                {x:0,ease:Power2.easeOut},
                {x:tabItemOffset.left-imgOffset.left,y:moveTop,opacity:0,scale:0.2,ease:Power2.easeOut,
                onComplete:function(){
                    $animatePic.remove();
                }
            });
        })
        //全部加入清单
        $('#btnAddAll').on('click',function(){
          var $liList = $resultList.find('li');
          var goodsList = [];
          $liList.each(function(){
            var $this = $(this);
            var number = 1;
            if($this.find('.fr em').html()>500){
                number = 5;
            }
            goodsList.push({goodsId:$this.attr('data-id'),number:number});
          })
          MZ.cart.addCart({goodsList:goodsList});
          MZ.cart.init();
        })
    }
    var Loading = false;
    function ajaxGetSearchList(){
      if(Loading)return;
      Loading = true;
      if($resultList.hasClass('nodata')){
          Loading= false;
          $('.loading-more').hide();
          return;
      }
      $('#cancelSearch').hide();
      $('#btnCar').show();
      if(searchContent == null || searchContent == 'null'){
        searchContent = '';
      }
      Zepto.ajax({
            url: ApiPrefix+'/goods/search',
            type: 'post',
            data: {"kgUid": kgUid,"token": MZ.utils.getToken(),"status": 0,"pageNumber": page,"pageSize": 10,"searchContent":searchContent},
            dataType: 'json',
            cache: false,
            success: function(data){
              if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    var list = data.data.goodsList;
                    var total = data.data.total;
                    $('#searchArea').add('#hotArea').hide();
                    $listResult.show();
                    $('.footer-icon').show();
                    $('#searchContent').html('搜索 <span class="blue" >'+searchContent+'</span> 的结果 ('+total+') :');
                    if(list.length!=0){
                      var str = '';
                      for(var i in list){
                        var item = list[i];
                        str += '<li class="table-view-cell media" data-id="'+item.goodsId+'">'+
                               ' <div class="navigate-right">'+
                               '   <div class="pic-left"><a href="detail.html?goodsId='+item.goodsId+'&id='+item.id+'"><img class="media-object pull-left" src="'+ImgBlank+'" alt="photo" data-echo="'+item.coverImgUrl+'"></div>'+
                               '   <div class="media-body">'+
                               '     <div class="media-right">'+
                               '       <a href="javascript:" data-id="'+item.goodsId+'" class="btn btn-red-transparent btn-small jsAddCar">加入清单</a>'+
                               '     </div>'+
                               '     <h3><a href="detail.html?goodsId='+item.goodsId+'&id='+item.id+'" class="link-black">'+item.goodsName+'</a></h3>'+
                               '     <div class="goods-control">'+
                               '       <div class="goods-status">'+
                               '         <div class="progress-bar">'+
                               '           <div class="inner" style="width:'+((item.needNumber-item.surplusNumber)/item.needNumber*100)+'%;"></div>'+
                               '         </div>'+
                               '         <span class="fl">总需：'+item.needNumber+'</span>'+
                               '         <span class="fr">剩余<em>'+item.surplusNumber+'</em></span>'+
                               '       </div>'+
                               '     </div>'+
                               '   </div>'+
                               ' </div>'+
                              '</li> ';
                      }
                      $('.footer-fixed').show();
                      if(page==1){
                        $resultList.html(str);
                      }else{
                        $resultList.append(str);
                      }
                      page++;
                      MZ.utils.initEcho();                      
                      $('.loading-more').hide();
                    }else {
                        $resultList.addClass('nodata');
                        $('.nomore').remove();
                        if(total!=0){
                          //$('<div class="center nomore" style="color:#666;padding: .5em 0 1em 0;">暂无更多</div>').insertAfter($resultList);
                        }else{
                          $resultList.html('<div class="center" style="color:#666;padding: 1em 0 1em 0;font-size:28px;">暂无记录</div>');
                        }
                    }
                }else{
                    MZ.confirm({
                        content: data.errorMessage,
                        callback: function(e){
                            //确定后执行
                        }
                    });
                }
                Loading = false;
            },
            error: function(){
              Loading = false;
            }
      })
      
    }
    function loadmore(){
        //初始化下拉加载更多
        $(document).on('scroll touchmove',function(){
          if($listResult.css('display')!='block')return;
            if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
              if($('.animate-loading-spiner').length==0 && $('.nomore').length==0){
                $('<div class="center loading-more"><div class="animate-loading-spiner"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div></div>').insertAfter($resultList);
              }
              ajaxGetSearchList();
            }
        });
    }
    //获取热门搜索关键词
    function ajaxGetHotSearch(){
        var $listSearchHot = $('.list-search-hot');
        Zepto.ajax({
          url: ApiPrefix+'/goods/search/hot',
          cache: false,
          type: 'get',
          success: function(data){
            if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
            if(data.status==1){
                var list = data.data;
                var str = '';
                for(var i in list){
                    var item = list[i];
                    str += '<dd><a href="javascript:">'+item.content+'</a></dd>';
                }
                $listSearchHot.html(str);
            }
          }
        })
    }
    //热门分类
    function ajaxGetCategory(){
      Zepto.ajax({
            url: ApiPrefix+'/goods/type',
            type: 'get',
            cache: false,
            success:function(data){
              if(data.errorMessage=='token不合法'){
                MZ.wechat.checkLogin(data);
                return;
              }
                if(data.status==1){
                    var list = data.data;
                    var str = '';
                    for(var i in list){
                        var item = list[i];
                        str+='<li><a href="category.html?code='+item.code+'">'+
                        '  <div class="fl"><span><img width="120" height="120" src="'+item.coverImgUrl+'"></span></div>'+item.name+'</a>'+
                            '</li>'
                    }
                    $('.hot-category').html(str);
                }
            }
        })
    }
    //搜索历史
    var HistoryList = localStorage.getItem('HistoryList');
    function searchHistory(){
      renderHistory();
      $btnClearHistory.on('click',function(){
        MZ.confirm({
            content: '确定清空全部历史记录？',
            callback: function(e){
               $('#listHistory').html('');
               $btnClearHistory.hide();
               localStorage.removeItem('HistoryList');
            }
        });
      })

    }
    function renderHistory(){
      HistoryList = localStorage.getItem('HistoryList');
      if(HistoryList == null){
        $btnClearHistory.hide();
      }else{
        var arr = JSON.parse(HistoryList);
        var str = '';
        for(var i in arr){
          str+='<dd><a href="javascript:">'+arr[i]+'</a></dd>';
        }
        $('#listHistory').html(str);
        $btnClearHistory.show();
      }
    }
    function saveSearchContent(content){
      if(content == 'null' || content== null || content.replace(/\s/g,'') == ''){
        return;
      }
      HistoryList = localStorage.getItem('HistoryList');
      var arr = [];
      if(HistoryList == null){
        arr.push(content);
      }else{
        var arr = JSON.parse(HistoryList);
        var count=-1;
        for(var i in arr){
          if(content==arr[i]){
            count=i;
          }
        }
        if(count==-1){
          if(arr.length==5){
            arr.pop();
          }
        }else{
          arr.splice(count,1)
        }
        arr.unshift(content);
      }
      localStorage.setItem('HistoryList',JSON.stringify(arr));
    }
    modules.exports = App;
});
