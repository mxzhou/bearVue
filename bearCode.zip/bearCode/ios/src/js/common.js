var MZ = (function(obj){
	
	return obj;
})(MZ || {})
var log = console.log.bind(console);
var Domain = document.domain;
var TEST = false;
if(/((?:(?:25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))\.){3}(?:25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d))))/g.test(Domain)){
	var ApiPrefix = 'http://'+Domain+':8811/api/iosWeb';
	var Prefix = 'http://'+Domain+':8811/api/iosWeb';
	var ImgBlank = 'http://'+Domain+':8811/api/iosWeb/src/images/blank.png';
	var ImgUser = 'http://'+Domain+':8811/api/iosWeb/src/images/default.png';
	var kgUid = 638535348;
  TEST = true;
}else{
	var ApiPrefix = 'http://'+Domain+'/api/iosWeb';
	var Prefix = 'http://'+Domain+'/api/iosWeb';
	var iosWebBlank = 'http://'+Domain+'/api/iosWeb/src/images/blank.png';
	var ImgUser = 'http://'+Domain+'/api/iosWeb/src/images/default.png';
	var kgUid = 0;
  TEST = false;
}
var JSSDK_TITLE = '胖熊一元买',
	JSSDK_DESCSTR = '胖熊一元实现梦想',
	JSSDK_LINKSTR = Domain+'/api/iosWeb/views/index.html',
	JSSDK_ICONSTR = 'http://'+Domain+'/api/iosWeb/src/images/default.png';

;MZ.browser = {
	sticky: function(){
			var a,b="-webkit-sticky",
			c=document.createElement("i");
			return c.style.position=b,a=c.style.position,c=null,a===b
		}(),
	isios: navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? !0 : !1,
	isWechat: navigator.userAgent.toLowerCase().match(/MicroMessenger/i)=="micromessenger" ? !0 : !1,
	isAndroid: -1 < navigator.userAgent.indexOf("Android"),
	isMobile: /AppleWebKit.*Mobile/i.test(navigator.userAgent) || (/MIDP|SymbianOS|NOKIA|SAMSUNG|LG|NEC|TCL|Alcatel|BIRD|DBTEL|Dopod|PHILIPS|HAIER|LENOVO|MOT-|Nokia|SonyEricsson|SIE-|Amoi|ZTE/.test(navigator.userAgent))
}

;MZ.utils = {

    getQueryString : function(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return r[2]; return null;
    },
    leaveTime: function(startTime,endTime){
        if(startTime>=endTime){
            return 0;
        }else{
            var t =  endTime - startTime;
            var h = 60*60*1000,
                m = 60*1000,
                s = 1000;
            var H = parseInt(t/h),
                M = parseInt((t-H*h)/m),
                S = parseInt((t-H*h-M*m)/s),
                HS = parseInt((t-H*h-M*m-S*s)/10);
            return intNumber(M)+":"+intNumber(S)+":"+intNumber(HS);
        }
        
    },
    formatDate: function(dt){
      if(/-/.test(dt)){
        var dt = new Date(dt.replace(/-/g,'/'));
      }else{
        var dt = new Date(dt);
      }
      return dt.getFullYear()+"-"+(dt.getMonth()+1)+"-"+dt.getDate()+" "+intNumber(dt.getHours())+":"+intNumber(dt.getMinutes())+":"+intNumber(dt.getSeconds());
    },
    formatFromToday: function(dtNow,dt){
      var dtNow = new Date(dtNow);
      if(/-/.test(dt)){
        var dt = new Date(dt.replace(/-/g,'/'));
      }else{
        var dt = new Date(dt);
      }
      var dt1 = new Date(dtNow.getTime() - 24*60*60*1000);
      if(dt.getFullYear()==dtNow.getFullYear() && dt.getMonth()==dtNow.getMonth() && dt.getDate()==dtNow.getDate()){
        return '今天'+intNumber(dt.getHours())+":"+intNumber(dt.getMinutes());
      }else {
        return dt.getFullYear()+"-"+(dt.getMonth()+1)+"-"+dt.getDate()+" "+intNumber(dt.getHours())+":"+intNumber(dt.getMinutes());
      }    
    },
    joinTime: function(t){
        var dt = new Date(t);
        return dt.getFullYear()+"-"+(dt.getMonth()+1)+"-"+dt.getDate()+" "+intNumber(dt.getHours())+":"+intNumber(dt.getMinutes())+":"+intNumber(dt.getSeconds())+"."+intNumberMil(dt.getMilliseconds());
    },
    initEcho: function(){
        echo.init({
            offset: 200,
            throttle: 250,
            unload: false,
            callback: function (element, op) {
                //console.log(element, 'has been', op + 'ed')
            }
        });
    },
    getToken: function(){
      return sessionStorage.getItem('wxtoken');
    }
    
};
function intNumber(n){
    return n<10?'0'+n:n;
}
function intNumberMil(n){
    return n<100?'0'+n:n;
}

;MZ.cart = {

	init : function() {
      if(!localStorage) return;
  		var $footerNav = $('.footer-nav');
      var cartNum = localStorage.getItem('cartNum');
  		if($footerNav.length!=0){
  			var  $badge = $footerNav.find('.tab-item').eq(3).find('.badge');
  			if(cartNum==null){
  				$badge.hide();
  			}else{
  				$badge.html(cartNum).show();
  			}
  		}
      var $btnCar = $('#btnCar').find('.badge');
      if($btnCar.length!=0){
        log("cartNum:"+cartNum)
        if(cartNum==null){
          $btnCar.hide();
        }else{
          $btnCar.html(cartNum).show();
        }
      }
    },
    getCartDetail: function() {
    	
    },
    update: function(number){
      if(number!=0){
        localStorage.setItem('cartNum',number);
      }else{
        localStorage.removeItem('cartNum',number);
      }
      MZ.cart.init();
    },
    addCart: function(config){    
    	var cartNum = localStorage.getItem('cartNum');
      console.log(config.goodsList);
    	Zepto.ajax({
    		type:'post',
    		url: ApiPrefix+'/cart/add',
    		data: {token:MZ.utils.getToken(),kgUid:kgUid,goodIds:JSON.stringify(config.goodsList)},
    		dataType:'json',
            cache: false,
  			success: function(data){
          log(data)
          if(data.errorMessage=='token不合法'){
            MZ.wechat.checkLogin(data);
            return;
          }
  				if(data.status==1){
            if(cartNum == null){
              if(data.data.totalNumber!=0){
                localStorage.setItem('cartNum',1);
              }
            }else{
              if(data.data.totalNumber!=0){
                localStorage.setItem('cartNum',data.data.totalNumber);
              }
            }
            config.callback&&config.callback();
  					MZ.cart.init();
  				}else{
            MZ.alert({content:'加入清单错误，请稍后再试'})
          }
  			},
        error: function(err){
        }
    	})
    }
    
};

MZ.cart.init();
;MZ.mask = {

	show : function($mask,type) {
		var $maskInner = $mask.find('.mask-inner'),
			$maskBg = $mask.find('.mask-bg');
		$mask.css({'height':window.innerHeight, 'display':'block'}).addClass('fadeIn');
		switch(type){
			case 'slideDown':
				$maskInner.addClass('slideDown');
				setTimeout(function(){
					$maskInner.addClass('in');
				},20)

		}
    },
    hide: function($mask,type) {
    	var $maskInner = $mask.find('.mask-inner'),
			$maskBg = $mask.find('.mask-bg');
		$mask.removeClass('fadeIn');
		$maskInner.removeClass('slideDown').removeClass('in');
		$mask.hide();
    }
    
}
;(function(obj){
    var body = document.body;
    obj.dropdown = {
        init: function(){
            this.addEvent();
        },
        addEvent: function(){
           $(document).delegate('.for-slide .item-title','click',function(){
             var $this = $(this)
             $this.toggleClass('active');
             $this.next().toggle();
           })
        }
    }     
    obj.radio = {
        init: function(){
            this.addEvent();
        },
        addEvent: function(){
          return;
            $(document).delegate('.radio-list li','click',function(){
                var $this = $(this);
                $this.toggleClass('active').siblings('li').removeClass('active');
            })
        }
    }  
    obj.toggle = {
        init: function(){
            this.addEvent();
        },
        addEvent: function(){
            $(document).delegate('.toggle','click',function(){
                var $this = $(this);
                $this.toggleClass('active');
            })
        }
    }
    obj.confirm = function(config){
        var content = config.content ? config.content : '',
            title = config.title ? config.title : '确认提示',
            cancleFunc = config.cancle,
            callback = config.callback;
        var txt1 = config.text1 == undefined?'取消':config.text1;
        var txt2 = config.text2 == undefined?'确定':config.text2;
        var timestamp = new Date().getTime();
        var str = '<div class="weui_dialog_confirm" id="dialog'+timestamp+'">'+
                   ' <div class="weui_mask"></div>'+
                   ' <div class="weui_dialog">'+
                   '     <div class="weui_dialog_hd"><strong class="weui_dialog_title">'+title+'</strong></div>'+
                   '     <div class="weui_dialog_bd">'+content+'</div>'+
                   '     <div class="weui_dialog_ft">'+
                   '         <a href="javascript:;" class="weui_btn_dialog default jsCancle">'+txt1+'</a>'+
                   '         <a href="javascript:;" class="weui_btn_dialog primary jsOk">'+txt2+'</a>'+
                   '     </div>'+
                   ' </div>'+
                '</div>';
        $('body').append(str);
        var $dialog = $('#dialog'+timestamp);
        setTimeout(function(){
         $dialog.find('.weui_dialog').addClass('active');
        },50) 
        $dialog.find('.jsCancle').on('click touchend',function(e){
            e.preventDefault();
            $dialog.remove();
            cancleFunc && cancleFunc();
        })
        $dialog.find('.jsOk').on('click touchend',function(e){
            e.preventDefault();
            callback && callback(e);
            $dialog.remove();
        })
        this.hide = function(){
            $dialog.remove();
        }
        return 'dialog'+timestamp;
    }
    obj.alert = function(config){
        var content = config.content ? config.content : '',
            title = config.title ? config.title : '',
            cancleFunc = config.cancle,
            callback = config.callback,
            text = config.text ? config.text:'确定',
            footer = config.footer!=null?'display:none;':'';

        var timestamp = new Date().getTime();
        setTimeout(function(){
          $dialog.find('.weui_dialog').addClass('active');
        },50) 
        var str = '<div class="weui_dialog_confirm" id="alert'+timestamp+'">'+
                   ' <div class="weui_mask"></div>'+
                   ' <div class="weui_dialog">'+
                   '     <div class="weui_dialog_hd" style="'+footer+'"><strong class="weui_dialog_title">'+title+'</strong></div>'+
                   '     <div class="weui_dialog_bd">'+content+'</div>'+
                   '     <div class="weui_dialog_ft" style="'+footer+'">'+
                   '         <a href="javascript:;" class="weui_btn_dialog primary jsOk">'+text+'</a>'+
                   '     </div>'+
                   ' </div>'+
                '</div>';
        $('body').append(str);
        var $dialog = $('#alert'+timestamp);
        $dialog.find('.jsOk').on('click touchend',function(e){
            e.preventDefault();
            callback && callback(e);
            $dialog.remove();
        })
        return 'alert'+timestamp;
    }
    obj.loading = function(config){
      var content = arguments[0] ? config.content : '数据加载中';
      var timestamp = new Date().getTime();
      this.id = 'toast'+timestamp;
      var str = '<div id="'+this.id+'" class="weui_loading_toast" style="">'+
                '  <div class="weui_mask_transparent"></div>'+
                '  <div class="weui_toast">'+
                '      <div class="weui_loading">'+
                '          <div class="weui_loading_leaf weui_loading_leaf_0"></div>'+
                '          <div class="weui_loading_leaf weui_loading_leaf_1"></div>'+
                '          <div class="weui_loading_leaf weui_loading_leaf_2"></div>'+
                '          <div class="weui_loading_leaf weui_loading_leaf_3"></div>'+
                '          <div class="weui_loading_leaf weui_loading_leaf_4"></div>'+
                '          <div class="weui_loading_leaf weui_loading_leaf_5"></div>'+
                '          <div class="weui_loading_leaf weui_loading_leaf_6"></div>'+
                '          <div class="weui_loading_leaf weui_loading_leaf_7"></div>'+
                '          <div class="weui_loading_leaf weui_loading_leaf_8"></div>'+
                '          <div class="weui_loading_leaf weui_loading_leaf_9"></div>'+
                '          <div class="weui_loading_leaf weui_loading_leaf_10"></div>'+
                '          <div class="weui_loading_leaf weui_loading_leaf_11"></div>'+
                '      </div>'+
                '      <p class="weui_toast_content">'+content+'</p>'+
                '  </div>'+
              '</div>';
        $('body').append(str);
        this.$container = $('#'+this.id);
    }
    obj.loading.prototype = {
      finish: function(content){
        var _this = this;
        var content = arguments[0] ? content : '已完成';
        _this.$container.find('.weui_toast_content').html(content);
        _this.$container.find('.weui_loading').replaceWith('<i class="icon icon-check"></i>')
        setTimeout(function(){
          _this.$container.remove();
        },1000)
      },
      hide: function(){
        this.$container.remove();
      }
    }
    obj.toast = function(config){
        var content = config.content ? config.content : '';
        var timestamp = new Date().getTime();
        this.id = 'toast'+timestamp;
        var str = '<div class="toast" id="'+this.id+'">'+content+'</div>';
        $('body').append(str);
        var $container = $('#toast'+timestamp);
        setTimeout(function(){
         $container.addClass('active');
        },50) 
        if(config.hide){
            setTimeout(function(){
                $container.remove();
            },config.time||3000)
        }
        this.$container = $container;
    }
    obj.toast.prototype = {
      setContent: function(content){
        this.$container.html(content);
      },
      hide: function(){
        this.$container.remove();
      }
    }
    obj.showPrize = function(config){
      var id = config.id,          
          img = config.avatarUrl,
          name = config.name;
      var str = '<div class="modal transparent active" id="pageLottery" style="display: none;">'+
                '<div class="lottery-dialog">'+
                 '   <div class="inner">'+
                 '       <div class="pic"><img src="'+img+'"></div>'+
                 '       <p>期号：'+id+'</p>'+
                 '       <h3>'+name+'</h3>'+
                 '       <div class="btn-area">'+
                 '           <a href="'+config.href+'" class="btn btn-red">选择收货地址</a>'+
                 '       </div>'+
                 '   </div>'+
                '</div>'+
                '<a href="javascript:" class="btn-close"><i class="icon icon-close-wechat"></i></a>'+
            '</div>'
        var $pageLottery = $(str);
        $('body').append($pageLottery);
        $pageLottery.fadeIn();
        setTimeout(function(){
            $pageLottery.addClass('animatein');
        },500)
        $pageLottery.find('.btn-close').on('click touchend',function(e){
          e.preventDefault();
          $pageLottery.removeClass('active');
        })
    }
    obj.showShare = function(){
      var str = '<div class="modal transparent" id="pageShare">'+
               ' <i class="icon icon-img_sharearrow_2x"></i>'+
              '</div>';
      if($('#pageShare').length==0){
        $('body').append(str);
      }
      setTimeout(function(){
       $('#pageShare').addClass('active');
      },100)
      $(document).delegate('#pageShare','touchend touchend',function(e){
        $('#pageShare').removeClass('active');
        MZ.wechat.init({
           title: JSSDK_TITLE,
           desc: JSSDK_DESCSTR,
           link: JSSDK_LINKSTR,
           imgUrl: JSSDK_ICONSTR
        })
        e.preventDefault();
      })
    }
    obj.showSharePrize = function(config){
      var str = '<div class="modal transparent active" id="pageSharePrize" style="display: none;">'+
                '<div class="lottery-dialog">'+
                ''+
                '</div>'+
                '<a href="javascript:" class="btn-close"><i class="icon icon-close-wechat"></i></a>'+
            '</div>'
        var $pageSharePrize = $(str);
        $('body').append($pageSharePrize);
        $pageSharePrize.fadeIn();
        setTimeout(function(){
            $pageSharePrize.addClass('animatein');
        },500)
        $pageSharePrize.find('.btn-close').on('click touchend',function(e){
          e.preventDefault();
          $pageSharePrize.removeClass('active');
        })
    }
    obj.showLuckyBag = function(list){
      var str = '<div class="modal transparent active" id="pageLuckyBag" style="display: none;">'+
      '<div class="lucky-dialog"><div class="number"><span class="nicon nicon-1"></span></div><div class="lucky-list">'+
                  '<ul>'+list+'</ul>'+
                  '</div><div class="center"><a href="'+Prefix+'/views/user/luckybag.html" class="btn btn-green">领取红包</a></div></div>'+
                  '<a href="javascript:" class="btn-close"><i class="icon icon-close-wechat"></i></a>'+
              '</div>'
        var $pageLuckyBag = $(str);
        $('body').append($pageLuckyBag);
        $pageLuckyBag.fadeIn();
        setTimeout(function(){
            $pageLuckyBag.addClass('animatein');
        },500)
        $pageLuckyBag.find('.btn-close').on('click touchend',function(e){
          e.preventDefault();
          $pageLuckyBag.removeClass('active');
        })
    }
    obj.showFirst = function(){
      if(typeof noLogin!=undefined){
        return;
      }
      if(!/share.html/g.test(location.href)){
        if(localStorage.getItem('isFirst')==null){
          var str = '<div class="modal transparent active" id="pageFirst">'+
          ' <div class="leadin"><a href="javascript:" class="btn btn-red" id="btnStart">马上试试</a></div>'+
                  '</div>';
          if($('#pageFirst').length==0){
            $('body').append(str);
          }
        }
        $(document).delegate('#btnStart','click touchend',function(e){
          $('#pageFirst').fadeOut();
          localStorage.setItem('isFirst',false)
          e.preventDefault();
        })
      }

    }
    obj.showShareResult = function(info){     
      var str = '<div class="modal transparent active" id="pageShareResult" style="display: none;">'+
                '<div class="lottery-dialog">'+
                 '   <div class="inner">'+
                 '       <div class="pic">￥'+info.money+'<br><span>'+info.typeName+'</span></div>'+
                 '       <p>分享成功！<br>恭喜你获得 '+info.money+' 元红包</p>'+
                 '       <div class="btn-area">'+
                 '           <a href="'+Prefix+'/views/index.html" class="btn btn-red">马上购物</a>'+
                 '       </div>'+
                 '   </div>'+
                '</div>'+
                '<a href="javascript:" class="btn-close"><i class="icon icon-close-wechat"></i></a>'+
            '</div>'
        var $pageLottery = $(str);
        $('body').append($pageLottery);
        $pageLottery.fadeIn();
        setTimeout(function(){
            $pageLottery.addClass('animatein');
        },500)
        $pageLottery.find('.btn-close').on('click touchend',function(e){
          e.preventDefault();
          $pageLottery.removeClass('active');
        })
    }
    obj.setNavStatus = function(idx){
        var $footerNav = $('.footer-nav');
        $footerNav.find('.tab-item').eq(idx).addClass('active');
    }
    return obj;
})(MZ || {});
//:active效果
document.body.addEventListener('touchstart',function(){},false);
MZ.dropdown.init();
MZ.radio.init();
MZ.toggle.init();
MZ.showFirst();
;MZ.wechat = {
  login: function(){
    Zepto.ajax({
      url: ApiPrefix+'/getCodeUrl',
      type: 'post',
      data: {url:encodeURIComponent(location.href.split('#')[0]),code:MZ.utils.getQueryString('code')},
      cache: false,
      async: false,
      success: function(data){
          if(data.errorCode==410018){
            MZ.alert({content:'<div style="padding:30px 0;">您的账号已被禁用</div>',footer:true});
            return;
          }
          if(data.errorCode==410019){
            MZ.alert({content:'<div style="padding:30px 0;">暂未开放，升级中...</div>',footer:true});
            return;
          }
          if(data.success == 1){
            alert(data.wxtoken)
            sessionStorage.setItem('wxtoken',data.wxtoken);            
          }else{
            if(!TEST){
              location.href = data.getCodeUrl;
            }
          }
      },
      error: function(){
      }
    })
  },
  getSignature: function(){
    Zepto.ajax({
      url: ApiPrefix+'/getSignature',
      type: 'post',
      data: {url:encodeURIComponent(location.href.split('#')[0])},
      cache: false,
      success: function(data){
          if(data.success == 1){            
            initJSSDK(data);
          }
      },
      error: function(){
      }
    })
  },
  checkLogin: function(data){
    if(data.errorMessage=='token不合法'){
      if($('.weui_dialog_confirm').length==0){
        MZ.alert({content:'欢迎回到酷狗一元买',text:'马上夺宝',callback:function(){
          MZ.wechat.login();
        }});
      }
    }
  },
  /**
   * 初始化微信分享配置
   */
   /*MZ.wechat.init({
    title: 'title',//不可为空
    desc: 'desc',//不可为空
    link: 'link',//不可为空
    imgUrl: 'imgUrl',//不可为空
    trigger: function(){},//可为空
    success: function(){},//可为空
    cancel: function(){},//可为空
    fail: function(){}//可为空
  })*/
  init: function(config){
    _czc = _czc || {};
    if(!config){
      alert('config undefined');
    }
    wx.ready(function () {
      //分享给朋友
      wx.onMenuShareAppMessage({
        title: config.title,
        desc: config.desc,
        link: ''+config.link+'',
        imgUrl: ''+config.imgUrl+'',
        trigger: function (res) {
          _czc.push(["_trackEvent", "点击弹出分享给朋友", "click", 'startup', 1]);
          config.trigger && config.trigger();
        },
        success: function (res) {
          _czc.push(["_trackEvent", "分享给朋友", "click", 'startup', 1]);
          config.success && config.success();
        },
        cancel: function (res) {
          _czc.push(["_trackEvent", "取消分享给朋友", "click", 'startup', 1]);
          config.cancel && config.cancel();
        },
        fail: function (res) {
          _czc.push(["_trackEvent", "分享到朋友失败", "click", 'startup', 1]);
          config.fail && config.fail();
        }
      });
      //分享到朋友圈
      wx.onMenuShareTimeline({
        title: config.title,
        desc: config.desc,
        link: ''+config.link+'',
        imgUrl: ''+config.imgUrl+'',
        trigger: function (res) {
          _czc.push(["_trackEvent", "点击弹出分享到朋友圈", "click", 'startup', 1]);
          config.trigger && config.trigger();
        },
        success: function (res) {
          _czc.push(["_trackEvent", "成功分享到朋友圈", "click", 'startup', 1]);
    config.success && config.success();
        },
        cancel: function (res) {
          _czc.push(["_trackEvent", "取消分享到朋友圈", "click", 'startup', 1]);
          config.cancel && config.cancel();
        },
        fail: function (res) {
          _czc.push(["_trackEvent", "分享到朋友圈失败", "click", 'startup', 1]);
          config.fail && config.fail();
        }
      });
  })
  wx.error(function (res) {
    alert(res.errMsg);
  });
  }

}
$(document).on('ajaxBeforeSend', function(e, xhr, options){
 /* if(sessionStorage.getItem('wxtoken')==null){
    MZ.wechat.login();    
  }*/
})
/*if(sessionStorage.getItem('wxtoken')==null){
  if(typeof noLogin == 'undefined'){
    MZ.wechat.login();
  }
}*/

function initJSSDK(data){
  if(!data)return;
  wx.config({
      debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
      appId: data.appId, // 必填，公众号的唯一标识
      timestamp: data.timestamp, // 必填，生成签名的时间戳
      nonceStr: data.nonceStr,   // 必填，生成签名的随机串
      signature: data.signature, // 必填，签名，见附录1
      jsApiList: [
          'onMenuShareTimeline',
          'onMenuShareAppMessage',
          'onMenuShareQQ',
          'onMenuShareWeibo'
      ] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
  });
  MZ.wechat.init({
     title: JSSDK_TITLE,
     desc: JSSDK_DESCSTR,
     link: JSSDK_LINKSTR,
     imgUrl: JSSDK_ICONSTR
  })
}
//MZ.wechat.getSignature();

;MZ.ajax = {

	getWin : function(params) {
		Zepto.ajax({
        type:'post',
        url: ApiPrefix+'/goods/win',
        data: {token:MZ.utils.getToken(),kgUid:kgUid,id:params.robid},
        dataType:'json',
            cache: false,
        success: function(data){
          if(data.errorMessage=='token不合法'){
            MZ.wechat.checkLogin(data);
            return;
          }
          log(data)
          if(data.status==1){
            params.callback(data);
          }else{
            MZ.alert({content:'查询中奖信息出错，请稍后再试'})
          }
        },
        error: function(err){
            MZ.alert({content:'网络连接出错，请稍后再试'})
        }
      })
  },
  getNewUser: function(){
    //新手红包
    Zepto.ajax({
        type:'post',
        url: ApiPrefix+'/user/newRedEnvelope',
        data: {token:MZ.utils.getToken(),kgUid:kgUid},
        dataType:'json',
        cache: false,
        success: function(data){
          if(data.errorMessage=='token不合法'){
            MZ.wechat.checkLogin(data);
            return;
          }
          if(data.status==1){
            var info = data.data;
            if(info.registerStatus==2){
              MZ.alert({content:info.failMsg});
            }
            if(info.registerStatus==1){
              var list = info.redEnvelopeList;
              /*list = [{
                        "id": 1,
                        "name": "过年红包",
                        "money": 50,
                        "limitSubMoney": 50,
                        "limitTime": "2016-04-27至2016-04-30",
                        "typeName": "iphone类",
                        "useStatus": 0
                    }]*/
              if(list.length!=0){
                var str = '';
                for(var i in list){
                  var item = list[i];
                  str += '<li><span class="fl"><i>￥</i>'+item.money+'</span><h3>'+item.name+'</h3><span class="type">'+item.typeName+'</span><p>满'+item.limitSubMoney+'元可用</p></li>';
                }
                MZ.showLuckyBag(str);
              }
            }
            localStorage.setItem('newUser',false);
          }
        },
        error: function(err){
        }
      })
  },
  getShareResult: function(config){
    var platform = config.platform, 
        type = config.type,
        id = config.id,
        source = config.source,
        shareUrl = location.href;
    //分享获得红包
    Zepto.ajax({
        type:'post',
        url: ApiPrefix+'/user/share',
        data: {token:MZ.utils.getToken(),kgUid:kgUid,platform:platform,id:id,type:type,shareUrl:shareUrl,source:source},
        dataType:'json',
        cache: false,
        success: function(data){
          if(data.errorMessage=='token不合法'){
            MZ.wechat.checkLogin(data);
            return;
          }
          if(data.status==1){
            var info = data.data;
            if(info.id!=0){
              MZ.showShareResult(info);
            }
          }else{
            MZ.alert({content:data.errorMessage});
          }
        },
        error: function(err){
        }
      })
  }
};
//分享获得红包
//MZ.ajax.getShareResult({platform:'朋友圈',type:1,id:120023,source:'wechat'});
//新用户则请求获取新手红包接口
/*if(localStorage){
  MZ.ajax.getNewUser();
  if(localStorage.getItem('newUser')==null){  
    if(typeof noLogin == 'undefined'){
      MZ.ajax.getNewUser();
    }
  }
}*/

;(function (root, factory) {
  if (typeof define === 'function' && define.amd) {
    define(function() {
      return factory(root);
    });
  } else if (typeof exports === 'object') {
    module.exports = factory;
  } else {
    root.echo = factory(root);
  }
})(this, function (root) {

  'use strict';

  var echo = {};

  var callback = function () {};

  var offset, poll, delay, useDebounce, unload;

  var isHidden = function (element) {
    return (element.offsetParent === null);
  };
  
  var inView = function (element, view) {
    if (isHidden(element)) {
      return false;
    }

    var box = element.getBoundingClientRect();
    return (box.right >= view.l && box.bottom >= view.t && box.left <= view.r && box.top <= view.b);
  };

  var debounceOrThrottle = function () {
    if(!useDebounce && !!poll) {
      return;
    }
    clearTimeout(poll);
    poll = setTimeout(function(){
      echo.render();
      poll = null;
    }, delay);
  };

  echo.init = function (opts) {
    opts = opts || {};
    var offsetAll = opts.offset || 0;
    var offsetVertical = opts.offsetVertical || offsetAll;
    var offsetHorizontal = opts.offsetHorizontal || offsetAll;
    var optionToInt = function (opt, fallback) {
      return parseInt(opt || fallback, 10);
    };
    offset = {
      t: optionToInt(opts.offsetTop, offsetVertical),
      b: optionToInt(opts.offsetBottom, offsetVertical),
      l: optionToInt(opts.offsetLeft, offsetHorizontal),
      r: optionToInt(opts.offsetRight, offsetHorizontal)
    };
    delay = optionToInt(opts.throttle, 250);
    useDebounce = opts.debounce !== false;
    unload = !!opts.unload;
    callback = opts.callback || callback;
    echo.render();
    if (document.addEventListener) {
      root.addEventListener('scroll', debounceOrThrottle, false);
      root.addEventListener('load', debounceOrThrottle, false);
    } else {
      root.attachEvent('onscroll', debounceOrThrottle);
      root.attachEvent('onload', debounceOrThrottle);
    }
  };

  echo.render = function () {
    var nodes = document.querySelectorAll('img[data-echo], [data-echo-background]');
    var length = nodes.length;
    var src, elem;
    var view = {
      l: 0 - offset.l,
      t: 0 - offset.t,
      b: (root.innerHeight || document.documentElement.clientHeight) + offset.b,
      r: (root.innerWidth || document.documentElement.clientWidth) + offset.r
    };
    for (var i = 0; i < length; i++) {
      elem = nodes[i];
      if (inView(elem, view)) {

        if (unload) {
          elem.setAttribute('data-echo-placeholder', elem.src);
        }

        if (elem.getAttribute('data-echo-background') !== null) {
          elem.style.backgroundImage = "url(" + elem.getAttribute('data-echo-background') + ")";
        }
        else {
          elem.src = elem.getAttribute('data-echo');
        }

        if (!unload) {
          elem.removeAttribute('data-echo');
          elem.removeAttribute('data-echo-background');
        }

        callback(elem, 'load');
      }
      else if (unload && !!(src = elem.getAttribute('data-echo-placeholder'))) {

        if (elem.getAttribute('data-echo-background') !== null) {
          elem.style.backgroundImage = "url(" + src + ")";
        }
        else {
          elem.src = src;
        }

        elem.removeAttribute('data-echo-placeholder');
        callback(elem, 'unload');
      }
    }
    if (!length) {
      echo.detach();
    }
  };

  echo.detach = function () {
    if (document.removeEventListener) {
      root.removeEventListener('scroll', debounceOrThrottle);
    } else {
      root.detachEvent('onscroll', debounceOrThrottle);
    }
    clearTimeout(poll);
  };

  return echo;

});