define(function(require, exports, module) {

    var webuploader = require('libs/webuploader/0.1.6/webuploader');
    var BASE_URL = 'http://localhost:8088/static/js/libs/webuploader/0.1.6/';
    function init(imgBtn){
        var $dndDiv = $('.source-list'),
            $imgBtn = $(imgBtn),
            file;
        var $parent = $imgBtn.parents('li');
        var $imgList = $('.pic-list');
        var uploader = WebUploader.create({
            auto: false,
            server: '/file/uploadBase64',
            pick: {
                id: imgBtn,
                multiple: false
            },
            accept: {
                title: 'Images',
                extensions: 'gif,jpg,jpeg,bmp,png',
                mimeTypes: 'image/*'
            },
            quality: 100,//图片压缩质量
            fileNumLimit: 1,
            sendAsBinary: false,
            duplicate: false
        });
        //文件添加进来的时候
        uploader.on( 'fileQueued', function( file ) {
            //if($imgList.find('dd').length)
            if(!/image\//g.test(file.type)){
                alert('请选择图片文件上传','warning');
                uploader.cancelFile(file);
                return;
            }
            //文件超过5M校验
            if(file.size >= 2*1024*1024){
                uploader.cancelFile(file);
                file.setStatus('invalid');
                alert('"'+str+'"文件超过2M不能上传','warning',5000);
                return;
            }      
            uploader.makeThumb( file, function( error, src ) {
                uploader.makeThumb( file, function( error, src ) {
                   $.ajax({
                        type: "POST",
                        url: "/file/uploadBase64",
                        data:{imgData:src},
                        dataType:'json',
                        cache: false,
                        success: function(data) {
                            console.log(data)
                            if(data.success==true){
                                $parent.find('.mask').hide();
                                $parent.find('img').attr('src',data.url);
                            }else{
                                MZ.alert({
                                    content: '上传失败，请重新选择上传',
                                    callback: function(e){
                                        $parent.find('.imgclip-block').hide();
                                        $parent.find('.icon-add').show();
                                        uploader.removeFile(file);
                                    }
                                });
                            }
                        }

                    })
                },file._info.width,file._info.height);
            });
            uploader.makeThumb( file, function( error, src ) {
               var imgDiv = '';
                if ( !error ) {
                    //支持预览则添加预览图
                    $imgBtn.hide();
                    $imgBtn.siblings('.imgclip-block').show();
                    $imgBtn.siblings('.imgclip-block').find('img').attr('src',src);
                } 
            }, 188, 188);
            file = file;
        });
        //文件上传中
        uploader.on( 'uploadProgress', function( file, percentage ) {
            //$parent.find('.mask').html('已上传'+parseInt(percentage*100)+'%');
        });
        //上传成功
        uploader.on( 'uploadSuccess', function( file, response ) {
            $parent.find('.mask').hide();
            $parent.find('img').attr('src',response.paths);
        });
        //上传失败
        uploader.on( 'uploadError', function( file ) {
            MZ.alert({
                content: '上传失败，请重新选择上传',
                callback: function(e){
                    $parent.find('.imgclip-block').hide();
                    $parent.find('.icon-add').show();
                    uploader.removeFile(file);
                }
            });
        });
        //上传操作完成，不分成功失败
        uploader.on( 'uploadComplete', function( file ) {   
           
            if(file.statusText == 'http' || file.statusText == 'abort' || file.statusText == 'server'){
            }else{
                uploader.removeFile(file);
            }
        });

        uploader.on('error',function(code){
            if(code == 'Q_TYPE_DENIED'){
                alert('请选择图片文件上传','warning');
            }
            if(code == 'F_DUPLICATE'){
                alert('此图片已上传','warning');
            }  
            /*if(code == 'Q_EXCEED_NUM_LIMIT'){
                alert('一次最多只能上传3张图片','warning');
            }  */
        })
        $('.icon-minus').on('touchend',function(e){
            var $this = $(this);
            $this.parents('li').find('.imgclip-block').hide();
            $this.parents('li').find('.icon-add').show();
            e.preventDefault();
        })
        return uploader;
    }
    module.exports = init;

});