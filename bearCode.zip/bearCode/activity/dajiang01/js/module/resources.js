define(function(require, exports,modules) {
    var v = '';
    var path = 'images/';
	var res = {
        img: {
            path: path,
            manifest: [
                {
                    src: "Preloader.gif"+v,
                    id: "img1"
                }
            ]
        }
    };
	modules.exports = res;

});
