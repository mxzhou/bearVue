define(function(require,exports,modules) {
    var Mobile = {};
    //初始化
    Mobile.init = function(){
        
        window.onload = function(){

        }
        addEvent();
    }
    function addEvent(){
        
    }
    
    modules.exports = Mobile;
    
});