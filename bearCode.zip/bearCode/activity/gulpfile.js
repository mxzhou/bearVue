var gulp     = require('gulp'),
concat       = require('gulp-concat'),
browserSync  = require('browser-sync'),
reload       = browserSync.reload,
sass         = require('gulp-sass'),
concat       = require('gulp-concat'),
sourcemaps   = require('gulp-sourcemaps'),
fileinclude  = require('gulp-file-include'),
autoprefixer = require('gulp-autoprefixer');
imagemin     = require('gulp-imagemin');
pngquant     = require('imagemin-pngquant');
spritesmith  = require('gulp.spritesmith');
proname      = 'share';
base_url     = './'+proname+'/',
dev          = true;
gulp.task('sprite', function () {
  var spriteData = gulp.src(base_url+'/development/images/icons/*.+(jpeg|jpg|png)').pipe(spritesmith({
    imgName: 'icons_sprite.png',
    cssName: 'icons_sprite.css',
    cssFormat: 'css',
    padding: 10
  }));
  return spriteData.pipe(gulp.dest(base_url+'css'));
});

gulp.task('images-min', function () {
    gulp.src(proname+'/development/images/*.+(jpeg|jpg|png)')
      .pipe(imagemin({
          progressive: true,
          use: [pngquant({quality: '65'})]
      }))      
      .pipe(gulp.dest(proname+'/images/'))     
});
gulp.task('images-sprite-min', function () {
    gulp.src(proname+'/css/*.+(jpeg|jpg|png)')
        .pipe(imagemin({
            progressive: true,
            use: [pngquant({quality: '65'})]
        }))        
        .pipe(gulp.dest(proname+'/min/'))       
});

gulp.task('concat:css', function() {   
    gulp.src([base_url+'css/style.css', base_url+'css/icons_sprite.css'])
        .pipe(concat('style.min.css'))         
        .pipe(gulp.dest(base_url+'css'))       
        .pipe(reload({stream:true}));
});
gulp.task('sass', function () {
  var type = dev ? '':'compressed';
  gulp.src(proname+'/development/sass/style.scss')
    .pipe(sourcemaps.init())
    .pipe(sass({outputStyle: type}).on('error', sass.logError))
    .pipe(autoprefixer({
        browsers: ['last 2 versions'],
        cascade: true
    }))
    .pipe(gulp.dest(proname+'/css'))
    .pipe(reload({stream:true}));
  //.pipe(sourcemaps.write())
});
gulp.task('autoPrefixer', function () {
    gulp.src(base_url+'css/'+proname+'.css')
        .pipe(autoprefixer({
            browsers: ['last 2 versions'],
            cascade: true
        }))
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest(base_url+'css'));
});
gulp.task('browser-sync', function() {
    browserSync({
        server: {
            baseDir: "./"
        }
    });
});
gulp.task('fileinclude', function() {
  gulp.src([proname+'/development/page/startup.html'])
    .pipe(fileinclude({
      prefix: '@@',
      basepath: '@file'
    }))
    .pipe(gulp.dest('./'+proname));
});
gulp.task('normal', function() {
  gulp.src([proname+'/*.html']).pipe(reload({stream:true}));
});

gulp.task('default', ['sass','images-min','sprite','concat:css','concat:css','browser-sync'], function () {
  gulp.watch([proname+'/development/sass/**/*.scss'], ['sass','concat:css','concat:css']);
  gulp.watch(['./src/sass/**/*.scss'], ['sass','concat:css','concat:css']);
  gulp.watch([proname+'/development/images/**/*.+(jpeg|jpg|png)'], ['images-min']);
  gulp.watch([proname+'/css/*.+(jpeg|jpg|png)'], ['images-sprite-min']);
  gulp.watch([proname+'/development/images/**/*.+(jpeg|jpg|png)'], ['sprite','concat:css']);
  gulp.watch([proname+'/**/*.html'], ['normal']);
});

gulp.task('sprite:text', function () {
  var spriteData = gulp.src(base_url+'_images/loading/*.+(jpeg|jpg|png)').pipe(spritesmith({
    imgName: 'text_sprite.png',
    cssName: 'text_sprite.css',
    cssFormat: 'css'
  }));
  return spriteData.pipe(gulp.dest(base_url+'css'));
});
gulp.task('images', function () {
    gulp.src('./src/_images/**/*.+(jpeg|jpg|png)')
        .pipe(imagemin({
            progressive: true,
            use: [pngquant({quality: '50'})]
        }))
        .pipe(gulp.dest('./src/images/'));
});
gulp.task('images:sprite', function () {
    var spriteData = gulp.src('./src/images/*.+(jpeg|jpg|png)').pipe(spritesmith({
      imgName: 'question_sprite.png',
      cssName: 'question_sprite.css',
      cssFormat: 'css',
      padding: 10
    }));
    return spriteData.pipe(gulp.dest('./src/images/'));
});