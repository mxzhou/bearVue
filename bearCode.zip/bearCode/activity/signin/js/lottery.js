var Lottery = (function(obj,win){
	var ApiPrefix = '/api/dzp/';
	var $time = $('.topbar');
	var kgUid = 638535348;
	var hasLottery = false;
	var LotterNum = 0,shareIf = 0,count=360*3,PrizeId = 0 ,hasLogin = false;
	obj.ajax = {
		init: function(data){
			var data = JSON.parse(data);
		    var urrstr,contentType='';
		    if(MZ.browser.isWechat){
		        data.token = MZ.utils.getToken();
		        data.kgUid = kgUid;
		        urlstr = ApiPrefix+'/lotteryInfo';
		    }else{
		        if(data.data.kgUid==0 || data.data.kgUid == undefined){
		        	$('#btnEnd').html('请先登录').show();
		            login();
		            return;
		        }
		        hasLogin = true;
		        contentType = 'application/json';
		        urlstr = '/api/dzp/lotteryInfo';
		        data = JSON.stringify(data);
		    }
			Zepto.ajax({
				url: urlstr,
				type: 'post',
				data: data,
				contentType: contentType,
				async: false,
				success: function(data){	
					if(data.status == 1){
						var info = data.data;
						LotterNum = info.lotteryNum;
						shareIf = info.shareIf;
						$('#btnPrizeList').show();
						if(LotterNum==1){
							$('.topbar').html('您今天还有<span>1</span>次抽奖机会');
							$('#btnStartLottery').show();
						}else{
							$('#btnEnd').show();
							/*if(shareIf==1){
								$('#btnEnd').show();
							}else{
								$('#btnStartLottery').hide();
								$('#btnShare').show();
							}*/							
							timeTicker(data.servertime);
						}
						var findDzpWin = info.findDzpWin;
						var str = '';
						for(var i in findDzpWin){
							var item = findDzpWin[i];
							str += '<div class="prizeimg prize'+item.id+'"><h3>'+item.winDesc+'</h3><img src="'+item.imgUrl+'"></div>';
						}
						$('#lotteymain').html(str);
					}else{
						MZ.alert({content:data.errorMessage})
					}
				},
				error: function(){
					MZ.alert({content:'网络连接错误'});
				}
			})
		},
		lottery: function(data){
		  	if(hasLottery)return;
		  	hasLottery = true;
		  	var data = JSON.parse(data);
		    var urrstr,contentType='';
		    if(MZ.browser.isWechat){
		        data.token = MZ.utils.getToken();
		        data.kgUid = kgUid;
		        urlstr = ApiPrefix+'/lotteryInfo';
		    }else{
		        if(data.data.kgUid==0 || data.data.kgUid == undefined){
		            login();
		            return;
		        }
		        contentType = 'application/json';
		        urlstr = '/api/dzp/lottery';
		        data = JSON.stringify(data);
		    }
		  	log('lottery...');			
			Zepto.ajax({
				url: urlstr,
				type: 'post',
				data: data,
				contentType: contentType,
				success: function(data){
					timeTicker(data.servertime);
					if(data.status==1){
						var info = data.data;
						if(info.success!=0){
							MZ.alert({content:info.message});
							return;
						}
						LotterNum = 0;
						var dzpWin = info.dzpWin;
						var level = dzpWin.id;
						var rotation = 0;
						if(level==1){
						  rotation = 360 + count;
						}else if(level==2){
						  rotation = 300 + count;
						}else if(level==3){
						  rotation = 240 + count;
						}else if(level==4){
						  rotation = 180 + count;
						}else if(level==5){
						  rotation = 120 + 360 + count;
						}else if(level==6){
						  rotation = 60 + 360 + count;
						}
						count += 360*4;
						$('#lotteymain').css({'-webkit-transform':'rotate('+rotation+'deg)','-webkit-transition-duration':'1.5s'});
						setTimeout(function(){
						  hasLottery = false;
						  if(dzpWin.winType==1){
						  	//红包
						  	$('#pagePrize .tips').html(dzpWin.winDesc);
						  	$('#pagePrize .money').html('￥'+dzpWin.money);
						  	$('#pagePrize .type').html(dzpWin.winDesc).css('opacity','1');
						  	$('#pagePrize').addClass('active');
						  }else if(dzpWin.winType==2){
						  	//赠币
						  	$('#pagePrize .tips').html('');
						  	$('#pagePrize .money').html(dzpWin.winDesc);
					  		$('#pagePrize .type').html('').css('opacity','0');
						  	$('#pagePrize').addClass('active');
						  }else{
						  	//实物奖品
						  	PrizeId = dzpWin.winInfoId;
						  	$('#prizeGoodsName').html(dzpWin.winDesc);
						  	$('#prizeGoodsImg img').attr('src',$('.prize'+dzpWin.id).find('img').attr('src'));
						  	$('#pagePrizeGoods').addClass('active');
						  }
						  $('#btnStartLottery').hide();
						  $('#btnEnd').show();
						  /*if(shareIf==1){
							$('#btnShare').hide();
							$('#btnEnd').show();
						  }else{
							$('#btnShare').show();
						  }*/
						},2000)
					}else{
						hasLottery = false;
						MZ.alert({content:data.errorMessage});
					}
				},
				error: function(){
					hasLottery = false;
					MZ.alert({content:'网络连接错误'});
				}
			})
		},
		lotteryList: function(data){
			var $ul = $('#prizeUlList ul');			
			if($ul.attr('hasNoMore')=='true')return;
			if($ul.attr('isLoading')=='true')return;
			$ul.attr('isLoading','true');
			var lastId = $ul.attr('lastid');
			var data = JSON.parse(data);
		    var urrstr,contentType='';
		    if(MZ.browser.isWechat){
		        data.token = MZ.utils.getToken();
		        data.kgUid = kgUid;
		        urlstr = ApiPrefix+'/lotteryInfo';
		    }else{
		        if(data.data.kgUid==0 || data.data.kgUid == undefined){
		            login();
		            return;
		        }
		        contentType = 'application/json';
		        urlstr = '/api/dzp/lotteryList';
		        data = JSON.stringify(data);
		    }  
		    var loading = new MZ.loading({content:'加载列表中'});
			Zepto.ajax({
				url: urlstr,
				type: 'post',
				data: data,
				contentType: contentType,
				success: function(data){
					loading.hide();
					$ul.attr('isLoading','false');
					if(data.status==1){
						var str = '';
						var list = data.data;
						for(var i in list){
							var item = list[i];
							if(item.winType != 0){
								str += '<li><h3>'+item.winDesc+'</h3><p>'+formateTime(item.createTime)+'</p></li>';
							}else{
								var disabled = item.ifSetAddress == 0 ? '':'disabled';
								str += '<li><a class="btn btn-blue '+disabled+' fr btnAddAddress" data-id="'+item.id+'">设置收货地址</a><h3>'+item.winDesc+'</h3><p>'+formateTime(item.createTime)+'</p></li>';
							}
						}
						if(list.length<20){
							$ul.attr('hasNoMore','true');
						}
						if(list.length!=0){
							$ul.attr('lastid',list[list.length-1].id);
						}
						if(lastId==0 && list.length == 0){
							str = '<li><div style="line-height:80px;text-align:center;">暂无中奖记录</div></li>';
						}

						$ul.append(str);
					}else{
						MZ.alert({content:data.errorMessage});
					}
				},
				error: function(){
					loading.hide();
					$ul.attr('isLoading','false');
				}
			})
		},
		lotteryShare: function(data){
			var data = JSON.parse(data);
		    var urrstr,contentType='';
		    if(MZ.browser.isWechat){
		        data.token = MZ.utils.getToken();
		        data.kgUid = kgUid;
		        urlstr = ApiPrefix+'/Share';
		    }else{
		        if(data.data.kgUid==0 || data.data.kgUid == undefined){
		            login();
		            return;
		        }
		        contentType = 'application/json';
		        urlstr = '/api/dzp/Share';
		        data = JSON.stringify(data);
		    }
		    var loading = new MZ.loading({content:'请求数据中...'});
			Zepto.ajax({
				url: urlstr,
				type: 'post',
				data: data,
				contentType: contentType,
				success: function(data){
					loading.hide();
					if(data.status==1){
						if(data.data.success==0){
							shareIf = 1;
							LotterNum = 1;
							$('#btnStartLottery').show();
							$('#btnShare').hide();
						}else{
							MZ.alert({content:data.data.message});
						}
					}else{
						MZ.alert({content:data.errorMessage});
					}
				},
				error: function(){
					loading.hide();
					MZ.alert({content:'网络连接错误'});
				}
			})
		},
		saveAddress: function(data){
			var data = JSON.parse(data);
		    var urrstr,contentType='';
		    var username = $('#username').val().replace(/\s/g,'').replace(/<*>*/g,'');
			var address = $('#address').val().replace(/\s/g,'').replace(/<*>*/g,'');
			var phone = $('#phone').val().replace(/\s/g,'').replace(/<*>*/g,'');
		    if(MZ.browser.isWechat){
		        data.token = MZ.utils.getToken();
		        data.kgUid = kgUid;
		        urlstr = ApiPrefix+'/submitAddress';
		    }else{
		        if(data.data.kgUid==0 || data.data.kgUid == undefined){
		            login();
		            return;
		        }
				data.data.receiveAddress = address;
				data.data.receiveMan = username;
				data.data.winInfoId = PrizeId;
				data.data.receivePhone = phone;
		        contentType = 'application/json';
		        urlstr = '/api/dzp/submitAddress';
		        data = JSON.stringify(data);
		    }
		    var loading = new MZ.loading({content:'请求数据中...'});
			Zepto.ajax({
				url: urlstr,
				type: 'post',
				data: data,
				contentType: contentType,
				success: function(data){
					loading.hide();
					if(data.status==1){
						if(data.data){
							MZ.alert({content:'提交成功'});
							$('#pageInfo').removeClass('active');
							$('#pagePrizeGoods').removeClass('active');
							$('.btnAddAddress').each(function(){
								var $this = $(this);
								if($this.attr('data-id')==PrizeId){
									$this.addClass('disabled');
								}
							})
						}else{
							MZ.alert({content:data.errorMessage});
						}
					}else{
						MZ.alert({content:data.errorMessage});
					}
				},
				error: function(){
					loading.hide();
					MZ.alert({content:'网络连接错误'});
				}
			})
		}
	}
	obj.init = function(){
		getRSA('Lottery.ajax.init',JSON.stringify({'key':'1'}));
		//getRSA('Lottery.ajax.lotteryList',JSON.stringify({'lastId':'0'}));
		obj.addEvent();
	}
	obj.addEvent = function(){
		$('#btnEnd').on('touchend',function(e){
			e.preventDefault();
			if($(this).text()=='请先登录'){
				login();
			}
		})
		//关闭安卓分享层
		$('.share-btn').on('click touchend',function(e){
			e.preventDefault();
			var $this = $(this);
			$('.share-btn').hide();
		})
		//放入账户
		$('#btnGet').on('click touchend',function(e){
			e.preventDefault();
			var $this = $(this);
			$this.parents('.modal').removeClass('active');
		})
		//设置地址按钮
		$(document).delegate('.btnAddAddress','click',function(){
			var $this = $(this);
			if($this.hasClass('disabled'))return;
			PrizeId = $this.attr('data-id');
		})
		//提交收货地址
		$('#btnSubmit').on('click',function(e){
			e.preventDefault();
			var username = $('#username').val().replace(/\s/g,'').replace(/<*>*/g,'');
			var address = $('#address').val().replace(/\s/g,'').replace(/<*>*/g,'');
			var phone = $('#phone').val().replace(/\s/g,'').replace(/<*>*/g,'');
			if(username == ''){
				MZ.alert({content:'请输入收货人姓名'});
				return;
			}
			if(phone == ''){
				MZ.alert({content:'请输入收货人联系电话'});
				return;
			}
			if(!/^1\d{10}$/.test(phone)){
				MZ.alert({content:'请输入正确的手机号码'});
	            return;
	        }
	        if(address == ''){
				MZ.alert({content:'请输入详细收货地址'});
				return;
			}
			MZ.confirm({content:'确认信息无误吗？',callback:function(){
				var data = {
					'receiveAddress':address,
					'receiveMan': username,
					'winInfoId': PrizeId,
					'receivePhone':phone
				}
				//document.write(JSON.stringify(data))
				getRSA('Lottery.ajax.saveAddress',JSON.stringify(data));
			}})
			
		})
		//填写地址
		$('#btnForInfo').on('touchend',function(e){
			e.preventDefault();
			$('#pageInfo').addClass('active');
		})
		//下拉加载更多中奖纪录
		var $prizeList = $('.prize-list');
		var $ul = $('#prizeUlList ul');
		$prizeList.on('scroll touchmove',function(){
		    if($prizeList.scrollTop() + $prizeList.height() + 50 > $('#prizeUlList').height()){
		    	var lastId = $ul.attr('lastid')==null ? 0 : $ul.attr('lastid');
		        getRSA('Lottery.ajax.lotteryList',JSON.stringify({'lastId':lastId}));
		    }
		})
		$('.btnClose').on('click touchend',function(e){
		  e.preventDefault();
		  $(this).parents('.modal').removeClass('active');
		})
		//中奖纪录
		$('#btnPrizeList').on('click touchend',function(e){
		  e.preventDefault();
		  var $ul = $('#prizeUlList ul');
		  $ul.html('');
		  $ul.attr('hasNoMore','false');
		  $ul.attr('isLoading','false');
		  $ul.attr('lastid',0)
		  getRSA('Lottery.ajax.lotteryList',JSON.stringify({'lastId':'0'}));
		  $('#pageList').addClass('active');
		})
		var baseUrl="http://1.kugou.com";
		var shareTitle = '1元大牌抢不停',
			shareContent = '胖熊一元买，一元开启幸运之门，iPhone 6S、小米平衡车、20g金条 ，尽在胖熊一元买。',
			shareUrl = baseUrl+"/shareLottery/index.html",
			imgUrl = baseUrl+"/api/static/images/share_icon.jpg",
			wbimgUrl = baseUrl+"/api/static/images/banner_mobile.jpg";
		//分享获取抽奖机会
		$('#btnShare').on('click touchend',function(e){
		  e.preventDefault();
		  if(MZ.browser.isIos){
            var json={
        			url:shareUrl,
        			title:shareTitle,
        			content:shareContent,
        			imageURLString:imgUrl,
        			wbUrl:wbimgUrl
        	}
        	document.location = "KugouBuy:Share:"+JSON.stringify(json);
          }else{
          	  $('.share-btn').show();
          }
		})
		//安卓分享
		$('.btnShare').on('click touchend',function(e){
			e.preventDefault();
			var baseUrl="http://1.kugou.com";
			var type = $(this).attr('data-type');
    		window.clickListener.Sharefirend(type,shareUrl,shareTitle,shareContent, imgUrl, wbimgUrl);
		})
		//设置收货地址
		$('#prizeUlList').delegate('.btn','click',function(e){
		  e.preventDefault();
		  var $this = $(this);
		  if(!$this.hasClass('disabled')){
		    $('#pageInfo').addClass('active');
		  }
		})
		$('#btnDraw').add('#btnStartLottery').on('click',function(e){
		  e.preventDefault();
		  if(!hasLogin){
		  	login();
		  	return;
		  }
		  if(LotterNum==0){
		  	MZ.alert({content:"您今天抽奖机会已用完，明天再来吧~"});
		  	return;
		  }
		  /*if(LotterNum==0 && shareIf == 1){
		  	MZ.alert({content:"您今天抽奖机会已用完，明天再来吧~"});
		  	return;
		  }
		  if(LotterNum==0 && shareIf == 0){
		  	MZ.alert({content:"请先分享获取1次抽奖机会~"});
		  	return;
		  }*/
		  getRSA('Lottery.ajax.lottery',JSON.stringify({'KEY':'1'}));
		})
	}
	
	function timeTicker(stime){
	   var serverTime = stime,
	      localTimeStart = new Date().getTime();
	  var tomorrow = new Date(serverTime+24*60*60*1000);
	  var targetTime = new Date(tomorrow.getFullYear()+"/"+(tomorrow.getMonth()+1)+"/"+tomorrow.getDate()+' 00:00:00').getTime();
	  var time = targetTime - serverTime;
	  countdown(time);
	  if(time>0){
	      timer = setInterval(function(){
	        var t = time - (new Date().getTime()-localTimeStart);
	        if(t>0){
	          countdown(t);
	        }else{
	          clearInterval(timer);
	          $time.html('您今天还有<span>1</span>次抽奖机会');
	        }
	      },500)
	  }else{
	    $('.title').html('土豪榜已揭晓');
	  }
	  function countdown(t){
	    var h = 60*60*1000,
	        m = 60*1000,
	        s = 1000;
	    var H = parseInt(t/h),
	        M = parseInt((t-H*h)/m),
	        S = parseInt((t-H*h-M*m)/s),
	        HS = parseInt((t-H*h-M*m-S*s)/10);
	        if(t<=0){
	        	location.href = '';
	        	return;
	        }
	        $time.html('<span>'+H+"</span>小时<span>"+intNumber(M)+"</span>分<span>"+intNumber(S)+"</span>秒后可再参与");
	  }
	}
	function intNumber(n){
	  return n<10?'0'+n:n;
	}
	function formateTime(dt){
	 var dt = new Date(dt);
      return dt.getFullYear()+"."+(dt.getMonth()+1)+"."+dt.getDate()+" "+intNumber(dt.getHours())+":"+intNumber(dt.getMinutes())+":"+intNumber(dt.getSeconds());
	}
	return obj;
})(Lottery || {},window)
Lottery.init();
function setupWebViewJavascriptBridge(callback) {
    if (window.WebViewJavascriptBridge) { return callback(WebViewJavascriptBridge); }
    if (window.WVJBCallbacks) { return window.WVJBCallbacks.push(callback); }
    window.WVJBCallbacks = [callback];
    var WVJBIframe = document.createElement('iframe');
    WVJBIframe.style.display = 'none';
    WVJBIframe.src = 'wvjbscheme://__BRIDGE_LOADED__';
    document.documentElement.appendChild(WVJBIframe);
    setTimeout(function() { document.documentElement.removeChild(WVJBIframe) }, 0)
}
setupWebViewJavascriptBridge(function(bridge) {
    bridge.registerHandler('px_webSideHandler', function(data, responseCallback) {
    	if(data.iOSSideMsgType=="iOSSideMsgTypeShareSuccess"){
    		//分享成功
    		getRSA('Lottery.ajax.lotteryShare',JSON.stringify({'key':'1'}));
    	}
	})
})
function getRSA(ajaxFunc,params){
    if(MZ.browser.isWechat){
        if(ajaxFunc=='init'){
            Lottery.ajax.init(params);
        }
    }else{
        if(navigator.userAgent.match(/(iPad|iPhone|iPod)/g)){
            setupWebViewJavascriptBridge(function(bridge) {
                bridge.callHandler('px_iosSideHandler', params , function responseCallback(Data) {
                    if(ajaxFunc=='Lottery.ajax.init'){
                        Lottery.ajax.init(Data);
                    }
                    if(ajaxFunc=='Lottery.ajax.lotteryList'){
                        Lottery.ajax.lotteryList(Data);
                    }
                    if(ajaxFunc=='Lottery.ajax.lottery'){
                        Lottery.ajax.lottery(Data);
                    }
                    if(ajaxFunc=='Lottery.ajax.lotteryShare'){
                        Lottery.ajax.lotteryShare(Data);
                    }
                    if(ajaxFunc=='Lottery.ajax.saveAddress'){
                        Lottery.ajax.saveAddress(Data);
                    }
                })
            })
        }else{
            window.clickListener.fanxinrsa(ajaxFunc,params);
        }
    }
}
function shareSuccess(){
	getRSA('Lottery.ajax.lotteryShare',JSON.stringify({'key':'1'}));
}
function login(){
	MZ.alert({content:'您还未登录，请先登录',callback:function(){
        if(MZ.browser.isIos){
            document.location = "KugouBuy:Login";
        }else{
            window.clickListener.GoRegister();
        }
    }});
}