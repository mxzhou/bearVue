  (function(win) {
      var psWidth = 750;
      var screenWidth =  parseInt(window.screen.width), 
          screenHeight =  parseInt(window.screen.height);
      var phoneScale = screenWidth/psWidth;
      var ua = navigator.userAgent;
      if (/Android (\d+\.\d+)/.test(ua)){
          var version = parseFloat(RegExp.$1);
          if(version>2.3){
              document.write('<meta name="viewport" content="width='+psWidth/2+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
          }else{
              document.write('<meta name="viewport" content="width='+psWidth/2+', target-densitydpi=device-dpi">');
          }
          // 其他系统
      } else {
          document.write('<meta name="viewport" content="width='+psWidth/2+', user-scalable=no, target-densitydpi=device-dpi">');
      };
      var doc = win.document;
      var docEl = doc.documentElement;
      var tid;
      function refreshRem() {
          var width = docEl.getBoundingClientRect().width,
              height = docEl.getBoundingClientRect().height;
          if (width > psWidth) { // 最大宽度
              width = psWidth;
          }
          var rem = width / 10; // 将屏幕宽度分成10份， 1份为1rem
          docEl.style.fontSize = rem + 'px';      
          var isMobile = /AppleWebKit.*Mobile/i.test(navigator.userAgent) || (/MIDP|SymbianOS|NOKIA|SAMSUNG|LG|NEC|TCL|Alcatel|BIRD|DBTEL|Dopod|PHILIPS|HAIER|LENOVO|MOT-|Nokia|SonyEricsson|SIE-|Amoi|ZTE/.test(navigator.userAgent));   
          if(screenWidth/screenHeight>320/500 && isMobile){  
            docEl.style.fontSize = psWidth/20*(320/500)/(screenWidth/screenHeight)+'px';
          }
      }
      win.addEventListener('resize', function() {
          clearTimeout(tid);
          tid = setTimeout(refreshRem, 300);
      }, false);
      win.addEventListener('pageshow', function(e) {
          if (e.persisted) {
              clearTimeout(tid);
              tid = setTimeout(refreshRem, 300);
          }
      }, false);
      refreshRem();
  })(window);