seajs.config({
  base: "./js/",
  alias: {
  },
  map: [
    [ /^(.*\/js\/.*\.(?:css|js))(?:.*)$/i, '$1?201602142' ]
  ]
})