define(function(require,exports,modules) {
    var App = {};
    //初始化
    App.init = function(){
        
        window.onload = function(){

        }
        addEvent();
    }
    function addEvent(){
        
    }
    
    modules.exports = App;
    
});