define(function(require,exports,modules) {
    var Mobile = {};
    //初始化
    Mobile.init = function(){
        
        window.onload = function(){

        }
        addEvent();
    }
    function addEvent(){
        $('#btnSavePic').on('click tuochend',function(e){
            e.preventDefault();
            var data = getDataUrl('mycode');
            location.href = data;
        })
    }
    canvasImg();
    var loading = new MZ.loading({content:'初始化中...'});
    function canvasImg(){
      function drawBg(bg){
          var mycv = document.getElementById("mycode");  
          var myctx = mycv.getContext("2d");
          myctx.drawImage(bg, 0, 0);
          //画入二维码
          drawCode();
      }
      load();
      function load(){
          var bg = new Image();  
          //bg.src = "http://p1.fx.kgimg.com/v2/kmh_1_img/T1Z5_4B7hs1RCvBVdK.jpeg"; 
          bg.src = "images/bg_myqrcard.jpg"; 
          if(bg.complete){
             drawbg(bg);
          }else{
             bg.onload = function(){
                drawBg(bg);
             };
             bg.onerror = function(){
               window.alert('加载失败，请重试');
             };
          };   
      }
    }
    //画入用户头像等信息
    function drawUserData(){
        var userPic = new Image();  
        userPic.src = "https://img.alicdn.com/tps/TB1t3ITJXXXXXXAXpXXXXXXXXXX-200-200.jpg_120x120.jpg?v="+new Date().getTime(); 
        //userPic.setAttribute('crossOrigin', 'Anonymous');
        if(userPic.complete){
            drawUserPic(userPic);
        }else{
            userPic.onload = function(){
                drawUserPic(userPic);
            };
            userPic.onerror = function(){
               window.alert('加载失败，请重试');
            };
        };
        function drawUserPic(userPic){
            var mycv = document.getElementById("mycode");  
            var myctx = mycv.getContext("2d");
            myctx.save();
            roundedImage(245,150,140,140,83);
            myctx.clip();
            myctx.drawImage(userPic,245,150,140,140);
            myctx.restore();
            myctx.font="30px Arial";
            myctx.textAlign="center";
            myctx.fillText("砸挂卖铁来夺宝",315,330);
            return;
           var pattern = myctx.createPattern(userPic, "no-repeat");
           myctx.arc(245, 150, Math.max(userPic.width, userPic.height) / 2, 0, 2 * Math.PI);
           myctx.drawImage(userPic, 0, 0);
           myctx.fillStyle = pattern;
           myctx.fill(); 
        }
    }
    function roundedImage(x,y,width,height,radius){
      var mycv = document.getElementById("mycode");  
      var ctx = mycv.getContext("2d");
      ctx.beginPath();
      ctx.moveTo(x + radius, y);
      ctx.lineTo(x + width - radius, y);
      ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
      ctx.lineTo(x + width, y + height - radius);
      ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
      ctx.lineTo(x + radius, y + height);
      ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
      ctx.lineTo(x, y + radius);
      ctx.quadraticCurveTo(x, y, x + radius, y);
      ctx.closePath();
    }
    //生成二维码并画入合成图
    function drawCode(){
        var qrnode = new AraleQRCode({
            render: 'canvas',
            correctLevel: 0,
            text: 'http://www.alipay.com/',
            size: 170,
            background: '#FFF',
            foreground: '#f04a56',
            pdground: '#f04a56',
            imageSize : 100
        });
        $('#qrcode').append(qrnode);
        $('#qrcode canvas').attr('id','codeImg');
        setTimeout(function(){
            var codecvs = document.getElementById('codeImg');  
            var imgData = codecvs.toDataURL('image/jpg');
            var codeImg = new Image();  
            codeImg.src = imgData; 
            codeImg.onload = function(){
               var mycode = document.getElementById("mycode");  
               var mycode = mycode.getContext("2d");
               mycode.drawImage(codeImg, 145, 412,340,340); 
               loading.hide();
               drawUserData();
            };
        },100)
    }
    function getDataUrl(id){
        var mycv = document.getElementById(id);  
        var imgData = mycv.toDataURL('image/jpg');
        return imgData;
    }
    modules.exports = Mobile;
    
});