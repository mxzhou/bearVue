define(function(require,exports,modules) {
    var Mobile = {};
    //初始化
    Mobile.init = function(){
        
        window.onload = function(){

        }
        addEvent();
    }
    function addEvent(){
        
    }

    renderMoney();
    function renderMoney(){
        var $moneyTotal = $('#moneyTotal'), 
            $moneyLeave = $('#moneyLeave');
        var moneyTotal = parseFloat($moneyTotal.attr('data-number')),
            moneyLeave = parseFloat($moneyLeave.attr('data-number'));
        var num1 = moneyTotal/100,money1=0;
        var num2 = moneyLeave/100,money2=0;
        var timer = setInterval(function(){
            money1 = money1 + num1;
            money2 = money2 + num2;
            if(money1>=moneyTotal){
                money1 = moneyTotal;
                clearInterval(timer);
                $moneyTotal.html(moneyTotal.toFixed(2));
                $moneyLeave.html(moneyLeave.toFixed(2));
                return;
            }
            $moneyTotal.html(money1.toFixed(2));
            $moneyLeave.html(money2.toFixed(2));
        },10);
    }
    modules.exports = Mobile;
    
});