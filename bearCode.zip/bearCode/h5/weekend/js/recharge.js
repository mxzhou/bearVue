var CanPay = false;//安卓是否可以传支付金额参数
var activityIn = false;//活动是否已开始
var Recharge = (function(obj,win){
	var ApiPrefix = 'http://'+document.domain;
	var $btnRecharge = $('#btnRecharge'),
		$topbar = $('.topbar'),
		$timebar = $('.timebar');
	var hasLogin = false,rechargeTime,hasActive=false,ServerTime = new Date().getTime(),hasGet=false,isLastDay=false;
	var win = window,
		doc = window.document;
	obj.ajax = {		
		init: function(data){
			var data = JSON.parse(data);
			version = data.version;
		    var urrstr,contentType='';
		    if(MZ.browser.isWechat){
		    }else{
		        if(data.data.kgUid==0 || data.data.kgUid == undefined){
		            login();
		            timeTicker(new Date().getTime());
		            return;
		        }
		        contentType = 'application/json';
		        urlstr = ApiPrefix+'/api/rechargeRedEnvelope/weekendReceive';
		        data = JSON.stringify(data);
		    }
			Zepto.ajax({
				url: urlstr,
				type: 'post',
				data: data,
				contentType: contentType,
				async: false,
				cache: false,
				success: function(data){
					timeTicker(data.servertime);
					if(data.status == 1){
						var info = data.data;
						hasActive = info.flag;
						if(hasActive){
							$('.footer-btn').show();
						}else{
							$('.footer-btn').hide();
						}
						if(info.receive==1){
							$('#btnGet').addClass('disabled').html('已领取资格');
						}
					}else{
						MZ.alert({content:data.errorMessage})
					}
				},
				error: function(){
					MZ.alert({content:'网络连接错误'});
				}
			})
		}, 
		eligibility: function(data){
			var data = JSON.parse(data);
		    var urrstr,contentType='';
		    if(MZ.browser.isWechat){
		    }else{
		        if(data.data.kgUid==0 || data.data.kgUid == undefined){
		            login();
		            return;
		        }
		        contentType = 'application/json';
		        urlstr = ApiPrefix+'/api/rechargeRedEnvelope/eligibility';
		        data = JSON.stringify(data);
		    }
		    var loading = new MZ.loading({content:'请求中...'});
			Zepto.ajax({
				url: urlstr,
				type: 'post',
				data: data,
				contentType: contentType,
				cache: false,
				success: function(data){
					loading.hide();	
					if(data.status == 1){
						$('#btnGet').addClass('disabled').html('已领取资格');
					}else{
						MZ.alert({content:data.errorMessage})
					}
				},
				error: function(){
					loading.hide();
					MZ.alert({content:'网络连接错误'});
				}
			})
		}
	}
	obj.init = function(){
		//MZ.showLuckyBag('<li><span class="fl"><i>￥</i>23334</span><h3>123</h3><p>4353</p></li>',3);
		obj.addEvent();
		getRSA('Recharge.ajax.init',JSON.stringify({'key':'1'}));
	}
	obj.addEvent = function(){
		$('#btnRule').on('click touchend',function(e){
			e.preventDefault();
			$('#pageRule').addClass('active');
		})
		$('#btnCloseRule').on('click touchend',function(e){
			e.preventDefault();
			$('#pageRule').removeClass('active');
		})
		//充值1000
		$('#btn1').on('click ',function(e){
			e.preventDefault();
			recharge(1000);
		})
		//充值500
		$('#btn2').on('click ',function(e){
			e.preventDefault();
			recharge(500);
		})
		//充值200
		$('#btn3').on('click ',function(e){
			e.preventDefault();
			recharge(200);
		})
		//充值50
		$('#btn4').on('click ',function(e){
			e.preventDefault();
			recharge(50);
		})
		$('#btnGet').on('click touchend',function(e){
			e.preventDefault();
			if($(this).text()=='领取资格'){
				getRSA('Recharge.ajax.eligibility',JSON.stringify({'key':'1'}));
			}
		})
		function recharge(money){
			if(activityIn){
				if(MZ.browser.isAndroid){
				  	if(CanPay){
				    	window.clickListener.GoRecharge(money);
				  	}else{
				    	window.clickListener.GoRecharge();
				  	}
				  }else if(MZ.browser.isIos){
				    document.location = "KugouBuy:Recharge:"+JSON.stringify({amount:money});
				  }
			}else{
				MZ.confirm({content:'<div style="padding:.4rem 0;">活动还未开始，是否继续充值？</div>',hideTitle:true,textOk:'充值',callback:function(){
					if(MZ.browser.isAndroid){
					  	if(CanPay){
					    	window.clickListener.GoRecharge(money);
					  	}else{
					    	window.clickListener.GoRecharge();
					  	}
					  }else if(MZ.browser.isIos){
					    document.location = "KugouBuy:Recharge:"+JSON.stringify({amount:money});
					  }
				}})
			}
		}
	}
	function timeTicker(stime){
	  var serverTime = stime,
	      localTimeStart = new Date().getTime();
	  //var serverTime = new Date('2016/7/29 23:59:50').getTime();
	  //var serverTime = new Date('2016/7/31 23:59:55').getTime();
	  var dayNow = new Date(serverTime).getDay();	  
	  if(dayNow!=0 && dayNow!=6){
	  	//非周末
	  	var targetTime = new Date(serverTime + (6-dayNow)*24*60*60*1000);
	  	$timebar.html('<p style="font-weight:bold;text-align:center;color:#991e29;font-size:.4rem;">活动尚未开始</p>');
	  }else{
	  	//周末
	  	activityIn = true;
	  	$topbar.html("活动进行中");
	  	$('.icon-end').hide();
	  	if(dayNow==0){
	  		var targetTime = new Date(serverTime + 24*60*60*1000);
	  	}
	  	if(dayNow == 6){
	  		var targetTime = new Date(serverTime + 2*24*60*60*1000);
	  	}
	  }
	  log(targetTime.getFullYear()+"/"+(targetTime.getMonth()+1)+"/"+targetTime.getDate()+' 00:00:00')
	  var target = new Date(targetTime.getFullYear()+"/"+(targetTime.getMonth()+1)+"/"+targetTime.getDate()+' 00:00:00').getTime()
	  var time = target - serverTime;
	  countdown(time);
	  if(time>0){
	      timer = setInterval(function(){
	        var t = time - (new Date().getTime()-localTimeStart);
	        if(t>0){
	          countdown(t);
	        }else{
	          clearInterval(timer);
	        }
	      },500)
	  }else{
	   
	  }
	  function countdown(t){
	    var h = 60*60*1000,
	    	d = 24*60*60*1000,
	        m = 60*1000,
	        s = 1000;
	    var D = parseInt(t/d),
	   		H = parseInt((t-D*d)/h),
	        M = parseInt((t-D*d-H*h)/m),
	        S = parseInt((t-D*d-H*h-M*m)/s),
	        HS = parseInt((t-D*d-H*h-M*m-S*s)/10);
	        if(t<=1000){
	        	location.href = '';
	        	return;
	        }
	        if(activityIn){
	        	H = D*24+H;
				$timebar.html('<span>'+intNumber(H)+"</span>小时<span>"+intNumber(M)+"</span>分<span>"+intNumber(S)+"</span>秒");

	        }else{
	        	if(D==0){
					$topbar.html('距离活动开始还有：'+intNumber(H)+"小时"+intNumber(M)+"分"+intNumber(S)+"秒");
	        	}else{
					$topbar.html('距离活动开始还有：'+D+'天'+H+"小时"+intNumber(M)+"分"+intNumber(S)+"秒");
	        	}
	        }
	  }
	}
	function intNumber(n){
	  return n<10?'0'+n:n;
	}
	function formateTime(dt){
	 var dt = new Date(dt);
      return dt.getFullYear()+"."+(dt.getMonth()+1)+"."+dt.getDate()+" "+intNumber(dt.getHours())+":"+intNumber(dt.getMinutes())+":"+intNumber(dt.getSeconds());
	}
	function formateDate(dt){
	 var dt = new Date(dt);
      return dt.getFullYear()+""+(dt.getMonth()+1)+""+dt.getDate();
	}
	return obj;
})(Recharge || {},window)
Recharge.init();
function getRSA(ajaxFunc,params){
    if(MZ.browser.isWechat){       
    }else{
        if(navigator.userAgent.match(/(iPad|iPhone|iPod)/g)){
            setupWebViewJavascriptBridge(function(bridge) {
                bridge.callHandler('px_iosSideHandler', params , function responseCallback(Data) {
                    if(ajaxFunc=='Recharge.ajax.init'){
                        Recharge.ajax.init(Data);
                    }
                    if(ajaxFunc=='Recharge.ajax.eligibility'){
                        Recharge.ajax.eligibility(Data);
                    }
                    
                })
            })
        }else{
            window.clickListener.fanxinrsa(ajaxFunc,params);
        }
    }
}
function login(){
	setTimeout(function(){
		MZ.alert({content:'您还未登录，请先登录',callback:function(){
	        if(MZ.browser.isIos){
	            document.location = "KugouBuy:Login";
	        }else{
	            window.clickListener.GoRegister();
	        }
	    }});
	},300)
}