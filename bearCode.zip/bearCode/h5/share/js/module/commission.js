var ApiPrefix = 'http://'+document.domain;
var win = window,
    doc = window.document;
define(function(require,exports,modules) {
    var App = {};
    //初始化
    App.init = function(){
        win.onload = function(){

        }
        getRSA('ajaxGetList',JSON.stringify({'key':'1'}));
        addEvent();
    }
    function addEvent(){
        //下拉加载更多中奖纪录
        var $list = $('#list');
        $(document).on('scroll touchmove',function(){
            if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
                getRSA('ajaxGetList',JSON.stringify({'key':'1'}));
            }
        });
    }
    win.ajaxGetList = function(data){
        var $ul = $('#list');
            if($ul.attr('hasNoMore')=='true')return;
            if($ul.attr('isLoading')=='true')return;
            $ul.attr('isLoading','true');
            var lastId = $ul.attr('lastid');
            var PaseSize = 20;

            var data = JSON.parse(data);
            var urrstr,contentType='';
            if(MZ.browser.isWechat){
            }else{
                if(data.data.kgUid==0 || data.data.kgUid == undefined){
                    MZ.app.login();
                    return;
                }
                hasLogin = true;
                contentType = 'application/json';
                urlstr = ApiPrefix+'/api/users/share/details';
                data.data.pageSize = PaseSize;
                data.data.lastId = lastId;
                data = JSON.stringify(data);
            }
            Zepto.ajax({
                url: urlstr,
                type: 'post',
                data: data,
                contentType: contentType,
                async: false,
                cache: false,
                success: function(data){    
                    $ul.attr('isLoading','false');
                    if(typeof data == 'string'){
                        data = JSON.parse(data);
                    }
                    /*data = {
                      "status" : 1,
                      "errorCode" : 0,
                      "errorMessage" : null,
                      "servertime" : 1467792965017,
                      "data" : [ {
                        "id":121,
                         "money" : 80.00,
                        "friendNickname" : "江南的生d活d",
                        "actionTime" : new Date().getTime()
                      } ]
                    }*/
                    
                    if(data.status == 1){
                        var str = '';
                        var list = data.data;
                        if(list.length==0){
                            $ul.html('<div class="center nodata">暂无佣金明细</div>');
                            return;
                        }

                        for(var i in list){
                            var item = list[i];
                            var moneyStr,typeStr;
                            if(item.money<0){
                                typeStr = '提现到余额';
                                moneyStr = item.money;
                            }else{
                                //typeStr = item.nickname+' 消费';
                                typeStr = '获得佣金';
                                moneyStr = '+'+item.money;
                            }
                            str += '<li class="item">'+
                                    '    <span class="fr">'+moneyStr+'元</span>'+
                                    '    <h3>'+typeStr+'</h3>'+
                                    '    <p>'+MZ.utils.formateTime(item.actionTime)+'</p>'+
                                    '</li>';
                        }
                        if(list.length!=0){
                            $ul.attr('lastid',list[list.length-1].id);
                        }
                        if(list.length<PaseSize){
                            $ul.attr('hasNoMore','true');
                            if(list.length == 0 && lastId == 0){
                                $ul.html('<div class="center" style="line-height:50px;color:#666;font-size:16px;">暂无数据</div>');
                            }else{
                                $ul.append(str);
                            }
                        }else{
                            $ul.append(str);
                        }
                    }else{
                        MZ.alert({content:data.errorMessage})
                    }
                },
                error: function(){
                    $ul.attr('isLoading','false');
                    MZ.alert({content:'网络连接错误'});
                }
            })
    }
    function getRSA(ajaxFunc,params){
        if(MZ.browser.isWechat){       
        }else{
            if(navigator.userAgent.match(/(iPad|iPhone|iPod)/g)){
                setupWebViewJavascriptBridge(function(bridge) {

                    bridge.callHandler('px_iosSideHandler', params , function responseCallback(Data) {
                        if(ajaxFunc=='ajaxGetList'){
                            ajaxGetList(Data);
                        }
                    })
                })
            }else{
                window.clickListener.fanxinrsa(ajaxFunc,params);
            }
        }
    }

    modules.exports = App;
    
});