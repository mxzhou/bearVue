var ApiPrefix = 'http://'+document.domain,kgUid=0,inviteCode=0,hasLogin=false,Master={};
define(function(require,exports,modules) {
    var App = {};
    //初始化
    App.init = function(){
        
        window.onload = function(){
        }
        getRSA('ajaxInit',JSON.stringify({'key':'1'}));
        addEvent();
    }
    function addEvent(){
        //分享
        $('#btnShare').on('click',function(e){
            e.preventDefault();
            if(!hasLogin){
                MZ.app.login();
                return;
            }
            var shareTitle = '送你1毛钱拿下iPhone的机会',
                shareContent = '推荐一个有趣好玩的购物平台，所有商品正品包邮。1块钱买到iPhone6S不是梦',
                shareUrl = ApiPrefix+"/api/h5/share/share-user.html?code="+inviteCode,
                imgUrl = ApiPrefix+"/api/h5/src/images/shareicon.jpg",
                wbimgUrl = ApiPrefix+"/api/h5/src/images/shareicon.jpg";
            var json={
                url:shareUrl,
                title:shareTitle,
                content:shareContent,
                imageURLString:imgUrl,
                wbUrl:wbimgUrl
            }
            MZ.app.share(json);
        })
        //拷贝邀请码
        $('#btnCopyCode').on('click',function(e){
            var text  = $('#inviteCode').html();
            if(!hasLogin){
                MZ.app.login();
                return;
            }
            if(text=='')return;
            MZ.app.copyText(text,'邀请码复制成功');
        })
        //拷贝
        $('#btnCopyUrl').on('click',function(e){
            var text  = $('#myLink').attr('src');
            if(!hasLogin){
                MZ.app.login();
                return;
            }
            if(text!=''){
                MZ.app.copyText(text,'分享链接复制成功');
            }
        })
        //提现
        $('#btnExchange').on('click',function(e){
            if(!hasLogin){
                MZ.app.login();
                return;
            }
            var moneyLeave = $('#moneyLeave').attr('data-number');
            if(moneyLeave<1){
                MZ.alert({content:'<div style="padding:20px 0 15px;">余额至少1元才可提现</div>',footerText:'知道了'});
                return;
            }
            MZ.confirm({content:'确定将'+moneyLeave+'元提现到余额？',callback:function(){
                getRSA('ajaxWithDrawal',{'key':1});
            }})
        })
        //认领师傅
        $('#btnFriend').on('click touchend',function(e){
            e.preventDefault();
            if(!hasLogin){
                MZ.app.login();
                return;
            }
            var $this = $(this);
            if($this.text()=='认领师傅'){
                $('#infoForm').show().css('top',0);
                $('#infoForm .weui_dialog').addClass('active');
            }else{
                MZ.alert({content:'<div style="padding:0 0 10px;"><h3 style="margin-bottom:20px;">您的师傅是</h3>'+Master.masterNickname+'<br>（ ID:'+Master.masterKgUid+' ）</div>',footerText:'知道了'});
            }
        })
        $('#infoForm .jsCancle').on('click touchend',function(e){
            e.preventDefault();
            $('#infoForm').hide();
            $('#infoForm .weui_dialog').removeClass('active');
        })
        //检查认领
        $('#infoForm .jsOk').on('click',function(e){
            e.preventDefault();
            var code = $('#inputCode').val().replace(/\s/gi,'');
            if(code==''){
                $('.error').html('请输入邀请码');
                return;
            }
            if(code==inviteCode){
                $('.error').html('您不能输入自己的邀请码');
                return;
            }
            getRSA('ajaxCheckfriend',{'invitationCode':code});
        })
        //过滤输入非数字内容
        $('#inputCode').on('keyup blur',function(){
            var $this = $(this);
            var val = $this.val().replace(/\D/g,'');
            $this.val(val);
        })
    }
    
    
            
    modules.exports = App;
    
});
function getRSA(ajaxFunc,params){
    if(MZ.browser.isWechat){       
    }else{
        if(navigator.userAgent.match(/(iPad|iPhone|iPod)/g)){
            setupWebViewJavascriptBridge(function(bridge) {
                bridge.callHandler('px_iosSideHandler', params , function responseCallback(Data) {
                    if(ajaxFunc=='ajaxInit'){
                        ajaxInit(Data);
                    }
                    if(ajaxFunc=='ajaxMakeFriend'){
                        ajaxMakeFriend(Data);
                    }   
                    if(ajaxFunc=='ajaxWithDrawal'){
                        ajaxWithDrawal(Data);
                    } 
                    if(ajaxFunc=='ajaxCheckfriend'){
                        ajaxCheckfriend(Data);
                    } 
                })
            })
        }else{
            window.clickListener.fanxinrsa(ajaxFunc,params);
        }
    }
}
//提现
function ajaxWithDrawal(data){
    var data = JSON.parse(data);
    var urrstr,contentType='';
    if(MZ.browser.isWechat){
    }else{
        if(data.data.kgUid==0 || data.data.kgUid == undefined){
            MZ.app.login();
            return;
        }
        contentType = 'application/json';
        urlstr = ApiPrefix+'/api/users/share/withdrawal';
        data = JSON.stringify(data);
    }
    var loading = new MZ.loading({content:'请求中...'});
    Zepto.ajax({
        url: urlstr,
        type: 'post',
        data: data,
        contentType: contentType,
        async: false,
        cache: false,
        success: function(data){
            loading.hide();
            if(data.status == 1){
                $('#moneyLeave').html('0.00');
                $('#moneyLeave').attr('data-number','0');
                MZ.toast({content:'提现成功',hide:true,time:1500});
            }else{
                MZ.alert({content:data.errorMessage})
            }
        },
        error: function(){
            loading.hide();
            MZ.alert({content:'网络连接错误'});
        }
    })
}
//检查邀请码
function ajaxCheckfriend(data){
    var data = JSON.parse(data);
    var urrstr,contentType='';
    var code = $('#inputCode').val().replace(/\s/gi,'');
    if(MZ.browser.isWechat){
    }else{
        if(data.data.kgUid==0 || data.data.kgUid == undefined){
            MZ.app.login();
            return;
        }
        contentType = 'application/json';
        urlstr = ApiPrefix+'/api/users/share/checkfriend';
        data.data.invitationCode = code;
        data = JSON.stringify(data);
    }
    var loading = new MZ.loading({content:'请求中...'});
    Zepto.ajax({
        url: urlstr,
        type: 'post',
        data: data,
        contentType: contentType,
        async: false,
        cache: false,
        success: function(data){
            loading.hide();
            if(data.status == 1){
                Master.masterNickname = data.data;
                Master.masterKgUid = code;
                var str = '<h3>师傅确认</h3><p>是否拜“'+data.data+'(ID:'+code+')”为师？<br>（师徒关系一旦绑定，将无法解除）</p>';
                MZ.confirm({content:str,hideTitle:true,callback:function(){
                    getRSA('ajaxMakeFriend',JSON.stringify({'key':1}));
                }})
            }else{
                $('.error').html(data.errorMessage);
            }
        },
        error: function(){
            loading.hide();
            MZ.alert({content:'网络连接错误'});
        }
    })
}
//认领师傅
function ajaxMakeFriend(data){
    var data = JSON.parse(data);
    var urrstr,contentType='';
    if(MZ.browser.isWechat){
    }else{
        if(data.data.kgUid==0 || data.data.kgUid == undefined){
            MZ.app.login();
            return;
        }
        contentType = 'application/json';
        urlstr = ApiPrefix+'/api/users/share/makefriend';
        data.data.invitationCode = $('#inputCode').val().replace(/\s/gi,'');
        data = JSON.stringify(data);
    }
    var loading = new MZ.loading({content:'请求中...'});
    Zepto.ajax({
        url: urlstr,
        type: 'post',
        data: data,
        contentType: contentType,
        async: false,
        cache: false,
        success: function(data){
            loading.hide();
            if(data.status == 1){
                $('#btnFriend').html('查看师傅<span class="icon icon-right-nav"></span>');
                $('#infoForm').hide();
                $('#infoForm .weui_dialog').removeClass('active');
                var info = data.data;
                MZ.showLuckyBag('<li><span class="fl"><i>￥</i>'+info.money+'</span><h3>'+info.redName+'</h3><p>'+info.redType+'</p></li>',1);
            }else{
                $('.error').html(data.errorMessage);
            }
        },
        error: function(){
            loading.hide();
            MZ.alert({content:'网络连接错误'});
        }
    })
}
//初始化信息
function ajaxInit(data){
    var data = JSON.parse(data);
    var urrstr,contentType='';
    if(MZ.browser.isWechat){
    }else{
        if(data.data.kgUid==0 || data.data.kgUid == undefined){
            MZ.app.login();
            return;
        }
        hasLogin = true;
        contentType = 'application/json';
        urlstr = ApiPrefix+'/api/users/share/makeMoney';
        data = JSON.stringify(data);
    }
    Zepto.ajax({
        url: urlstr,
        type: 'post',
        data: data,
        contentType: contentType,
        async: false,
        cache: false,
        success: function(data){
            if(data.status == 1){
                var info = data.data;
                kgUid = info.kgUid;
                inviteCode = info.invitationCode;
                $('#inviteCode').html(info.invitationCode);
                $('#moneyTotal').attr('data-number',info.totalMoney);
                $('#moneyLeave').attr('data-number',info.stayMoney);
                $('#myLink').attr('src','http://'+document.domain+'/api/h5/share/share-user.html?code='+info.kgUid);
                renderMoney();
                Master.masterNickname = info.masterNickname;
                Master.masterKgUid = info.masterKgUid;
                var timeNotExpire = data.servertime - info.registTime < 3*24*60*60*1000,
                    masterNull = info.masterNickname == null||info.masterNickname == undefined;
                if(timeNotExpire && masterNull){
                    $('#btnFriend').html('认领师傅');
                }
                if(timeNotExpire && !masterNull){
                    $('#btnFriend').html('查看师傅');
                }
                if(!timeNotExpire && masterNull){
                    $('#btnFriend').hide();
                    $('#btnMyFirends').css('margin-left','25%');
                }
            }else{
                MZ.alert({content:data.errorMessage})
            }
        },
        error: function(){
            MZ.alert({content:'网络连接错误'});
        }
    })
}
function renderMoney(){
    var $moneyTotal = $('#moneyTotal'), 
        $moneyLeave = $('#moneyLeave');
    var moneyTotal = parseFloat($moneyTotal.attr('data-number')),
        moneyLeave = parseFloat($moneyLeave.attr('data-number'));
    var num1 = moneyTotal/100,money1=0;
    var num2 = moneyLeave/100,money2=0;
    var timer = setInterval(function(){
        money1 = money1 + num1;
        money2 = money2 + num2;
        if(money1>=moneyTotal){
            money1 = moneyTotal;
            clearInterval(timer);
            $moneyTotal.html(moneyTotal.toFixed(2));
            $moneyLeave.html(moneyLeave.toFixed(2));
            return;
        }
        $moneyTotal.html(money1.toFixed(2));
        $moneyLeave.html(money2.toFixed(2));
    },10);
}
function login(){
    MZ.alert({content:'您还未登录，请先登录',callback:function(){
        if(MZ.browser.isIos){
            document.location = "KugouBuy:Login";
        }else{
            window.clickListener.GoRegister();
        }
    }});
}