define(function(require,exports,modules) {
    var App = {};
    var ApiPrefix = 'http://'+document.domain;
    var win = window,
        doc = window.document;
    //初始化
    App.init = function(){
        
        window.onload = function(){

        }
        getRSA('ajaxGetList',JSON.stringify({'key':'1'}));
        addEvent();
    }
    function addEvent(){
        //下拉加载更多中奖纪录
        var $list = $('#list');
        $(document).on('scroll touchmove',function(){
            if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
                getRSA('ajaxGetList',JSON.stringify({'key':'1'}));
            }
        });
    }
    var Page = 1;
    win.ajaxGetList = function(data){
        var $ul = $('#list');
            if($ul.attr('hasNoMore')=='true')return;
            if($ul.attr('isLoading')=='true')return;
            $ul.attr('isLoading','true');
            var PaseSize = 20;

            var data = JSON.parse(data);
            var urrstr,contentType='';
            if(MZ.browser.isWechat){
            }else{
                if(data.data.kgUid==0 || data.data.kgUid == undefined){
                    MZ.app.login();
                    return;
                }
                hasLogin = true;
                contentType = 'application/json';
                urlstr = ApiPrefix+'/api/users/share/friends';
                data.data.pageSize = PaseSize;
                data.data.pageNumber = Page;
                data = JSON.stringify(data);
            }
            Zepto.ajax({
                url: urlstr,
                type: 'post',
                data: data,
                contentType: contentType,
                async: false,
                cache: false,
                success: function(data){    
                    $ul.attr('isLoading','false');
                    if(data.status == 1){
                        var str = '';
                        var list = data.data;
                        if(list==''){
                            $ul.html('<div class="center nodata">您暂无徒弟</div>');
                            return;
                        }
                        for(var i in list){
                            var item = list[i];
                            str += '<li class="item">'+
									'	<span class="fr">'+item.totalMoney+'元<br><i>累计贡献</i></span>'+
									'	<span class="fl"><img src="'+item.avatarUrl+'"></span>'+
									'	<h3>'+item.friendsNickname+'</h3>'+
									'	<p>剩余 '+item.totalDate+' 天</p>'+
									'</li>';
                        }
                        if(list.length!=0){
                            Page++;
                        }
                        if(list.length<PaseSize){
                            $ul.attr('hasNoMore','true');
                            if(list.length == 0 && lastId == 0){
                                $ul.html('<div class="center nodata">您暂无徒弟</div>');
                            }else{
                                $ul.append(str);
                            }
                        }else{
                            $ul.append(str);
                        }
                    }else{
                        MZ.alert({content:data.errorMessage})
                    }
                },
                error: function(){
                    $ul.attr('isLoading','false');
                    MZ.alert({content:'网络连接错误'});
                }
            })
    }
    function getRSA(ajaxFunc,params){
        var paramsStr;
        if(typeof params != 'string'){
            paramsStr = JSON.stringify(params);
        }else{
            paramsStr = params;
        }
        if(MZ.browser.isWechat){       
        }else{
            if(navigator.userAgent.match(/(iPad|iPhone|iPod)/g)){
                setupWebViewJavascriptBridge(function(bridge) {

                    bridge.callHandler('px_iosSideHandler', paramsStr , function responseCallback(Data) {
                        if(ajaxFunc=='ajaxGetList'){
                            ajaxGetList(Data);
                        }
                    })
                })
            }else{
                window.clickListener.fanxinrsa(ajaxFunc,params);
            }
        }
    }
    modules.exports = App;
    
});