define(function(require,exports,modules) {
    var App = {};
    var ApiPrefix = 'http://'+document.domain,userImg,username='0',kgUid=0;
    //初始化
    App.init = function(){
        
        window.onload = function(){
        }
        //canvasImg();
        getRSA('ajaxGetInfo',{'key':1});
        addEvent();
    }
    window.ajaxGetInfo = function(data){
       var data = JSON.parse(data);
        var urrstr,contentType='';
        if(MZ.browser.isWechat){
        }else{
            if(data.data.kgUid==0 || data.data.kgUid == undefined){
                login();
                return;
            }
            contentType = 'application/json';
            urlstr = ApiPrefix+'/api/user/detail';
            data.data.status = 1;
            data.data.targetKgUid = data.data.kgUid;
            data = JSON.stringify(data);
        }
        Zepto.ajax({
            url: urlstr,
            type: 'post',
            data: data,
            contentType: contentType,
            async: false,
            cache: false,
            success: function(data){
                if(data.errorMessage=='token不合法'){
                   login();
                   return;
                }
                if(data.status == 1){
                  userImg = data.data.avatarUrl;
                  username = data.data.nickname;
                  kgUid = data.data.kgUid;
                  if(localStorage){
                    var userImgStorage = localStorage.getItem('userImg'),
                        userImgData = localStorage.getItem('userImgData');
                    if(userImgStorage==userImg && userImgData != null){
                      userImg = 'data:image/jpeg;base64,' + userImgData;
                      canvasImg();
                    }else{
                      getRSA('ajaxGetImg',{'key':1});
                    }
                  }else{
                    getRSA('ajaxGetImg',{'key':1});
                  }
                }else{                  
                  MZ.alert({content:data.errorMessage})
                }
            },
            error: function(){
                MZ.alert({content:'网络连接错误'});
            }
        })
    }
    window.ajaxGetImg = function(data){
        var data = JSON.parse(data);
        var urrstr,contentType='';
        if(MZ.browser.isWechat){
        }else{
            if(data.data.kgUid==0 || data.data.kgUid == undefined){
                login();
                return;
            }
            contentType = 'application/json';
            urlstr = ApiPrefix+'/api/users/share/getImage';
            if(/com\/static/gi.test(userImg)){
              userImg = ApiPrefix + '/api/static/images/img_defaultavatar.png?v='+new Date().getTime();
            }
            data.data.imgeURL = userImg;
            data = JSON.stringify(data);
        }
        Zepto.ajax({
            url: urlstr,
            type: 'post',
            data: data,
            contentType: contentType,
            async: false,
            cache: false,
            success: function(data){
                if(data.errorMessage=='token不合法'){
                   login();
                   return;
                }
                if(data.status == 1){
                  userImg = 'data:image/jpeg;base64,'+data.data;
                  canvasImg();
                }else{
                    MZ.alert({content:'用户头像获取失败，请刷新重试'})
                }
            },
            error: function(){
                MZ.alert({content:'网络连接错误'});
            }
        })
    }
    function addEvent(){
        $('#btnSavePic').on('click tuochend',function(e){
            e.preventDefault();
            var data = getDataUrl('mycode');
            MZ.app.savePic(data.split(',')[1]);
        })
    }
    function getRSA(ajaxFunc,params){
        if(MZ.browser.isWechat){       
        }else{
            if(navigator.userAgent.match(/(iPad|iPhone|iPod)/g)){
                setupWebViewJavascriptBridge(function(bridge) {
                    bridge.callHandler('px_iosSideHandler', params , function responseCallback(Data) {
                        if(ajaxFunc=='ajaxGetInfo'){
                            ajaxGetInfo(Data);
                        }
                        if(ajaxFunc=='ajaxGetImg'){
                            ajaxGetImg(Data);
                        }
                    })
                })
            }else{
                window.clickListener.fanxinrsa(ajaxFunc,params);
            }
        }
    }
    function login(){
        MZ.alert({content:'您还未登录，请先登录',callback:function(){
            if(MZ.browser.isIos){
                document.location = "KugouBuy:Login";
            }else{
                window.clickListener.GoRegister();
            }
        }});
    }
    var loading = new MZ.loading({content:'生成二维码中...'});
    setTimeout(function(){
      if($('.weui_loading_toast').length!=0){
       //location.href = '';
      }
    },2000)
    function canvasImg(){
      function drawBg(bg){
          var mycv = document.getElementById("mycode");  
          var myctx = mycv.getContext("2d");
          myctx.drawImage(bg, 0, 0);
          //画入二维码
          drawCode();
      }
      load();
      function load(){
          var bg = new Image();  
          bg.src = "images/bg_myqrcard.jpg?v="+new Date().getTime(); 
          if(bg.complete){
             drawbg(bg);
          }else{
             bg.onload = function(){
                drawBg(bg);
             };
             bg.onerror = function(){
               window.alert('加载失败，请重试');
             };
          };   
      }
    }
    //画入用户头像等信息
    function drawUserData(){
        var userPic = new Image();  
        if(/com\/static/gi.test(userImg)){
          userImg = ApiPrefix + '/api/static/images/img_defaultavatar.png?v='+new Date().getTime();
        }
        userPic.src = userImg;
        //userPic.setAttribute('crossOrigin', 'Anonymous');
        //userPic.src = 'http://imge.kugou.com/kugouicon/165/20160501/20160501094958534537.jpg?v='+new Date().getTime();
        //userPic.src = 'http://p1.fx.kgimg.com/v2/kmh_1_img/T1R0KmBvKv1RCvBVdK.jpg?v='+new Date().getTime();
        //userPic.src = "https://img.alicdn.com/tps/TB1t3ITJXXXXXXAXpXXXXXXXXXX-200-200.jpg_120x120.jpg?v="+new Date().getTime(); 
        if(userPic.complete){
            drawUserPic(userPic);
        }else{
            userPic.onload = function(){
                drawUserPic(userPic);
            };
            userPic.onerror = function(){
               window.alert('加载头像失败，请重试');
            };
        };
        function drawUserPic(userPic){
            var mycv = document.getElementById("mycode");  
            var myctx = mycv.getContext("2d");
            myctx.save();
            roundedImage(245,150,140,140,83);
            myctx.clip();
            myctx.drawImage(userPic,245,150,140,140);
            myctx.restore();
            myctx.font="30px Arial";
            myctx.textAlign="center";
            myctx.fillText(username,315,330);
            drawUserCover();
            return;
           var pattern = myctx.createPattern(userPic, "no-repeat");
           myctx.arc(245, 150, Math.max(userPic.width, userPic.height) / 2, 0, 2 * Math.PI);
           myctx.drawImage(userPic, 0, 0);
           myctx.fillStyle = pattern;
           myctx.fill(); 
        }
    }
    function drawUserCover(){
        $('#btnSavePic').fadeIn();
        var pic = new Image();  
        pic.src = "images/cover.png?v="+new Date().getTime();
        loading.hide();
        if(pic.complete){
            drawUserPicCover(pic);
        }else{
            pic.onload = function(){
                drawUserPicCover(pic);
            };
            pic.onerror = function(){
               window.alert('加载失败，请重试');
            };
        };
        function drawUserPicCover(userPic){
            var mycv = document.getElementById("mycode");  
            var myctx = mycv.getContext("2d");
            myctx.save();
            roundedImage(240,150,150,150,0);
            myctx.clip();
            myctx.drawImage(userPic,238,145,150,150);
            myctx.restore();
            return;
           var pattern = myctx.createPattern(userPic, "no-repeat");
           myctx.arc(245, 150, Math.max(userPic.width, userPic.height) / 2, 0, 2 * Math.PI);
           myctx.drawImage(userPic, 0, 0);
           myctx.fillStyle = pattern;
           myctx.fill(); 
        }
    }
    function roundedImage(x,y,width,height,radius){
      var mycv = document.getElementById("mycode");  
      var ctx = mycv.getContext("2d");
      ctx.beginPath();
      ctx.moveTo(x + radius, y);
      ctx.lineTo(x + width - radius, y);
      ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
      ctx.lineTo(x + width, y + height - radius);
      ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
      ctx.lineTo(x + radius, y + height);
      ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
      ctx.lineTo(x, y + radius);
      ctx.quadraticCurveTo(x, y, x + radius, y);
      ctx.closePath();
    }
    //生成二维码并画入合成图
    function drawCode(){

        var qrnode = new AraleQRCode({
            render: 'canvas',
            correctLevel: 0,
            text: ApiPrefix+"/api/h5/share/share-user.html?code="+kgUid,
            size: 170,
            background: '#FFF',
            foreground: '#f04a56',
            pdground: '#f04a56',
            imageSize : 100
        });
        $('#qrcode').append(qrnode);
        $('#qrcode canvas').attr('id','codeImg');
        setTimeout(function(){
            var codecvs = document.getElementById('codeImg');  
            var imgData = codecvs.toDataURL('image/jpg');
            var codeImg = new Image();  
            codeImg.src = imgData; 
            codeImg.onload = function(){
               var mycode = document.getElementById("mycode");  
               var mycode = mycode.getContext("2d");
               mycode.drawImage(codeImg, 145, 412,340,340);                
               drawUserData();
            };
        },100)
    }
    function getDataUrl(id){
        var mycv = document.getElementById(id);  
        var imgData = mycv.toDataURL('image/jpg');
        return imgData;
    }
    modules.exports = App;
    
});

