define(function(require,exports,modules) {
    var App = {};
    //初始化
    App.init = function(){
        
        window.onload = function(){

        }
        addEvent();
    }
    function addEvent(){
        $('#btnShowRule').on('click touchend',function(e){
            e.preventDefault();
            var str = '<div class="ruleDesc"><h3 class="center">兑换说明</h3><p>1、用户可使用积分兑换红包，兑换比例为  1000：1</p><p>2、红包数量每日有限，次日0点刷新</p><p>3、积分一旦兑换为红包，既不可退回</p></div>';
            MZ.alert({content:str,footerText:'知道了'})
        })
    }

    modules.exports = App;
    
});