var CanPay = false;
var Recharge = (function(obj,win){
	var ApiPrefix = 'http://'+document.domain;
	var $btnRecharge = $('#btnRecharge');
	var hasLogin = false,rechargeTime,hasActive=false,ServerTime = new Date().getTime(),hasGet=false,isLastDay=false;
	var win = window,
		doc = window.document,
		version;
	obj.ajax = {		
		init: function(data){
			var data = JSON.parse(data);
			version = data.version;
		    var urrstr,contentType='';

		    if(MZ.browser.isWechat){
		    }else{
		        if(data.data.kgUid==0 || data.data.kgUid == undefined){
		            login();
		            return;
		        }
		        contentType = 'application/json';
		        urlstr = ApiPrefix+'/api/rechargeRedEnvelope/receive';
		        data = JSON.stringify(data);
		    }
			Zepto.ajax({
				url: urlstr,
				type: 'post',
				data: data,
				contentType: contentType,
				async: false,
				cache: false,
				success: function(data){
					if(data.status == 1){
						var info = data.data;
						hasActive = info.flag;
						if(hasActive==false && typeof info.one == 'undefined'){
							$('#btnRecharge').addClass('disabled').html('活动已结束');
							$('#pageEnd').show();
							return;
						}
						rechargeTime = info.rechargeTime;
						//rechargeTime = 1468617010000;
						ServerTime = data.servertime;
						var tdate7 = rechargeTime+6*24*60*60*1000;
						if(rechargeTime!=undefined){
							var tnow = formateDate(ServerTime);
							if(formateDate(ServerTime) == formateDate(tdate7)){
								isLastDay = true;
								//第七天
								if(info.seven==1){
									hasGet = false;
									$('#btnRecharge').html('充100领红包').removeClass('disabled');
								}else{
									$('#btnRecharge').html('领取红包');
								}
							}else if(formateDate(ServerTime) != formateDate(tdate7) && ServerTime<=tdate7){
								var todayStatus;
								for(var i=0;i<7;i++){
									var t =  rechargeTime+i*24*60*60*1000;
									if(formateDate(t)==tnow){
										if(i==0){todayStatus = info.one;}
										if(i==1){todayStatus = info.two;}
										if(i==2){todayStatus = info.three;}
										if(i==3){todayStatus = info.four;}
										if(i==4){todayStatus = info.five;}
										if(i==5){todayStatus = info.six;}
										if(i==6){todayStatus = info.seven;}
									}
								}
								if(todayStatus==1){
									hasGet = true;
								}else{
									$('#btnRecharge').html('领取红包');
								}
							}else if(formateDate(ServerTime) != formateDate(tdate7) && ServerTime>tdate7){
								//已充值过7天
								$('#btnRecharge').html('充100领红包');
							}
							for(var i=0;i<7;i++){
								var t =  rechargeTime+i*24*60*60*1000;
								var $item = $('#day'+(i-1+2));
								var status = 0;
								if(i==0){status = info.one;}
								if(i==1){status = info.two;}
								if(i==2){status = info.three;}
								if(i==3){status = info.four;}
								if(i==4){status = info.five;}
								if(i==5){status = info.six;}
								if(i==6){status = info.seven;}
								if(status == 1){
									renderBtn($item,1);
								}else{
									if(formateDate(t)!=tnow){
										if(ServerTime>t){
											renderBtn($item,2);
										}
									}else{
										renderBtn($item,0);
									}
								}
							}
							function renderBtn($item,status){
								if(status==1){
									$item.addClass('active').find('.btn-area').html('<a class="btn">已领取</a>');
								}else if(status==0){
									$item.find('.btn-area').html('<a class="btn">可领取</a>');
								}else{
									$item.addClass('disabled');
								}
							}
							timeTicker(ServerTime);
						}
					}else{
						MZ.alert({content:data.errorMessage})
					}
				},
				error: function(){
					MZ.alert({content:'网络连接错误'});
				}
			})
		}, 
		claimRed: function(data){
			var data = JSON.parse(data);
		    var urrstr,contentType='';
		    if(MZ.browser.isWechat){
		    }else{
		        if(data.data.kgUid==0 || data.data.kgUid == undefined){
		            login();
		            return;
		        }
		        contentType = 'application/json';
		        urlstr = ApiPrefix+'/api/rechargeRedEnvelope/claimRed';
		        data = JSON.stringify(data);
		    }
		    var loading = new MZ.loading({content:'领取红包中...'});
			Zepto.ajax({
				url: urlstr,
				type: 'post',
				data: data,
				contentType: contentType,
				cache: false,
				success: function(data){
					loading.hide();	
					if(data.status == 1){
						if(isLastDay){
							if(hasActive){
								hasGet = false;
								$('#btnRecharge').html('充100领红包').removeClass('disabled');
							}else{
								$('#btnRecharge').html('活动已结束').removeClass('disabled');
							}
							
						}else{
							hasGet = true;
						}
						$('.item').each(function(){
							var $this = $(this),	
								$btn = $this.find('.btn');
							if($btn.text()=='可领取'){
								$btn.text('已领取');
								$('#pageRed').addClass('active');
								$('#pageRed .type').html($this.attr('data-money')+"元红包");
								$('#pageRed .money').html("￥"+$this.attr('data-money'));
								$('#pageRed .tips').html($this.attr('data-type'));
								$this.addClass('active');
							}
						})
					}else{
						MZ.alert({content:data.errorMessage})
					}
				},
				error: function(){
					loading.hide();
					MZ.alert({content:'网络连接错误'});
				}
			})
		}
	}
	obj.init = function(){
		//MZ.showLuckyBag('<li><span class="fl"><i>￥</i>23334</span><h3>123</h3><p>4353</p></li>',3);		
		getRSA('Recharge.ajax.init',JSON.stringify({'key':'1'}));
		obj.addEvent();
	}
	obj.addEvent = function(){		
		$('#btnRecharge').on('click',function(){
			var $this = $(this);
			if($this.text()=='充100领红包'){
			  if(MZ.browser.isAndroid){
			  	if(CanPay){
			    	window.clickListener.GoRecharge(100);
			  	}else{
			    	window.clickListener.GoRecharge();
			  	}
			  }else if(MZ.browser.isIos){
			    document.location = "KugouBuy:Recharge:"+JSON.stringify({amount:100});
			  }
			}else if($this.text()=='领取红包'){
				getRSA('Recharge.ajax.claimRed',JSON.stringify({'key':'1'}));
			}
			
		})
		//点击
		$('.item').on('click',function(){
			var $btnRecharge = $('#btnRecharge');
			if($btnRecharge.text()=='充100领红包'){
				MZ.confirm({content:'<div style="padding:.4rem 0;">充值100元才可领取红包哟</div>',hideTitle:true,textOk:'充值',callback:function(){
					if(MZ.browser.isAndroid){
					  	if(CanPay){
					    	window.clickListener.GoRecharge(100);
					  	}else{
					    	window.clickListener.GoRecharge();
					  	}
					  }else if(MZ.browser.isIos){
					    document.location = "KugouBuy:Recharge:"+JSON.stringify({amount:100});
					  }
				}})
			}
		})
		$('#pageRed .btnClose').on('click touchend',function(e){
			e.preventDefault();
			$('#pageRed').removeClass('active');
		})
		$('#btnGet').on('click touchend',function(e){
			e.preventDefault();
			$('#pageRed').removeClass('active');
		})
        //领取红包
        $('.item').delegate('.btn','click',function(){
        	var $this = $(this);
        	if($this.text()=='可领取'){
	        	getRSA('Recharge.ajax.claimRed',JSON.stringify({'key':'1'}));
        	}
        })
	}
	function timeTicker(stime){
	   var serverTime = stime,
	      localTimeStart = new Date().getTime();
	  var tomorrow = new Date(serverTime+24*60*60*1000);
	  var targetTime = new Date(tomorrow.getFullYear()+"/"+(tomorrow.getMonth()+1)+"/"+tomorrow.getDate()+' 00:00:00').getTime();
	  var time = targetTime - serverTime;
	  countdown(time);
	  if(time>0){
	      timer = setInterval(function(){
	        var t = time - (new Date().getTime()-localTimeStart);
	        if(t>0){
	          countdown(t);
	        }else{
	          clearInterval(timer);
	        }
	      },500)
	  }else{
	   
	  }
	  function countdown(t){
	    var h = 60*60*1000,
	        m = 60*1000,
	        s = 1000;
	    var H = parseInt(t/h),
	        M = parseInt((t-H*h)/m),
	        S = parseInt((t-H*h-M*m)/s),
	        HS = parseInt((t-H*h-M*m-S*s)/10);
	        if(t<=0){
	        	location.href = '';
	        	return;
	        }
	        if(hasGet){
			    $btnRecharge.addClass('disabled').html('<span>'+H+"</span>小时<span>"+intNumber(M)+"</span>分<span>"+intNumber(S)+"</span>秒后可再次领取");
	        }
	  }
	}
	function intNumber(n){
	  return n<10?'0'+n:n;
	}
	function formateTime(dt){
	 var dt = new Date(dt);
      return dt.getFullYear()+"."+(dt.getMonth()+1)+"."+dt.getDate()+" "+intNumber(dt.getHours())+":"+intNumber(dt.getMinutes())+":"+intNumber(dt.getSeconds());
	}
	function formateDate(dt){
	 var dt = new Date(dt);
      return dt.getFullYear()+""+(dt.getMonth()+1)+""+dt.getDate();
	}
	return obj;
})(Recharge || {},window)
Recharge.init();
function checkAndroidResult(){
	CanPay = true;
}
function getRSA(ajaxFunc,params){
    if(MZ.browser.isWechat){       
    }else{
        if(navigator.userAgent.match(/(iPad|iPhone|iPod)/g)){
            setupWebViewJavascriptBridge(function(bridge) {
                bridge.callHandler('px_iosSideHandler', params , function responseCallback(Data) {
                    if(ajaxFunc=='Recharge.ajax.init'){
                        Recharge.ajax.init(Data);
                    }
                    if(ajaxFunc=='Recharge.ajax.claimRed'){
                        Recharge.ajax.claimRed(Data);
                    }
                    
                })
            })
        }else{
            window.clickListener.fanxinrsa(ajaxFunc,params);
        }
    }
}
function login(){
	setTimeout(function(){
		MZ.alert({content:'您还未登录，请先登录',callback:function(){
	        if(MZ.browser.isIos){
	            document.location = "KugouBuy:Login";
	        }else{
	            window.clickListener.GoRegister();
	        }
	    }});
	},300)
}
//检测是否支付可以传参数
window.clickListener.init('checkAndroidResult');