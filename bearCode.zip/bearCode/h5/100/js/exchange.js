var Exchange = (function(obj,win){
	var ApiPrefix = 'http://'+document.domain;
	var hasLogin = false,userPoint=0,objExchange = {};
	var win = window,
		doc = window.document;
	obj.ajax = {
		getList: function(data){
			var $ul = $('#list');
			if($ul.attr('hasNoMore')=='true')return;
			if($ul.attr('isLoading')=='true')return;
			$ul.attr('isLoading','true');
			var lastId = $ul.attr('lastid');
		    var PaseSize = 20;

			var data = JSON.parse(data);
		    var urrstr,contentType='';
		    if(MZ.browser.isWechat){
		    }else{
		        if(data.data.kgUid==0 || data.data.kgUid == undefined){
		            login();
		            return;
		        }
		        hasLogin = true;
		        contentType = 'application/json';
		        urlstr = ApiPrefix+'/api/user/point/exchangeRedEnvelopeList';
		        data.data.pageSize = PaseSize;
		        data.data.lastId = lastId;
		        data = JSON.stringify(data);
		    }
			Zepto.ajax({
				url: urlstr,
				type: 'post',
				data: data,
				contentType: contentType,
				async: false,
				cache: false,
				success: function(data){	
					$ul.attr('isLoading','false');
					if(data.status == 1){
						var str = '';
						var list = data.data.redEnvelopeList;
						for(var i in list){
							var item = list[i];
							var subTypeStr = item.subType == 0 ? '直减':'满'+item.limitOrderMoney+'元可用';
							var statuStr = item.status == 0 ? '数量有限，抢完即止':'已被抢光，明天再来看看吧~';
							var statuBtn = item.status == 0 ? '':'disabled';
							var btnStr = item.status == 0 ? item.money*1000+'积分':'已抢光';
							str += '<li class="item" id="item'+item.id+'">'+
									'	<div class="fr">'+
									'		<a data-id="'+item.id+'" class="btn jsExchange btn-red-transparent '+statuBtn+'" data-money="'+item.money+'">'+btnStr+'</a>'+
									'	</div>'+
									'	<div class="cicon icon-img_luckybagitem">'+
									'		￥<span>'+item.money+'</span>'+
									'	</div>'+
									'	<h3>'+item.name+'</h3>'+
									'	<p class="subType">'+subTypeStr+'</p>'+
									'	<p>'+statuStr+'</p>'+
									'</li>';
						}
						if(list.length!=0){
							$ul.attr('lastid',list[list.length-1].id);
						}
						if(list.length<PaseSize){
							$ul.attr('hasNoMore','true');
							if(list.length == 0 && lastId == 0){
								$ul.html('<div class="center" style="line-height:50px;color:#666;font-size:16px;">暂无数据</div>');
							}else{
								$ul.append(str);
							}
						}else{
							$ul.append(str);
						}
					}else{
						MZ.alert({content:data.errorMessage})
					}
				},
				error: function(){
					$ul.attr('isLoading','false');
					MZ.alert({content:'网络连接错误'});
				}
			})
		},
		query: function(data){
			var data = JSON.parse(data);
		    var urrstr,contentType='';
		    if(MZ.browser.isWechat){
		    }else{
		        if(data.data.kgUid==0 || data.data.kgUid == undefined){
		            login();
		            return;
		        }
		        contentType = 'application/json';
		        urlstr = ApiPrefix+'/api/user/point/query';
		        data = JSON.stringify(data);
		    }
			Zepto.ajax({
				url: urlstr,
				type: 'post',
				data: data,
				contentType: contentType,
				async: false,
				cache: false,
				success: function(data){	
					getRSA('Exchange.ajax.getList',JSON.stringify({'key':'1'}));
					if(data.status == 1){
						userPoint = data.data.userPoint;
						$('#userPoint').html(userPoint);
					}else{
						MZ.alert({content:data.errorMessage})
					}
				},
				error: function(){
					$ul.attr('isLoading','false');
					MZ.alert({content:'网络连接错误'});
				}
			})
		},
		exchange: function(data){
			var data = JSON.parse(data);
		    var urrstr,contentType='';
		    if(MZ.browser.isWechat){
		    }else{
		        if(data.data.kgUid==0 || data.data.kgUid == undefined){
		            login();
		            return;
		        }
		        contentType = 'application/json';
		        urlstr = ApiPrefix+'/api/user/point/exchangeRedEnvelope';
		        data.data.redEnvelopeId = objExchange.id;
		        data = JSON.stringify(data);
		    }
		    var loading = new MZ.loading({content:'兑换请求中...'});
			Zepto.ajax({
				url: urlstr,
				type: 'post',
				data: data,
				contentType: contentType,
				async: false,
				cache: false,
				success: function(data){
					loading.hide();	
					if(data.status == 1){
						if(data.data.result==1){
							userPoint -= objExchange.money*1000;
							$('#userPoint').html(userPoint);
							var $item =  objExchange.$item;
							MZ.showLuckyBag('<li><span class="fl"><i>￥</i>'+objExchange.money+'</span><h3>'+$item.find('h3').html()+'</h3><p>'+$item.find('.subType').html()+'</p></li>',1);
							if(data.data.remainRedEnvelope==0){
								objExchange.$item.find('.btn').addClass('disabled').html('已抢光');
								objExchange.$item.find('p').eq(1).html('已被抢光，明天再来看看吧');
							}
						}else{
							MZ.toast({content:'兑换失败',hide:true,time:2000});
						}
					}else{
						MZ.alert({content:data.errorMessage})
					}
				},
				error: function(){
					loading.hide();
					MZ.alert({content:'网络连接错误'});
				}
			})
		}
	}
	obj.init = function(){
		//MZ.showLuckyBag('<li><span class="fl"><i>￥</i>23334</span><h3>123</h3><p>4353</p></li>',3);		
		getRSA('Exchange.ajax.query',JSON.stringify({'key':'1'}));
		obj.addEvent();
	}
	obj.addEvent = function(){
		$('#btnShowRule').on('click touchend',function(e){
            e.preventDefault();
            var str = '<div class="ruleDesc"><h3 class="center">兑换说明</h3><p>1、用户可使用积分兑换红包，兑换比例为  1000：1</p><p>2、红包数量每日有限，次日0点刷新</p><p>3、积分一旦兑换为红包，既不可退回</p></div>';
            MZ.alert({content:str,footerText:'知道了'})
        })
        //下拉加载更多中奖纪录
		var $list = $('#list');
		$(document).on('scroll touchmove',function(){
            if($(win).scrollTop()+$(win).height()+50>=$(doc).height()){
		        getRSA('Exchange.ajax.getList',JSON.stringify({'key':'1'}));
            }
        });
        //兑换
        $('#list').delegate('.jsExchange','click',function(){
        	var $this = $(this);
        	if($this.hasClass('disabled'))return;
        	var dataId = $this.attr('data-id');
        	var money = $this.attr('data-money');
        	if(money*1000>userPoint){
        		MZ.toast({content:'积分不足<br>还差 '+(money*1000-userPoint)+' 积分',hide:true,time:1500});
        		return;
        	}else{
        		objExchange.id = dataId;
        		objExchange.money = money;
        		objExchange.$item = $this.parents('.item');
        		MZ.confirm({content:'您确定兑换吗？',callback:function(){
        			getRSA('Exchange.ajax.exchange',JSON.stringify({'key':'1'}));
        		}})
        	}

        })
	}
	return obj;
})(Exchange || {},window)
Exchange.init();

function getRSA(ajaxFunc,params){
    if(MZ.browser.isWechat){       
    }else{
        if(navigator.userAgent.match(/(iPad|iPhone|iPod)/g)){
            setupWebViewJavascriptBridge(function(bridge) {
                bridge.callHandler('px_iosSideHandler', params , function responseCallback(Data) {
                    if(ajaxFunc=='Exchange.ajax.getList'){
                        Exchange.ajax.getList(Data);
                    }
                    if(ajaxFunc=='Exchange.ajax.query'){
                        Exchange.ajax.query(Data);
                    }
                    if(ajaxFunc=='Exchange.ajax.exchange'){
                        Exchange.ajax.exchange(Data);
                    }
                })
            })
        }else{
            window.clickListener.fanxinrsa(ajaxFunc,params);
        }
    }
}
function shareSuccess(){
	getRSA('Exchange.ajax.ExchangeShare',JSON.stringify({'key':'1'}));
}
function login(){
	MZ.alert({content:'您还未登录，请先登录',callback:function(){
        if(MZ.browser.isIos){
            document.location = "KugouBuy:Login";
        }else{
            window.clickListener.GoRegister();
        }
    }});
}